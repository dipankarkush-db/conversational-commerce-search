# Conversational Commerce Search

An AI-powered conversational commerce search system built on Databricks that revolutionizes online shopping through natural language interactions. This platform combines advanced content-based filtering, semantic embeddings, and intelligent conversational agents to create an intuitive, personalized shopping experience that understands customer intent and delivers relevant product recommendations in real-time.

## 🎯 Overview

This project implements a next-generation **Conversational Commerce** platform that transforms how customers discover and purchase products online. By leveraging AI-driven conversations, the system creates a shopping assistant that understands natural language, remembers customer preferences, and provides personalized recommendations that drive engagement and sales.

### Key Conversational Commerce Capabilities

- **🛍️ AI Shopping Assistant**: Intelligent conversational agent that acts as a personal shopping consultant
- **🔍 Natural Language Product Search**: Customers can search using everyday language like "Show me camping gear under $100"
- **🎯 Intent-Driven Recommendations**: Understands shopping intent beyond keywords (gift-giving, budget constraints, specific needs)
- **💬 Multi-Turn Conversations**: Maintains context across conversation turns for refined product discovery
- **🏪 Personalized Shopping Experience**: Adapts to individual customer preferences and shopping behavior
- **⚡ Real-Time Product Matching**: Instant semantic search across product catalogs using vector embeddings
- **🔄 Contextual Follow-ups**: Suggests complementary products and alternatives based on conversation flow

### Business Value Proposition

- **📈 Increased Conversion Rates**: Personalized recommendations drive higher purchase intent
- **🎪 Enhanced Customer Engagement**: Interactive conversations keep customers engaged longer
- **💰 Higher Average Order Value**: Intelligent cross-selling and upselling through natural dialogue
- **🎨 Improved Customer Satisfaction**: Intuitive search experience reduces friction in product discovery
- **📊 Rich Customer Insights**: Conversation data provides deep insights into customer preferences and behavior

## 🏗️ Conversational Commerce Search Architecture

### Overall System Architecture

```mermaid
graph TB
    subgraph "Customer Experience Layer"
        CUSTOMER[👤 Customer]
        QUERY[💬 Natural Language Query<br/>wireless headphones for running]
        UI[🖥️ Conversational Interface]
    end
    
    subgraph "AI Commerce Agent"
        AGENT[🧠 Conversational Agent<br/>Claude 3.5 Sonnet]
        INTENT[🎯 Intent Understanding<br/>Product: headphones<br/>Use case: running<br/>Feature: wireless]
        CONTEXT[🔄 Conversation Memory<br/>Multi-turn dialogue]
    end
    
    subgraph "Content-Based Filtering Engine"
        CBF[📊 Content-Based Filtering<br/>System]
        VECTOR[🔍 Vector Search<br/>BGE-Large Embeddings]
        SIMILARITY[📈 Similarity Matching<br/>Cosine similarity]
        PERSONALIZE[🎯 Personalization<br/>User preferences]
    end
    
    subgraph "Databricks Data Platform"
        UC[🏛️ Unity Catalog<br/>Data Governance]
        PRODUCTS[📦 Product Catalog<br/>10K+ products with features]
        CUSTOMERS[👥 Customer Profiles<br/>Personas and preferences]
        INTERACTIONS[🔄 Shopping History<br/>Views purchases ratings]
        FUNCTIONS[⚙️ UC Functions<br/>Serverless recommendations]
    end
    
    subgraph "Recommendation Output"
        RECS[💡 Personalized Recommendations]
        EXPLAIN[📝 Natural Language Explanations]
        CROSSSELL[🛒 Cross-sell Suggestions]
        RESPONSE[💬 Structured Response<br/>with product suggestions]
    end
    
    %% Customer Journey Flow
    CUSTOMER --> QUERY
    QUERY --> UI
    UI --> AGENT
    
    %% Agent Processing
    AGENT --> INTENT
    INTENT --> CONTEXT
    AGENT --> CBF
    
    %% Content-Based Filtering
    CBF --> VECTOR
    CBF --> SIMILARITY
    CBF --> PERSONALIZE
    
    %% Data Access
    VECTOR --> UC
    SIMILARITY --> PRODUCTS
    PERSONALIZE --> CUSTOMERS
    CBF --> INTERACTIONS
    UC --> FUNCTIONS
    
    %% Response Generation
    FUNCTIONS --> RECS
    RECS --> EXPLAIN
    RECS --> CROSSSELL
    AGENT --> RESPONSE
    RESPONSE --> UI
    UI --> CUSTOMER
    
    %% Styling
    style CUSTOMER fill:#e8f5e8
    style AGENT fill:#e1f5fe
    style CBF fill:#f3e5f5
    style UC fill:#fff3e0
    style RECS fill:#f1f8e9
```

### Conversational Commerce User Journey

```mermaid
sequenceDiagram
    participant Customer as 🛍️ Customer
    participant UI as 💬 Chat Interface
    participant Agent as 🤖 AI Shopping Assistant
    participant Tools as 🔧 UC Functions
    participant Vector as 🔍 Vector Search
    participant Data as 📊 Product Data
    
    Customer->>UI: I need wireless headphones for running
    UI->>Agent: Process natural language query
    
    Note over Agent: 🧠 Understand intent:<br/>Product: headphones<br/>Use case: running<br/>Feature: wireless
    
    Agent->>Tools: Call recommend_products_fuzzy_category()
    Tools->>Vector: Search similar products
    Vector->>Data: Query product embeddings
    Data-->>Vector: Return matching products
    Vector-->>Tools: Ranked product list
    Tools-->>Agent: Personalized recommendations
    
    Note over Agent: 🎯 Generate contextual response<br/>with product suggestions
    
    Agent->>UI: Here are great wireless headphones for running
    Note over UI: 1. Sony WF-1000XM4 - $280<br/>2. Apple AirPods Pro - $249<br/>3. Jabra Elite 75t - $199
    UI->>Customer: Display recommendations
    
    Customer->>UI: What about battery life?
    UI->>Agent: Follow-up question
    
    Note over Agent: 🔄 Maintain conversation context
    Agent->>Tools: Get detailed product features
    Tools-->>Agent: Battery specifications
    
    Agent->>UI: Battery comparison provided
    Note over UI: Sony: 8hrs + 24hrs case<br/>Apple: 4.5hrs + 24hrs case<br/>Jabra: 7.5hrs + 28hrs case
    UI->>Customer: Detailed comparison
    
    Customer->>UI: I'll take the Jabra ones
    UI->>Agent: Purchase intent
    Agent->>UI: Great choice! Cross-sell suggestion
    Note over UI: Jabra Elite 75t offers excellent<br/>battery life for long runs.<br/>Would you like a carrying case?
    UI->>Customer: Cross-sell suggestion
```

### Technology Stack

- **Databricks Platform**: Unity Catalog, Vector Search, Foundation Models
- **AI Framework**: LangGraph, LangChain, MLflow Agent Framework
- **Embeddings**: Databricks BGE-Large-EN model (1024 dimensions)
- **Data Processing**: PySpark, Delta Lake with Change Data Feed
- **Agent Runtime**: Claude 3.5 Sonnet via Databricks Model Serving
- **Vector Database**: Unity Catalog Vector Search with real-time indexing

### Core Components

```
conversational-commerce-search/
├── content-based-filtering/
│   ├── 01_data_generation.ipynb          # Synthetic e-commerce data generation
│   ├── 02_vector_index_generation.ipynb  # Embedding generation & vector search setup
│   ├── 03_uc_function_tools.py           # Unity Catalog SQL functions
│   ├── agent.py                          # LangGraph conversational agent
│   ├── driver.ipynb                      # Agent deployment & testing
│   ├── requirements.txt                  # Python dependencies
│   └── README.md                         # Detailed technical documentation
└── README.md                             # This file
```

## 🚀 Quick Start

### Prerequisites

- Databricks workspace with Unity Catalog enabled
- Access to Databricks Foundation Model APIs
- Vector Search endpoint configured
- ML Runtime 13.3 LTS or higher

### Setup Instructions

1. **Clone and Upload**:
   ```bash
   # Upload the entire project to your Databricks workspace
   # Ensure all notebooks are in the same directory
   ```

2. **Configure Parameters**:
   ```python
   # Set these parameters in each notebook
   catalog = "conversational_commerce_search"
   schema = "content_based_rec"
   vector_search_endpoint = "your-vector-search-endpoint"
   model_serving_endpoint = "databricks-bge-large-en"
   ```

3. **Run Notebooks in Sequence**:
   ```
   01_data_generation.ipynb       → Generate synthetic e-commerce data
   02_vector_index_generation.ipynb → Create embeddings and vector indexes
   03_uc_function_tools.py        → Deploy Unity Catalog functions
   driver.ipynb                   → Deploy and test the conversational agent
   ```

4. **Deploy the Agent**:
   ```python
   # The driver notebook will:
   # - Log the agent to MLflow
   # - Register to Unity Catalog
   # - Deploy as a serving endpoint
   ```

## 🎯 Key Features

### Conversational AI Agent

- **Natural Language Processing**: Understands product search queries in plain English
- **Context Awareness**: Maintains conversation history and user preferences
- **Tool Integration**: Uses Unity Catalog functions for data access
- **Fuzzy Matching**: Handles typos and abbreviations in product categories
- **Text-Based Interface**: Clean, intuitive chat interface for product discovery

### Content-Based Filtering System

- **Synthetic Data**: 10,000+ products, 100 customers, 50,000+ interactions
- **Rich Product Features**: Categories, brands, descriptions, ratings, pricing
- **User Profiles**: Diverse customer personas with realistic preferences
- **Interaction Tracking**: Views, purchases, ratings, cart additions

### Vector Search & Embeddings

- **Semantic Embeddings**: BGE-Large model for superior text understanding
- **Product Vectors**: Rich text representations including descriptions and features
- **User Vectors**: Computed from interaction history and preferences
- **Real-time Search**: Unity Catalog Vector Search for fast similarity matching

### Unity Catalog Functions

- **`recommend_products_for_user`**: Personalized recommendations using vector similarity
- **`recommend_products_fuzzy_category`**: Category-aware search with fuzzy matching
- **Serverless Execution**: Scalable SQL functions for production deployment

## 📊 Data Model

### Products Table
```sql
- product_id: Unique identifier
- name: Product name
- category/subcategory: Hierarchical classification
- brand: Product brand
- price: Pricing information
- description: Rich text description
- features: JSON-encoded product attributes
- avg_rating: Customer ratings
```

### Customers Table
```sql
- customer_id: Unique identifier
- persona: Customer type (Tech Enthusiast, Fashion Forward, etc.)
- preferred_categories: Comma-separated preferences
- price_sensitivity: Budget awareness level
- brand_loyalty: Brand preference strength
```

### Interactions Table
```sql
- interaction_type: view, cart_add, purchase, rating, review
- timestamp: Interaction time
- rating: Customer rating (if applicable)
- purchase_amount: Transaction value
```

## 🤖 Conversational Commerce Agent Capabilities

### Natural Language Shopping Queries

The AI shopping assistant understands diverse conversational patterns and shopping contexts:

#### Product Discovery
- **Specific Needs**: "I need wireless headphones for working out"
- **Gift Shopping**: "What's a good birthday gift for a tech enthusiast under $200?"
- **Comparison Shopping**: "Show me the difference between iPhone and Samsung phones"
- **Budget-Conscious**: "Find me the best laptop for students under $800"

#### Contextual Shopping
- **Seasonal Needs**: "I need winter clothes for my upcoming ski trip"
- **Lifestyle-Based**: "Recommend home office furniture for remote work"
- **Problem-Solving**: "My old phone battery dies quickly, what should I buy?"
- **Trend-Following**: "What are the most popular fitness gadgets right now?"

#### Conversational Commerce Features
- **Follow-up Questions**: "Do you need accessories with that?" or "What's your preferred color?"
- **Alternative Suggestions**: "This item is out of stock, but here are similar options"
- **Bundle Recommendations**: "Customers who bought this also purchased..."
- **Price Negotiation**: "I can find you a similar item within your budget"

### Shopping Assistant Behavior

#### Personalization Engine
- **Purchase History Analysis**: Learns from past customer interactions and preferences
- **Behavioral Patterns**: Adapts to shopping frequency, price sensitivity, and brand loyalty
- **Contextual Memory**: Remembers conversation context across multiple interactions
- **Preference Learning**: Continuously improves recommendations based on customer feedback

#### Commerce-Specific Intelligence
- **Inventory Awareness**: Considers stock levels and availability in recommendations
- **Price Optimization**: Balances customer budget with product quality and features
- **Cross-Selling Logic**: Intelligently suggests complementary products and accessories
- **Seasonal Adaptation**: Adjusts recommendations based on time of year and trends

#### Conversation Management
- **Multi-Turn Dialogue**: Maintains context across extended shopping conversations
- **Clarification Requests**: Asks follow-up questions to better understand customer needs
- **Graceful Fallbacks**: Provides alternatives when specific requests cannot be fulfilled
- **Shopping Journey Guidance**: Guides customers through the entire purchase decision process

## 🔍 Text-Based Search Interface

### Natural Language Search Capabilities

The platform provides intelligent text-based product discovery:

- **⌨️ Text Input**: Type natural language queries in the chat interface
- **🔄 Real-time Processing**: Instant query understanding and product matching
- **🔗 Seamless Integration**: Text input flows through the recommendation pipeline
- **📱 Responsive Design**: Clean, Google-inspired interface for optimal user experience
- **♿ Accessibility**: Simple text-based interaction for all users

### Search Workflow

```mermaid
graph LR
    A[⌨️ Text Input] --> B[📝 Query Processing]
    B --> C[🧠 LLM Understanding]
    C --> D[🔍 Vector Search]
    D --> E[🤖 Commerce Agent]
    E --> F[🛍️ Product Recommendations]
    
    style A fill:#e1f5fe
    style C fill:#fff3e0
    style F fill:#f1f8e9
```

### Example Text Queries

**Personalized Search:**
- *"Show me wireless headphones under 350 dollars"*
- *"Find me fiction books from Penguin"*

**General Search:**
- *"Show me electronics under 150 dollars"*
- *"Show me camping gear under $100"*
- *"Find me books similar to what I bought before"*

### Setup Requirements

1. **Databricks Workspace**: Unity Catalog and Model Serving enabled
2. **Environment Variables**: Serving endpoint and warehouse configuration
3. **Dependencies**: `streamlit`, `databricks-sdk`, `mlflow`

## 🔧 Technical Implementation

### Embedding Pipeline

1. **Text Generation**: Combines product name, brand, category, description, keywords
2. **Batch Processing**: Processes embeddings in batches of 150 for API efficiency
3. **Vector Storage**: Stores in Delta tables with change data feed enabled
4. **Index Creation**: Populates Unity Catalog Vector Search indexes

### Agent Architecture

1. **LangGraph Workflow**: State-based conversation management
2. **Tool Binding**: Integration with Unity Catalog functions
3. **System Prompt**: Specialized instructions for commerce recommendations
4. **Streaming Support**: Real-time response generation

### Deployment Pipeline

1. **MLflow Logging**: Tracks agent code and dependencies
2. **Unity Catalog Registration**: Versioned model management
3. **Serving Endpoint**: Production-ready API deployment
4. **Resource Dependencies**: Automatic authentication passthrough

## 📈 Performance & Scalability

### Vector Search Performance
- **Index Type**: Delta Sync with triggered updates
- **Embedding Dimension**: 1024 (BGE-Large)
- **Search Latency**: Sub-second response times
- **Concurrent Users**: Scales with Databricks compute

### Data Processing
- **Synthetic Scale**: 10K products, 100 customers, 50K interactions
- **Real-world Ready**: Designed for production data volumes
- **Delta Lake**: ACID transactions and time travel
- **Change Data Feed**: Incremental updates for vector indexes

## 🛠️ Development & Testing

### Local Testing
```python
# Test the agent locally
from agent import AGENT

response = AGENT.predict({
    "messages": [{"role": "user", "content": "Recommend headphones for cust_001"}]
})
```

### Production Deployment
```python
# Deploy via Databricks Agents
from databricks import agents
agents.deploy(UC_MODEL_NAME, version, tags={"endpointSource": "playground"})
```

## 📋 Next Steps

### Production Enhancements
1. **Real Data Integration**: Connect to actual product catalogs and user data
2. **Advanced NLP**: Implement intent recognition and entity extraction
3. **Multi-modal Search**: Add image-based product search capabilities
4. **A/B Testing**: Framework for recommendation algorithm optimization

### Scalability Improvements
1. **Streaming Updates**: Real-time embedding updates for new products
2. **Hybrid Recommendations**: Combine content-based with collaborative filtering
3. **Contextual Features**: Location, time, and device-based personalization
4. **Performance Monitoring**: Comprehensive observability and alerting

### User Experience
1. **Web Interface**: Customer-facing chat application with intelligent text search ✅ **IMPLEMENTED**
2. **Mobile Integration**: Native mobile app support
3. **Visual Search**: Image-based product matching
4. **Advanced Filtering**: Smart category and price-based filtering

## 🤝 Contributing

This project demonstrates modern AI-powered commerce search capabilities on Databricks. To adapt for production:

1. Replace synthetic data with your actual product catalog and user interactions
2. Customize the embedding pipeline for your domain-specific features
3. Tune the agent prompts and tools for your business requirements
4. Implement proper security, privacy, and compliance measures

## 📄 License

This project is for educational and demonstration purposes. Please ensure compliance with your organization's data and privacy policies when adapting for production use.

---

**Built with ❤️ on Databricks**

For questions or support, please refer to the [Databricks documentation](https://docs.databricks.com/generative-ai/agent-framework/) or contact your Databricks representative.