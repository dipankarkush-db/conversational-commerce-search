from typing import Any, Generator, Optional, Sequence, Union
from langchain.tools import Tool
import mlflow
from databricks_langchain import ChatDatabricks
from databricks_langchain.uc_ai import (
    DatabricksFunctionClient,
    UCFunctionToolkit,
    set_uc_function_client,
)
from langchain_core.language_models import LanguageModelLike
from langchain_core.runnables import RunnableConfig, RunnableLambda
from langchain_core.tools import BaseTool
from langgraph.graph import END, StateGraph
from langgraph.graph.graph import CompiledGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt.tool_node import ToolNode
from mlflow.langchain.chat_agent_langgraph import ChatAgentState, ChatAgentToolNode
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
import re

mlflow.langchain.autolog()

client = DatabricksFunctionClient()
set_uc_function_client(client)

############################################
# Define your LLM endpoint and system prompt
############################################
#LLM_ENDPOINT_NAME = "databricks-claude-3-7-sonnet"
# LLM_ENDPOINT_NAME = "databricks-claude-sonnet-4-5"
#LLM_ENDPOINT_NAME = "llama_v3_3_70b_instruct_pt"
LLM_ENDPOINT_NAME = "databricks-meta-llama-3-3-70b-instruct"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME)

system_prompt = f"""                
                You are a product recommendation agent for conversational commerce.

TOOLS:
- get_smart_product_recommendations: Get personalized recommendations (use customer name, email, search query, brand, min/max price)
- product_lookup_by_description: Look up specific products by description
- get_random_customer_info: Get a random customer if none provided
- get_customer_interactions: Get customer history

RULES:
1. Call tools ONCE per query, then respond immediately
2. For customer queries with name/email: call get_smart_product_recommendations directly
3. Format response: "Based on your preferences, I recommend:\n\n**Category - Subcategory:**\n1. Product Name - $Price (Rating) - Brief description"
4. Group products by category in response
5. Honor price/brand filters from user query
6. If no customer context: call get_random_customer_info first
7. Use this example to form the tool call. If a search query says - "Show me cloths under 250 $ from Zara" from a customer named "Dawn Smith" and customer email "griffinheidi@example.org" you will call the get_smart_product_recommendations () tool with the following parameters -
        (
            "input_customer_name": "Dawn Smith",
            "input_customer_email": "griffinheidi@example.org",
            "input_product_description": "cloths",
            "input_brand": "Zara",
            "input_max_price": 250
        )

RESPONSE FORMAT EXAMPLE:
Based on your preferences, I recommend the following products for your camping trip:

**Sports & Outdoors - Camping:**
1. Under Armour Camping West - $105.01 (4.7/5) - Water-resistant with multiple compartments

Would you like more details on any item?

Keep responses concise and helpful.  
    """

tools = []

# You can use UDFs in Unity Catalog as agent tools
uc_tool_names = [
    "retail_consumer_goods.conversational_commerce_search.get_smart_product_recommendations",
    "retail_consumer_goods.conversational_commerce_search.product_lookup_by_description",
    "retail_consumer_goods.conversational_commerce_search.validate_customer_by_name",
    "retail_consumer_goods.conversational_commerce_search.get_customer_interactions",
    "retail_consumer_goods.conversational_commerce_search.get_random_customer_info",
]
uc_toolkit = UCFunctionToolkit(function_names=uc_tool_names)
tools.extend(uc_toolkit.tools)


def create_tool_calling_agent(
    model: LanguageModelLike,
    tools: Union[Sequence[BaseTool], ToolNode],
    system_prompt: Optional[str] = None,
) -> CompiledGraph:
    model = model.bind_tools(tools)

    # Define the function that determines which node to go to
    def should_continue(state: ChatAgentState):
        messages = state["messages"]
        last_message = messages[-1]
        # If there are function calls, continue. else, end
        if last_message.get("tool_calls"):
            return "continue"
        else:
            return "end"

    if system_prompt:
        preprocessor = RunnableLambda(
            lambda state: [{"role": "system", "content": system_prompt}]
            + state["messages"]
        )
    else:
        preprocessor = RunnableLambda(lambda state: state["messages"])
    model_runnable = preprocessor | model

    def call_model(
        state: ChatAgentState,
        config: RunnableConfig,
    ):
        response = model_runnable.invoke(state, config)

        return {"messages": [response]}

    workflow = StateGraph(ChatAgentState)

    workflow.add_node("agent", RunnableLambda(call_model))
    workflow.add_node("tools", ChatAgentToolNode(tools))

    workflow.set_entry_point("agent")
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "continue": "tools",
            "end": END,
        },
    )
    workflow.add_edge("tools", "agent")

    return workflow.compile()


class LangGraphChatAgent(ChatAgent):
    def __init__(self, agent: CompiledStateGraph):
        self.agent = agent

    def predict(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> ChatAgentResponse:
        request = {"messages": self._convert_messages_to_dict(messages)}

        messages = []
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                messages.extend(
                    ChatAgentMessage(**msg) for msg in node_data.get("messages", [])
                )
        return ChatAgentResponse(messages=messages)

    def predict_stream(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> Generator[ChatAgentChunk, None, None]:
        request = {"messages": self._convert_messages_to_dict(messages)}
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                yield from (
                    ChatAgentChunk(**{"delta": msg}) for msg in node_data["messages"]
                )


# Create the agent object, and specify it as the agent object to use when
# loading the agent back for inference via mlflow.models.set_model()
agent = create_tool_calling_agent(llm, tools, system_prompt)
AGENT = LangGraphChatAgent(agent)
mlflow.models.set_model(AGENT)
