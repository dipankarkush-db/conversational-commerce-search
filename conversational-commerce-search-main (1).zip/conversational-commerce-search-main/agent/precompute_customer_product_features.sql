-- Materialize per-customer/product interaction features to avoid recomputing them at query time.
-- Run this notebook (or schedule it as a Delta Live Table / workflow) before calling the recommendation UDF.

USE CATALOG retail_consumer_goods;
USE retail_consumer_goods.conversational_commerce_search;

CREATE TABLE IF NOT EXISTS retail_consumer_goods.conversational_commerce_search.customer_product_interaction_features (
    customer_id STRING,
    product_id STRING,
    interaction_count BIGINT,
    last_interaction_ts TIMESTAMP,
    avg_customer_rating DOUBLE,
    latest_interaction_type STRING,
    interaction_recency_days INT
) USING DELTA
TBLPROPERTIES (
    delta.enableChangeDataFeed = true
);

MERGE INTO retail_consumer_goods.conversational_commerce_search.customer_product_interaction_features AS target
USING (
    WITH base_interactions AS (
        SELECT
            customer_id,
            product_id,
            interaction_type,
            rating,
            timestamp
        FROM retail_consumer_goods.conversational_commerce_search.interactions
    ),
    aggregated AS (
        SELECT
            customer_id,
            product_id,
            COUNT(*) AS interaction_count,
            MAX(timestamp) AS last_interaction_ts,
            AVG(CASE WHEN rating IS NOT NULL THEN rating END) AS avg_customer_rating
        FROM base_interactions
        GROUP BY customer_id, product_id
    ),
    latest AS (
        SELECT DISTINCT
            customer_id,
            product_id,
            FIRST_VALUE(interaction_type) OVER (
                PARTITION BY customer_id, product_id
                ORDER BY timestamp DESC
            ) AS latest_interaction_type
        FROM base_interactions
    )
    SELECT
        a.customer_id,
        a.product_id,
        a.interaction_count,
        a.last_interaction_ts,
        COALESCE(a.avg_customer_rating, 0.0) AS avg_customer_rating,
        l.latest_interaction_type,
        DATEDIFF(CURRENT_DATE(), DATE(a.last_interaction_ts)) AS interaction_recency_days
    FROM aggregated a
    LEFT JOIN latest l
        ON a.customer_id = l.customer_id
       AND a.product_id = l.product_id
) AS source
ON target.customer_id = source.customer_id
AND target.product_id = source.product_id
WHEN MATCHED THEN UPDATE SET
    target.interaction_count = source.interaction_count,
    target.last_interaction_ts = source.last_interaction_ts,
    target.avg_customer_rating = source.avg_customer_rating,
    target.latest_interaction_type = source.latest_interaction_type,
    target.interaction_recency_days = source.interaction_recency_days
WHEN NOT MATCHED THEN INSERT (
    customer_id,
    product_id,
    interaction_count,
    last_interaction_ts,
    avg_customer_rating,
    latest_interaction_type,
    interaction_recency_days
) VALUES (
    source.customer_id,
    source.product_id,
    source.interaction_count,
    source.last_interaction_ts,
    source.avg_customer_rating,
    source.latest_interaction_type,
    source.interaction_recency_days
);

