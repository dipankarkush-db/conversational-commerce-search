-- Optimized definition of get_smart_product_recommendations
CREATE OR REPLACE FUNCTION get_smart_product_recommendations(
    input_customer_name STRING COMMENT "Customer's name",
    input_customer_email STRING COMMENT "Customer's email for precise identification (recommended to avoid name conflicts)",
    input_product_description STRING COMMENT "Description of what the customer is looking for (e.g., 'outdoor camping gear', 'fiction books', 'wireless headphones')",
    input_brand STRING DEFAULT NULL COMMENT "Brand filter (e.g., 'penguin', 'nike', 'apple') - uses fuzzy matching",
    input_min_price DOUBLE DEFAULT NULL COMMENT "Minimum price filter (e.g., 10.0 for products above 10 $)",
    input_max_price DOUBLE DEFAULT NULL COMMENT "Maximum price filter (e.g., 20.0 for products under 20 $)"
)
RETURNS TABLE(
    customer_name STRING COMMENT "Customer's name",
    customer_email STRING COMMENT "Customer's email",
    product_id STRING COMMENT "Product's unique identifier",
    product_name STRING COMMENT "Product's name",
    category STRING COMMENT "Product's category",
    subcategory STRING COMMENT "Product's subcategory",
    brand STRING COMMENT "Product's brand",
    price DOUBLE COMMENT "Product's price",
    description STRING COMMENT "Product's description",
    avg_rating DOUBLE COMMENT "Product's average rating",
    recommendation_score DOUBLE COMMENT "Combined recommendation score (higher is better)",
    recommendation_reason STRING COMMENT "Explanation of why this product was recommended",
    brand_match_score DOUBLE COMMENT "Brand similarity score (if brand filter applied)",
    price_in_range BOOLEAN COMMENT "Whether product price meets the specified criteria"
)
COMMENT "Optimized smart recommendation function that limits runtime to vector-derived candidates, applies reusable brand/price filters, and joins pre-filtered interaction history for faster results."
LANGUAGE SQL
RETURN
    WITH customer_context AS (
        SELECT 
            c.customer_id,
            c.name AS customer_name,
            c.email AS customer_email,
            uf.embedding
        FROM retail_consumer_goods.conversational_commerce_search.customers c
        JOIN retail_consumer_goods.conversational_commerce_search.user_features uf
            ON c.customer_id = uf.customer_id
        WHERE LOWER(c.email) = LOWER(input_customer_email)
          AND ai_similarity(c.name, input_customer_name) > 0.9
        LIMIT 1
    ),
    similar_users AS (
        SELECT 
            CAST(sp.customer_id AS STRING) AS similar_customer_id,
            sp.search_score AS similarity_score
        FROM customer_context cc
        CROSS JOIN VECTOR_SEARCH(
            index => 'retail_consumer_goods.conversational_commerce_search.user_index',
            query_vector => (SELECT embedding FROM customer_context),
            num_results => 20
        ) sp
        WHERE sp.customer_id <> cc.customer_id
    ),
    neighbor_candidates AS (
        SELECT 
            product_id,
            neighbor_signal,
            neighbor_avg_rating
        FROM (
            SELECT 
                cpf.product_id,
                SUM(cpf.interaction_count * su.similarity_score) AS neighbor_signal,
                MAX(cpf.avg_customer_rating) AS neighbor_avg_rating
            FROM retail_consumer_goods.conversational_commerce_search.customer_product_interaction_features cpf
            JOIN similar_users su
                ON cpf.customer_id = su.similar_customer_id
            GROUP BY cpf.product_id
        )
        ORDER BY neighbor_signal DESC
        LIMIT 50
    ),
    vector_recommendations AS (
        SELECT 
            sp.product_id,
            sp.search_score AS vector_score
        FROM VECTOR_SEARCH(
            index => 'retail_consumer_goods.conversational_commerce_search.product_index',
            query_vector => (SELECT embedding FROM customer_context),
            num_results => 50
        ) sp
    ),
    description_recommendations AS (
        SELECT 
            sp.product_id,
            sp.search_score AS description_score
        FROM VECTOR_SEARCH(
            index => 'retail_consumer_goods.conversational_commerce_search.product_desc_index',
            query_text => input_product_description,
            num_results => 50
        ) sp
    ),
    candidate_products AS (
        SELECT product_id, vector_score, NULL AS description_score, NULL AS neighbor_signal, NULL AS neighbor_avg_rating
        FROM vector_recommendations
        UNION ALL
        SELECT product_id, NULL, description_score, NULL, NULL
        FROM description_recommendations
        UNION ALL
        SELECT product_id, NULL, NULL, neighbor_signal, neighbor_avg_rating
        FROM neighbor_candidates
    ),
    merged_candidates AS (
        SELECT 
            product_id,
            MAX(vector_score) AS vector_score,
            MAX(description_score) AS description_score,
            MAX(neighbor_signal) AS neighbor_signal,
            MAX(neighbor_avg_rating) AS neighbor_avg_rating
        FROM candidate_products
        GROUP BY product_id
    ),
    product_features AS (
        SELECT 
            mc.product_id,
            p.name AS product_name,
            p.category,
            p.subcategory,
            p.brand,
            p.price,
            p.description,
            p.avg_rating,
            mc.vector_score,
            mc.description_score,
            COALESCE(mc.neighbor_signal, 0.0) AS neighbor_signal,
            COALESCE(mc.neighbor_avg_rating, 0.0) AS neighbor_avg_rating,
            CASE 
                WHEN input_brand IS NULL THEN 1.0
                ELSE ai_similarity(p.brand, input_brand)
            END AS brand_match_score,
            CASE 
                WHEN input_min_price IS NOT NULL AND input_max_price IS NOT NULL THEN (p.price BETWEEN input_min_price AND input_max_price)
                WHEN input_min_price IS NOT NULL THEN (p.price >= input_min_price)
                WHEN input_max_price IS NOT NULL THEN (p.price <= input_max_price)
                ELSE TRUE
            END AS price_in_range
        FROM merged_candidates mc
        JOIN retail_consumer_goods.conversational_commerce_search.products p
            ON mc.product_id = p.product_id
        WHERE p.in_stock = TRUE
    ),
    filtered_products AS (
        SELECT *
        FROM product_features
        WHERE price_in_range
          AND (input_brand IS NULL OR brand_match_score > 0.7)
    ),
    scored_recommendations AS (
        SELECT
            cc.customer_name,
            cc.customer_email,
            fp.product_id,
            fp.product_name,
            fp.category,
            fp.subcategory,
            fp.brand,
            fp.price,
            fp.description,
            fp.avg_rating,
            fp.brand_match_score,
            fp.price_in_range,
            fp.vector_score,
            fp.description_score,
            fp.neighbor_signal,
            fp.neighbor_avg_rating,
            COALESCE(cif.interaction_count, 0) AS interaction_count,
            COALESCE(cif.avg_customer_rating, 0) AS customer_rating,
            COALESCE(cif.latest_interaction_type, 'No previous interaction') AS latest_interaction_type,
            (
                COALESCE(fp.vector_score, 0) * 0.3 +
                COALESCE(fp.description_score, 0) * 0.25 +
                CASE WHEN COALESCE(cif.interaction_count, 0) > 0 THEN 0.15 ELSE 0 END +
                (fp.avg_rating / 5.0) * 0.1 +
                CASE WHEN input_brand IS NOT NULL THEN fp.brand_match_score * 0.1 ELSE 0 END +
                (LEAST(COALESCE(fp.neighbor_signal, 0), 25) / 25.0) * 0.1
            ) AS recommendation_score,
            CASE 
                WHEN COALESCE(cif.interaction_count, 0) > 0 
                     AND COALESCE(fp.description_score, 0) > 0.7
                     AND input_brand IS NOT NULL 
                     AND fp.brand_match_score > 0.8 THEN 
                    CONCAT('Previously interacted with similar products (', COALESCE(cif.interaction_count, 0), ' times), matches "', input_product_description, '", and from preferred brand "', input_brand, '"')
                WHEN COALESCE(cif.interaction_count, 0) > 0 
                     AND COALESCE(fp.description_score, 0) > 0.7 THEN 
                    CONCAT('Previously interacted with similar products (', COALESCE(cif.interaction_count, 0), ' times) and matches your search for "', input_product_description, '"')
                WHEN COALESCE(cif.interaction_count, 0) > 0 
                     AND input_brand IS NOT NULL 
                     AND fp.brand_match_score > 0.8 THEN 
                    CONCAT('Based on your previous interactions with similar products (', COALESCE(cif.interaction_count, 0), ' times) and from brand "', input_brand, '"')
                WHEN COALESCE(fp.description_score, 0) > 0.7 
                     AND input_brand IS NOT NULL 
                     AND fp.brand_match_score > 0.8 THEN 
                    CONCAT('Matches your search for "', input_product_description, '" from brand "', input_brand, '"')
                WHEN COALESCE(cif.interaction_count, 0) > 0 THEN 
                    CONCAT('Based on your previous interactions with similar products (', COALESCE(cif.interaction_count, 0), ' times)')
                WHEN COALESCE(fp.neighbor_signal, 0) > 0 THEN 
                    'Popular among customers with similar profiles'
                WHEN COALESCE(fp.description_score, 0) > 0.7 THEN 
                    CONCAT('Matches your search for "', input_product_description, '" (', ROUND(COALESCE(fp.description_score, 0), 2), ' similarity)')
                WHEN input_brand IS NOT NULL AND fp.brand_match_score > 0.8 THEN 
                    CONCAT('From your preferred brand "', input_brand, '"')
                WHEN COALESCE(fp.vector_score, 0) > 0.8 THEN 
                    'Highly similar to your preferences based on browsing history'
                ELSE 
                    'Recommended based on your overall preferences'
            END AS recommendation_reason
        FROM customer_context cc
        JOIN filtered_products fp ON TRUE
        LEFT JOIN retail_consumer_goods.conversational_commerce_search.customer_product_interaction_features cif
            ON cc.customer_id = cif.customer_id
           AND fp.product_id = cif.product_id
    )
    SELECT 
        customer_name,
        customer_email,
        product_id,
        product_name,
        category,
        subcategory,
        brand,
        price,
        description,
        avg_rating,
        recommendation_score,
        recommendation_reason,
        brand_match_score,
        price_in_range
    FROM scored_recommendations
    ORDER BY recommendation_score DESC
    LIMIT 25;

