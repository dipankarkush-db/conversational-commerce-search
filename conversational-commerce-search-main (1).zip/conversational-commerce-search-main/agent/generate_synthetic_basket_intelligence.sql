-- Generate Synthetic Basket Intelligence Data
-- This creates frequently-bought-together product pairs for each customer
-- based on their purchase history and preferences

USE CATALOG retail_consumer_goods;
USE SCHEMA conversational_commerce_search;

-- Drop and recreate the basket intelligence table with synthetic data
CREATE OR REPLACE TABLE retail_consumer_goods.conversational_commerce_search.customer_basket_intelligence
USING DELTA
COMMENT 'Customer-level product affinity pairs derived from purchase baskets (synthetic)'
TBLPROPERTIES (
  delta.enableChangeDataFeed = true
)
AS
WITH customer_purchases AS (
    -- Get all customers and their purchased products
    SELECT DISTINCT
        i.customer_id,
        c.name AS customer_name,
        i.product_id,
        p.name AS product_name,
        p.category,
        p.subcategory
    FROM retail_consumer_goods.conversational_commerce_search.interactions i
    JOIN retail_consumer_goods.conversational_commerce_search.products p 
        ON i.product_id = p.product_id
    JOIN retail_consumer_goods.conversational_commerce_search.customers c
        ON i.customer_id = c.customer_id
    WHERE LOWER(i.interaction_type) = 'purchase'
),
customer_product_pairs AS (
    -- Create product pairs for each customer (cartesian product of their purchases)
    SELECT
        cp1.customer_id,
        cp1.customer_name,
        cp1.product_id AS anchor_product_id,
        cp1.product_name AS anchor_product_name,
        cp2.product_id AS associated_product_id,
        cp2.product_name AS associated_product_name,
        -- Products from same category are more likely to be bought together
        CASE 
            WHEN cp1.category = cp2.category THEN 0.7
            ELSE 0.3
        END AS base_affinity
    FROM customer_purchases cp1
    JOIN customer_purchases cp2
        ON cp1.customer_id = cp2.customer_id
        AND cp1.product_id < cp2.product_id  -- Avoid duplicates (A,B) and (B,A)
),
synthetic_pairs AS (
    -- Generate synthetic purchase counts and affinity scores
    SELECT
        customer_id,
        customer_name,
        anchor_product_id,
        anchor_product_name,
        associated_product_id,
        associated_product_name,
        -- Random pair count between 1 and 5
        CAST(FLOOR(rand() * 5) + 1 AS INT) AS pair_count,
        -- Affinity score based on base affinity + some randomness
        ROUND(base_affinity * (0.5 + rand() * 0.5), 4) AS affinity_share,
        CURRENT_TIMESTAMP() AS last_seen_purchase_ts
    FROM customer_product_pairs
    -- Add some randomness - not all product pairs should appear
    WHERE rand() > 0.7  -- Only keep 30% of possible pairs to make it realistic
),
ranked_pairs AS (
    -- Rank pairs by affinity for each customer and anchor product
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY customer_id, anchor_product_id
            ORDER BY affinity_share DESC, associated_product_id
        ) AS affinity_rank
    FROM synthetic_pairs
)
-- Keep top 5 associated products for each anchor product per customer
SELECT
    customer_id,
    customer_name,
    anchor_product_id,
    anchor_product_name,
    associated_product_id,
    associated_product_name,
    pair_count,
    affinity_share,
    last_seen_purchase_ts,
    affinity_rank
FROM ranked_pairs
WHERE affinity_rank <= 5
ORDER BY customer_id, anchor_product_id, affinity_rank;

-- Verify the data
SELECT 
    COUNT(DISTINCT customer_id) AS num_customers_with_baskets,
    COUNT(*) AS total_basket_pairs,
    ROUND(AVG(pair_count), 2) AS avg_pair_count,
    ROUND(AVG(affinity_share), 4) AS avg_affinity_share
FROM retail_consumer_goods.conversational_commerce_search.customer_basket_intelligence;

-- Show sample data for first customer
SELECT *
FROM retail_consumer_goods.conversational_commerce_search.customer_basket_intelligence
LIMIT 10;

