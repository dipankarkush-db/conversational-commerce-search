"""
Quick Performance Test for get_smart_product_recommendations

Simple script to measure execution time of a single function call.
Perfect for quick testing during development.

Usage in Databricks Notebook:
    Copy and paste into a Python cell
"""

import time

def quick_test(
    customer_name="Peter Bryant",
    customer_email="heidi18@example.net", 
    search_query="fictional books",
    brand=None,
    min_price=None,
    max_price=None
):
    """
    Quick performance test for get_smart_product_recommendations
    
    Example usage:
        quick_test("Peter Bryant", "heidi18@example.net", "outdoor gear")
        quick_test("Raymond Roberts", "raymond@example.com", "gaming laptop", brand="HP", max_price=1000)
    """
    
    # Build parameters
    brand_param = f"'{brand}'" if brand else "NULL"
    min_price_param = str(min_price) if min_price else "NULL"
    max_price_param = str(max_price) if max_price else "NULL"
    
    print(f"\n{'='*70}")
    print(f"⏱️  PERFORMANCE TEST")
    print(f"{'='*70}")
    print(f"Customer: {customer_name}")
    print(f"Email: {customer_email}")
    print(f"Search: {search_query}")
    if brand:
        print(f"Brand: {brand}")
    if min_price or max_price:
        price_str = ""
        if min_price and max_price:
            price_str = f"${min_price} - ${max_price}"
        elif min_price:
            price_str = f">= ${min_price}"
        else:
            price_str = f"<= ${max_price}"
        print(f"Price Range: {price_str}")
    print(f"{'='*70}\n")
    
    # Start timer
    start = time.time()
    
    # Execute query
    query = f"""
    SELECT 
        product_name,
        brand,
        price,
        category,
        recommendation_score,
        recommendation_reason
    FROM get_smart_product_recommendations(
        "{customer_name}", 
        "{customer_email}", 
        "{search_query}", 
        {brand_param}, 
        {min_price_param}, 
        {max_price_param}
    )
    ORDER BY recommendation_score DESC
    """
    
    df = spark.sql(query)
    count = df.count()
    
    # End timer
    end = time.time()
    duration = end - start
    
    # Format time
    if duration < 1:
        time_str = f"{duration*1000:.2f} milliseconds"
    else:
        time_str = f"{duration:.2f} seconds"
    
    # Display results
    print(f"✅ COMPLETED in {time_str}")
    print(f"📦 Found {count} products\n")
    
    if count > 0:
        print("📋 Top 10 Results:")
        print("-" * 70)
        df.select(
            "product_name", 
            "brand", 
            "price", 
            "recommendation_score"
        ).show(10, truncate=False)
    
    return df, duration

# Example: Run a quick test
# Uncomment below to run:
# df, time_taken = quick_test()

