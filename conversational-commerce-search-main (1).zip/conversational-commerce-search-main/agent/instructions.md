# Right now I have this code base inside the folder "/Users/dipankar.kushari/Library/CloudStorage/GoogleDrive-dipankar.kushari@databricks.com/My Drive/10x/conversational-commerce-search/agent" which creates the data in delta format for product, customer, customer interaction and builds on top of that to create a customer profile using "/Users/dipankar.kushari/Library/CloudStorage/GoogleDrive-dipankar.kushari@databricks.com/My Drive/10x/conversational-commerce-search/agent/01_data_generation.ipynb" 

# Using "/Users/dipankar.kushari/Library/CloudStorage/GoogleDrive-dipankar.kushari@databricks.com/My Drive/10x/conversational-commerce-search/agent/02_vector_index_generation.ipynb" it creates vector search index from the above mentioned delta tables

# tables -
1. customers
2. interactions
3. product_features
4. products
5. user_features

Vector index
1. user_index
2. product_desc_index
3. product_index

# "/Users/dipankar.kushari/Library/CloudStorage/GoogleDrive-dipankar.kushari@databricks.com/My Drive/10x/conversational-commerce-search/agent/03_uc_function_tools.ipynb" creates the Unity Catalog functions which are then used as tools by the agent

# The main feature of the agent is to provide product recommendations. That function is get_smart_product_recommendations in "/Users/dipankar.kushari/Library/CloudStorage/GoogleDrive-dipankar.kushari@databricks.com/My Drive/10x/conversational-commerce-search/agent/03_uc_function_tools.ipynb"

# main purpose of get_smart_product_recommendations is to take a customer name (mandatory), email (mandatory), search description(manadatory), price (optional) and brand name (optional)  and look at the previous customer interactions, customer profile, products available and product features and generate a list of products that matches based on those factors when a specific customer enters a search description. The resultant rows are then shared with the agent and agent send the relevant information back to the caller

This is an example of the customer request for conversational commerce search -

{"messages": [
        {
            "role": "user", 
            "content": "Customer Name: Ronald Jackson, Customer email: ureed@example.com. I am moving to a new apartment and need to buy all the necessary items for my new apartment. I do not want them to be too expensive but durable. What do you suggest?"
        }
    ]
}

# Can you review the function "get_smart_product_recommendations" in "/Users/dipankar.kushari/Library/CloudStorage/GoogleDrive-dipankar.kushari@databricks.com/My Drive/10x/conversational-commerce-search/agent/03_uc_function_tools.ipynb", and suggest how this function can be made performance efficient? Currently the agent takes around on an average 20 seconds to respond to user query, out of which on an average 10 seconds for the "get_smart_product_recommendations" function call. I am trying to see how we could optimize the get_smart_product_recommendations functions which would potentially bring the response time down significantly.

Do not make any changes yet or add any new file(s). Just show your recommendations on the screen.



