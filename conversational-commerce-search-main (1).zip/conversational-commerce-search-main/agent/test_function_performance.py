"""
Performance Testing Script for get_smart_product_recommendations Function

This script measures the execution time of the get_smart_product_recommendations
function with various test cases to help identify performance bottlenecks.

Usage in Databricks Notebook:
    %run ./test_function_performance.py
"""

import time
from datetime import datetime
from pyspark.sql import SparkSession

# Initialize Spark session (if not already available)
try:
    spark
except NameError:
    spark = SparkSession.builder.getOrCreate()

def format_duration(seconds):
    """Format duration in a human-readable way"""
    if seconds < 1:
        return f"{seconds*1000:.2f} ms"
    elif seconds < 60:
        return f"{seconds:.2f} seconds"
    else:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.2f}s"

def test_function_performance(
    customer_name,
    customer_email,
    product_description,
    brand=None,
    min_price=None,
    max_price=None,
    test_name="Test"
):
    """
    Test the performance of get_smart_product_recommendations function
    
    Args:
        customer_name: Customer's name
        customer_email: Customer's email
        product_description: Search description
        brand: Optional brand filter
        min_price: Optional minimum price
        max_price: Optional maximum price
        test_name: Name of the test case
    
    Returns:
        dict: Results including execution time and row count
    """
    
    # Build the SQL query
    brand_param = f"'{brand}'" if brand else "NULL"
    min_price_param = str(min_price) if min_price else "NULL"
    max_price_param = str(max_price) if max_price else "NULL"
    
    query = f"""
    SELECT 
        customer_name,
        customer_email,
        product_name,
        category,
        subcategory,
        brand,
        price,
        recommendation_score,
        recommendation_reason
    FROM get_smart_product_recommendations(
        "{customer_name}", 
        "{customer_email}", 
        "{product_description}", 
        {brand_param}, 
        {min_price_param}, 
        {max_price_param}
    )
    ORDER BY recommendation_score DESC
    """
    
    # Measure execution time
    print(f"\n{'='*80}")
    print(f"🧪 {test_name}")
    print(f"{'='*80}")
    print(f"📋 Parameters:")
    print(f"   Customer: {customer_name} ({customer_email})")
    print(f"   Search: {product_description}")
    if brand:
        print(f"   Brand: {brand}")
    if min_price or max_price:
        price_range = f"   Price: "
        if min_price and max_price:
            price_range += f"${min_price} - ${max_price}"
        elif min_price:
            price_range += f">= ${min_price}"
        else:
            price_range += f"<= ${max_price}"
        print(price_range)
    
    print(f"\n⏱️  Executing query...")
    start_time = time.time()
    
    try:
        # Execute the query
        result_df = spark.sql(query)
        
        # Trigger execution by counting rows
        row_count = result_df.count()
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # Display results
        print(f"✅ Query completed successfully!")
        print(f"⏱️  Execution Time: {format_duration(execution_time)}")
        print(f"📊 Results: {row_count} products recommended")
        
        # Show top 5 results
        if row_count > 0:
            print(f"\n📦 Top 5 Recommendations:")
            top_results = result_df.limit(5).collect()
            for i, row in enumerate(top_results, 1):
                print(f"   {i}. {row['product_name']}")
                print(f"      Brand: {row['brand']} | Price: ${row['price']:.2f} | Score: {row['recommendation_score']:.3f}")
                print(f"      Reason: {row['recommendation_reason']}")
        
        return {
            "test_name": test_name,
            "execution_time": execution_time,
            "row_count": row_count,
            "status": "success"
        }
        
    except Exception as e:
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"❌ Query failed!")
        print(f"⏱️  Time before failure: {format_duration(execution_time)}")
        print(f"❌ Error: {str(e)}")
        
        return {
            "test_name": test_name,
            "execution_time": execution_time,
            "row_count": 0,
            "status": "failed",
            "error": str(e)
        }

def run_performance_test_suite():
    """
    Run a comprehensive test suite with multiple scenarios
    """
    print(f"\n{'#'*80}")
    print(f"🚀 PERFORMANCE TEST SUITE FOR get_smart_product_recommendations")
    print(f"{'#'*80}")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Define test cases
    test_cases = [
        {
            "test_name": "Test 1: Simple Search (Books)",
            "customer_name": "Peter Bryant",
            "customer_email": "heidi18@example.net",
            "product_description": "fictional books",
            "brand": None,
            "min_price": None,
            "max_price": None
        },
        {
            "test_name": "Test 2: Search with Brand Filter (Books + Penguin)",
            "customer_name": "Peter Bryant",
            "customer_email": "heidi18@example.net",
            "product_description": "fictional books",
            "brand": "penguin",
            "min_price": None,
            "max_price": 20
        },
        {
            "test_name": "Test 3: Search with Price Filter (Gaming Laptop < $1000)",
            "customer_name": "Raymond Roberts",
            "customer_email": "raymond.roberts@example.com",
            "product_description": "gaming laptop",
            "brand": "HP",
            "min_price": None,
            "max_price": 1000
        },
        {
            "test_name": "Test 4: General Search (Outdoor Gears)",
            "customer_name": "David Hawkins",
            "customer_email": "david.hawkins@example.com",
            "product_description": "outdoor gears",
            "brand": None,
            "min_price": None,
            "max_price": None
        },
        {
            "test_name": "Test 5: Vacation Books",
            "customer_name": "Susan Martin",
            "customer_email": "susan.martin@example.com",
            "product_description": "books for vacation",
            "brand": None,
            "min_price": None,
            "max_price": None
        }
    ]
    
    # Run all tests
    results = []
    for test_case in test_cases:
        result = test_function_performance(**test_case)
        results.append(result)
        time.sleep(1)  # Brief pause between tests
    
    # Summary Report
    print(f"\n{'='*80}")
    print(f"📊 PERFORMANCE TEST SUMMARY")
    print(f"{'='*80}")
    
    total_time = sum(r['execution_time'] for r in results)
    avg_time = total_time / len(results)
    successful_tests = sum(1 for r in results if r['status'] == 'success')
    
    print(f"\n📈 Overall Statistics:")
    print(f"   Total Tests: {len(results)}")
    print(f"   Successful: {successful_tests}")
    print(f"   Failed: {len(results) - successful_tests}")
    print(f"   Total Time: {format_duration(total_time)}")
    print(f"   Average Time: {format_duration(avg_time)}")
    print(f"   Min Time: {format_duration(min(r['execution_time'] for r in results))}")
    print(f"   Max Time: {format_duration(max(r['execution_time'] for r in results))}")
    
    print(f"\n📋 Detailed Results:")
    print(f"{'Test':<50} {'Time':<15} {'Rows':<10} {'Status':<10}")
    print(f"{'-'*85}")
    for result in results:
        test_name = result['test_name'][:48]
        time_str = format_duration(result['execution_time'])
        rows = str(result['row_count'])
        status = result['status']
        print(f"{test_name:<50} {time_str:<15} {rows:<10} {status:<10}")
    
    print(f"\n{'='*80}")
    print(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*80}\n")
    
    return results

# Main execution
if __name__ == "__main__":
    # Set catalog and schema
    spark.sql("USE CATALOG retail_consumer_goods")
    spark.sql("USE retail_consumer_goods.conversational_commerce_search")
    
    # Run the test suite
    results = run_performance_test_suite()

