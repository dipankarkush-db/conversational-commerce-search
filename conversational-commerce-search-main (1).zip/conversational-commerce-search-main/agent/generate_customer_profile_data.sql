-- Synthetic customer-profile feature generation for conversational commerce demos.
-- Prerequisites:
--   * The base tables retail_consumer_goods.conversational_commerce_search.customers,
--     retail_consumer_goods.conversational_commerce_search.products, and
--     retail_consumer_goods.conversational_commerce_search.interactions already exist
--     (they are produced by the 01_data_generation notebook).
--   * Run this script in a Databricks SQL environment connected to the same catalog/schema.

USE CATALOG retail_consumer_goods;
USE SCHEMA conversational_commerce_search;

-- 1) Generate synthetic browsing telemetry for each customer (mobile + web sessions).
CREATE OR REPLACE TABLE retail_consumer_goods.conversational_commerce_search.customer_browsing_events
USING DELTA
COMMENT 'Synthetic customer browsing sessions across app and web surfaces'
TBLPROPERTIES (
  delta.enableChangeDataFeed = true
)
AS
WITH customer_base AS (
    SELECT
        c.customer_id,
        c.name,
        c.email,
        c.persona,
        c.preferred_categories,
        c.registration_date,
        c.total_orders,
        c.total_spent,
        CASE
            WHEN trim(coalesce(c.preferred_categories, '')) = '' THEN array('General Discovery')
            ELSE transform(split(c.preferred_categories, ','), x -> trim(x))
        END AS pref_categories
    FROM retail_consumer_goods.conversational_commerce_search.customers c
),
expansion AS (
    SELECT
        cb.*,
        GREATEST(4, CAST(FLOOR(rand() * 5) + 4 AS INT)) AS event_target
    FROM customer_base cb
),
event_rows AS (
    SELECT
        e.customer_id,
        e.name,
        e.email,
        e.persona,
        e.pref_categories,
        posexplode(sequence(1, e.event_target)) AS (event_pos, event_index)
    FROM expansion e
),
raw_events AS (
    SELECT
        er.customer_id,
        CONCAT('sess_', substring(md5(CONCAT(er.customer_id, '_', CAST(er.event_index AS STRING))), 1, 16)) AS session_id,
        from_unixtime(unix_timestamp() - CAST(rand() * 86400 * 21 AS BIGINT)) AS event_timestamp,
        CASE WHEN rand() < 0.55 THEN 'mobile_app' ELSE 'website' END AS channel_value,
        CASE
            WHEN rand() < 0.45 THEN 'product_detail'
            WHEN rand() < 0.75 THEN 'search_results'
            WHEN rand() < 0.90 THEN 'category'
            ELSE 'home'
        END AS page_type_value,
        CASE
            WHEN size(er.pref_categories) = 0 THEN 'General Discovery'
            WHEN size(er.pref_categories) = 1 THEN er.pref_categories[0]
            ELSE er.pref_categories[CAST(FLOOR(rand() * size(er.pref_categories)) AS INT)]
        END AS focus_topic_raw,
        CAST(rand() * 280 + 40 AS INT) AS dwell_seconds,
        CAST(rand() * 80 + 15 AS INT) AS scroll_depth_pct
    FROM event_rows er
),
final_events AS (
    SELECT
        customer_id,
        session_id,
        event_timestamp,
        channel_value AS channel,
        page_type_value AS page_type,
        INITCAP(focus_topic_raw) AS focus_topic,
        CASE
            WHEN page_type_value = 'search_results' THEN CONCAT('best ', lower(focus_topic_raw))
            WHEN page_type_value = 'product_detail' THEN CONCAT(lower(focus_topic_raw), ' top picks')
            ELSE CONCAT('latest ', lower(focus_topic_raw))
        END AS search_query,
        dwell_seconds,
        scroll_depth_pct,
        CASE
            WHEN channel_value = 'mobile_app' THEN
                CASE WHEN rand() < 0.6 THEN 'iOS' ELSE 'Android' END
            ELSE
                CASE WHEN rand() < 0.65 THEN 'Desktop' ELSE 'Tablet' END
        END AS device_type,
        CASE WHEN page_type_value = 'product_detail' THEN true ELSE false END AS viewed_product_detail
    FROM raw_events
)
SELECT * FROM final_events;


-- 2) Generate synthetic external signal data (social + engagement cues).
CREATE OR REPLACE TABLE retail_consumer_goods.conversational_commerce_search.customer_external_signals
USING DELTA
COMMENT 'External social-signal telemetry mapped to customers'
TBLPROPERTIES (
  delta.enableChangeDataFeed = true
)
AS
WITH customer_base AS (
    SELECT
        c.customer_id,
        c.name,
        c.email,
        CASE
            WHEN trim(coalesce(c.preferred_categories, '')) = '' THEN array('General Discovery')
            ELSE transform(split(c.preferred_categories, ','), x -> trim(x))
        END AS pref_categories
    FROM retail_consumer_goods.conversational_commerce_search.customers c
),
expansion AS (
    SELECT
        cb.*,
        GREATEST(1, CAST(FLOOR(rand() * 3) + 1 AS INT)) AS signal_target
    FROM customer_base cb
),
signal_rows AS (
    SELECT
        e.customer_id,
        posexplode(sequence(1, e.signal_target)) AS (signal_pos, signal_index),
        e.pref_categories
    FROM expansion e
),
raw_signals AS (
    SELECT
        sr.customer_id,
        from_unixtime(unix_timestamp() - CAST(rand() * 86400 * 30 AS BIGINT)) AS signal_timestamp,
        CASE
            WHEN rand() < 0.40 THEN 'TikTok'
            WHEN rand() < 0.70 THEN 'Instagram'
            WHEN rand() < 0.85 THEN 'YouTube'
            WHEN rand() < 0.95 THEN 'Pinterest'
            ELSE 'Reddit'
        END AS platform,
        CASE
            WHEN rand() < 0.35 THEN 'trend_follow'
            WHEN rand() < 0.60 THEN 'content_engagement'
            WHEN rand() < 0.80 THEN 'influencer_like'
            WHEN rand() < 0.95 THEN 'wishlist_save'
            ELSE 'cart_discussion'
        END AS signal_type,
        CASE
            WHEN size(sr.pref_categories) = 0 THEN 'general lifestyle'
            WHEN size(sr.pref_categories) = 1 THEN sr.pref_categories[0]
            ELSE sr.pref_categories[CAST(FLOOR(rand() * size(sr.pref_categories)) AS INT)]
        END AS content_topic_raw,
        ROUND(rand() * 0.7 + 0.3, 3) AS engagement_score
    FROM signal_rows sr
)
SELECT
    customer_id,
    signal_timestamp,
    platform,
    signal_type,
    INITCAP(content_topic_raw) AS content_topic,
    engagement_score,
    CONCAT(
        'https://www.',
        lower(regexp_replace(platform, '\\s+', '')),
        '.com/',
        lower(regexp_replace(content_topic_raw, '\\s+', '-')),
        '/',
        substring(md5(concat(platform, content_topic_raw, CAST(signal_timestamp AS STRING))), 1, 8)
    ) AS source_url
FROM raw_signals;


-- 3) Basket intelligence (co-purchase graph per customer) sourced from interaction history.
CREATE OR REPLACE TABLE retail_consumer_goods.conversational_commerce_search.customer_basket_intelligence
USING DELTA
COMMENT 'Customer-level product affinity pairs derived from purchase baskets'
TBLPROPERTIES (
  delta.enableChangeDataFeed = true
)
AS
WITH purchase_events AS (
    SELECT
        customer_id,
        session_id,
        collect_list(product_id) AS products,
        MAX(timestamp) AS last_purchase_ts
    FROM retail_consumer_goods.conversational_commerce_search.interactions
    WHERE lower(interaction_type) = 'purchase'
    GROUP BY customer_id, session_id
    HAVING size(products) > 1
),
pair_rows AS (
    SELECT
        pe.customer_id,
        pe.last_purchase_ts,
        anchor_pos,
        anchor_product_id,
        assoc_pos,
        associated_product_id
    FROM purchase_events pe
    LATERAL VIEW posexplode(pe.products) anchor AS anchor_pos, anchor_product_id
    LATERAL VIEW posexplode(pe.products) assoc AS assoc_pos, associated_product_id
    WHERE anchor_pos <> assoc_pos
),
pair_scores AS (
    SELECT
        pr.customer_id,
        pr.anchor_product_id,
        pr.associated_product_id,
        COUNT(*) AS pair_count,
        MAX(pr.last_purchase_ts) AS last_seen_purchase_ts
    FROM pair_rows pr
    GROUP BY pr.customer_id, pr.anchor_product_id, pr.associated_product_id
),
normalized AS (
    SELECT
        ps.*,
        ps.pair_count / SUM(ps.pair_count) OVER (PARTITION BY ps.customer_id, ps.anchor_product_id) AS affinity_share,
        ROW_NUMBER() OVER (
            PARTITION BY ps.customer_id, ps.anchor_product_id
            ORDER BY ps.pair_count DESC, ps.associated_product_id
        ) AS affinity_rank
    FROM pair_scores ps
)
SELECT
    n.customer_id,
    c.name AS customer_name,
    n.anchor_product_id,
    anchor.name AS anchor_product_name,
    n.associated_product_id,
    assoc.name AS associated_product_name,
    n.pair_count,
    ROUND(n.affinity_share, 4) AS affinity_share,
    n.last_seen_purchase_ts,
    n.affinity_rank
FROM normalized n
LEFT JOIN retail_consumer_goods.conversational_commerce_search.products anchor
    ON n.anchor_product_id = anchor.product_id
LEFT JOIN retail_consumer_goods.conversational_commerce_search.products assoc
    ON n.associated_product_id = assoc.product_id
LEFT JOIN retail_consumer_goods.conversational_commerce_search.customers c
    ON n.customer_id = c.customer_id
WHERE n.affinity_rank <= 5;


-- 4) Unified customer profile snapshot that surfaces recent purchases, browsing, social signals, and basket insights.
CREATE OR REPLACE TABLE retail_consumer_goods.conversational_commerce_search.customer_profile_summary
USING DELTA
COMMENT 'Admin-facing customer profile rollup combining transactions, browsing, social signals, and basket intelligence'
TBLPROPERTIES (
  delta.enableChangeDataFeed = true
)
AS
WITH base_customers AS (
    SELECT
        customer_id,
        name,
        email,
        persona,
        preferred_categories,
        registration_date,
        total_orders,
        total_spent
    FROM retail_consumer_goods.conversational_commerce_search.customers
),
recent_purchase AS (
    SELECT
        customer_id,
        product_id,
        purchase_amount,
        timestamp AS purchase_ts,
        ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY timestamp DESC) AS rn
    FROM retail_consumer_goods.conversational_commerce_search.interactions
    WHERE lower(interaction_type) = 'purchase'
),
recent_purchase_enriched AS (
    SELECT
        rp.customer_id,
        rp.product_id,
        p.name AS product_name,
        p.category AS product_category,
        p.price AS listed_price,
        rp.purchase_amount,
        rp.purchase_ts AS last_purchase_ts
    FROM recent_purchase rp
    LEFT JOIN retail_consumer_goods.conversational_commerce_search.products p
        ON rp.product_id = p.product_id
    WHERE rp.rn = 1
),
recent_browse AS (
    SELECT
        customer_id,
        session_id,
        event_timestamp,
        channel,
        page_type,
        device_type,
        search_query,
        focus_topic,
        ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY event_timestamp DESC) AS rn
    FROM retail_consumer_goods.conversational_commerce_search.customer_browsing_events
),
recent_external AS (
    SELECT
        customer_id,
        signal_timestamp,
        platform,
        signal_type,
        content_topic,
        engagement_score,
        source_url,
        ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY signal_timestamp DESC) AS rn
    FROM retail_consumer_goods.conversational_commerce_search.customer_external_signals
),
basket_ranked AS (
    SELECT
        cbi.*,
        ROW_NUMBER() OVER (
            PARTITION BY cbi.customer_id
            ORDER BY cbi.affinity_share DESC, cbi.pair_count DESC
        ) AS rn
    FROM retail_consumer_goods.conversational_commerce_search.customer_basket_intelligence cbi
),
basket_summary AS (
    SELECT
        customer_id,
        array_join(
            transform(
                array_sort(
                    collect_list(
                        named_struct(
                            'rn', rn,
                            'text',
                            CONCAT(
                                coalesce(associated_product_name, associated_product_id),
                                ' (',
                                ROUND(affinity_share * 100, 1),
                                '%)'
                            )
                        )
                    )
                ),
                x -> x.text
            ),
            '; '
        ) AS top_cross_sell_products
    FROM basket_ranked
    WHERE rn <= 3
    GROUP BY customer_id
)
SELECT
    bc.customer_id,
    bc.name AS customer_name,
    bc.email,
    bc.persona,
    bc.preferred_categories,
    bc.registration_date,
    bc.total_orders,
    bc.total_spent,
    rpe.product_id AS last_product_id,
    rpe.product_name AS last_product_name,
    rpe.product_category AS last_product_category,
    rpe.last_purchase_ts,
    rpe.purchase_amount,
    rb.event_timestamp AS last_browse_ts,
    rb.channel AS last_browse_channel,
    rb.device_type AS last_browse_device,
    rb.page_type AS last_browse_page,
    rb.search_query AS last_browse_search,
    rb.focus_topic AS last_browse_topic,
    re.signal_timestamp AS last_external_ts,
    re.platform AS last_external_platform,
    re.signal_type AS last_external_signal_type,
    re.content_topic AS last_external_topic,
    re.engagement_score AS last_external_engagement_score,
    re.source_url AS last_external_url,
    bs.top_cross_sell_products
FROM base_customers bc
LEFT JOIN recent_purchase_enriched rpe
    ON bc.customer_id = rpe.customer_id
LEFT JOIN recent_browse rb
    ON bc.customer_id = rb.customer_id AND rb.rn = 1
LEFT JOIN recent_external re
    ON bc.customer_id = re.customer_id AND re.rn = 1
LEFT JOIN basket_summary bs
    ON bc.customer_id = bs.customer_id;

