-- Create ORDERDB schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS ORDERDB;

-- ORDER_HEADER TABLE
CREATE TABLE IF NOT EXISTS ORDERDB.ORDER_HEADER (
    order_id                VARCHAR(50)     PRIMARY KEY,
    order_timestamp         TIMESTAMP       NOT NULL,
    customer_name           VARCHAR(255)    NOT NULL,
    customer_email          VARCHAR(255)    NOT NULL,
    phone                   VARCHAR(20),
    address                 VARCHAR(500),
    city                    VARCHAR(100),
    state                   VARCHAR(2),
    zip_code                VARCHAR(10),
    payment_method          VARCHAR(20),
    card_last_four          VARCHAR(4),
    subtotal                DECIMAL(10,2)   NOT NULL,
    tax                     DECIMAL(10,2)   NOT NULL,
    total_price             DECIMAL(10,2)   NOT NULL,
    created_at              TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ORDER_DETAILS TABLE
CREATE TABLE IF NOT EXISTS ORDERDB.ORDER_DETAILS (
    order_detail_id         VARCHAR(50)     PRIMARY KEY,
    order_id                VARCHAR(50)     NOT NULL,
    line_number             INT             NOT NULL,
    product_id              VARCHAR(50)     NOT NULL,
    name                    VARCHAR(255)    NOT NULL,
    category                VARCHAR(100)    NOT NULL,
    brand                   VARCHAR(100)    NOT NULL,
    price                   DECIMAL(10,2)   NOT NULL,
    quantity                INT             NOT NULL,
    line_total              DECIMAL(10,2)   NOT NULL,
    created_at              TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES ORDERDB.ORDER_HEADER(order_id) ON DELETE CASCADE
);
