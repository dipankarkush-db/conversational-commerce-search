# Lakebase Directory

This directory contains lakebase-related files for the conversational commerce application.

(Placeholder file to ensure directory is tracked by Git)
