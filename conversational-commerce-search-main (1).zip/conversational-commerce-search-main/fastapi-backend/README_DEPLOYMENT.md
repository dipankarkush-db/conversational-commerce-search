# Databricks Deployment Package

## 📦 Contents

This folder contains everything needed for Databricks Apps deployment:

```
fastapi-backend/
├── main.py                 # FastAPI server (serves React frontend)
├── requirements.txt        # Python dependencies
├── app.yaml               # Databricks app configuration
└── dist/                  # React frontend build (CRITICAL!)
    ├── index.html
    └── assets/
        ├── index-Biie753q.js
        └── index-prIZzJcJ.css
```

## ⚠️ IMPORTANT: Upload `dist` Folder!

**Common Issue**: When uploading via Databricks UI, the `dist` folder often doesn't upload automatically!

Your app will show this JSON if `dist` is missing:
```json
{"status":"healthy","service":"Conversational Commerce Search API"...}
```

## ✅ How to Upload Correctly

### Option 1: CLI (Recommended)

From project root:
```bash
databricks workspace import-dir \
  fastapi-backend \
  /Workspace/Users/<your-email>/conversational-commerce-search \
  --overwrite
```

### Option 2: Upload dist Separately

If UI upload skips the `dist` folder:
```bash
databricks workspace import-dir \
  fastapi-backend/dist \
  /Workspace/Users/<your-email>/conversational-commerce-search/dist \
  --overwrite
```

### Option 3: Manual UI Upload

1. Upload all top-level files (main.py, app.yaml, requirements.txt)
2. Create `dist` folder in Databricks workspace
3. Manually upload `index.html` and `assets/` folder contents

## 🔍 Verify Deployment

After upload, check `/api/debug/files` endpoint:

**✅ Correct:**
```json
{
  "directory_tree": [
    {"name": "main.py"},
    {"name": "dist", "type": "directory"}
  ]
}
```

**❌ Missing dist:**
```json
{
  "directory_tree": [
    {"name": "main.py"},
    {"name": "app.yaml"}
  ]
}
```

## 🎯 Expected Result

When deployed correctly, your app URL shows:
- ✅ React interface with Databricks branding
- ✅ "Start Shopping Experience" button
- ✅ Feature cards and descriptions
- ❌ NO JSON health check message

## 🐛 Troubleshooting

**Still seeing JSON?**
1. Check logs for: `Current directory contents: [...]`
2. If `'dist'` is not in the list → folder didn't upload
3. Upload `dist` separately using methods above
4. Restart app (Stop → Start)

**Get help**: See `../QUICK_FIX.md` for detailed instructions

