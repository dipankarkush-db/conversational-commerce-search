"""
FastAPI Backend for Conversational Commerce Search
Replaces Streamlit app with React + FastAPI architecture
"""
import os
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
import json
import csv
import re
from io import StringIO
from functools import lru_cache
import asyncio

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from pathlib import Path
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementParameterListItem
from mlflow.deployments import get_deploy_client

# Configure logging first (before Lakebase import)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import Lakebase service
try:
    from services.lakebase import lakebase
    LAKEBASE_ENABLED = True
except Exception as e:
    LAKEBASE_ENABLED = False
    lakebase = None

# Initialize FastAPI app
app = FastAPI(
    title="Conversational Commerce Search API",
    description="AI-powered conversational commerce search backend",
    version="1.0.0"
)

# CORS middleware for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Vite default
        "http://localhost:3000",  # Common React port
        "*"  # Allow all origins for Databricks app deployment
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# OPTIMIZATION: Add Gzip compression for faster response times (200-500ms savings)
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Environment variables
SERVING_ENDPOINT = os.getenv('SERVING_ENDPOINT')
DATABRICKS_WAREHOUSE_ID = os.getenv('DATABRICKS_WAREHOUSE_ID')
MAX_TOKENS = int(os.getenv('MAX_TOKENS', '800'))
DEBUG_MODE = os.getenv('DEBUG_MODE', 'false').lower() == 'true'

# Email configuration (optional - for order notifications)
ORDER_NOTIFICATION_EMAIL = os.getenv('ORDER_NOTIFICATION_EMAIL', 'dipankar.kushari@gmail.com')
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
SMTP_USERNAME = os.getenv('SMTP_USERNAME', '')
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')
EMAIL_ENABLED = bool(SMTP_USERNAME and SMTP_PASSWORD)

# Validate required environment variables
if not SERVING_ENDPOINT:
    SERVING_ENDPOINT = "conversational_commerce_agent"

# Debug logging helper
def debug_print(*args, **kwargs):
    """Conditional print based on DEBUG_MODE environment variable"""
    if DEBUG_MODE:
        print(*args, **kwargs)

# OPTIMIZATION: In-memory cache for customer data (10 minute TTL)
customer_cache = {}
CACHE_TTL = 600  # 10 minutes in seconds

def get_cached_customer(customer_email: str) -> Optional[Dict]:
    """Get customer from cache if not expired"""
    if customer_email in customer_cache:
        cached_data, timestamp = customer_cache[customer_email]
        if datetime.now().timestamp() - timestamp < CACHE_TTL:
            return cached_data
        else:
            # Expired, remove from cache
            del customer_cache[customer_email]
    return None

def cache_customer(customer_email: str, customer_data: Dict):
    """Cache customer data with timestamp"""
    customer_cache[customer_email] = (customer_data, datetime.now().timestamp())


# ============================================================================
# Pydantic Models
# ============================================================================

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    customer_id: str
    customer_name: str
    customer_email: str
    messages: List[Message]
    max_tokens: Optional[int] = None  # Will use MAX_TOKENS from env if not provided

class Product(BaseModel):
    product_id: str
    name: str
    category: str
    subcategory: str
    brand: str
    price: float
    description: str
    avg_rating: float
    features: Optional[Dict[str, Any]] = None

class ChatResponse(BaseModel):
    content: str
    products: Optional[List[Product]] = None
    timestamp: datetime

class CustomerInfo(BaseModel):
    customer_id: str
    customer_name: str
    customer_email: str
    customer_age: Optional[int] = None
    customer_gender: Optional[str] = None
    customer_location: Optional[str] = None
    persona: Optional[str] = None
    brand_loyalty: Optional[str] = None
    price_sensitivity: Optional[str] = None
    preferred_categories: Optional[str] = None
    total_orders: Optional[int] = 0
    total_spent: Optional[float] = 0.0

class CustomerInteraction(BaseModel):
    customer_name: str
    customer_email: str
    product_name: str
    product_price: float
    interaction_type: str
    interaction_timestamp: str
    customer_rating: Optional[float] = None
    product_category: Optional[str] = None
    product_brand: Optional[str] = None
    days_since_interaction: Optional[int] = None

class OrderItem(BaseModel):
    product_id: str
    name: str
    category: str
    brand: str
    price: float
    quantity: int

class OrderSubmission(BaseModel):
    customer_name: str
    customer_email: str
    items: List[OrderItem]
    subtotal: float
    tax: float
    total_price: float
    # Contact information
    full_name: str
    email: str
    phone: str
    # Shipping address
    address: str
    city: str
    state: str
    zip_code: str
    # Payment (masked for security)
    payment_method: str
    card_last_four: Optional[str] = None

class OrderResponse(BaseModel):
    success: bool
    order_id: str
    message: str
    email_sent: bool


# ============================================================================
# Databricks Integration Functions
# ============================================================================

@lru_cache(maxsize=1)
def get_workspace_client() -> WorkspaceClient:
    """Get Databricks workspace client (cached for connection pooling)"""
    try:
        return WorkspaceClient()
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to connect to Databricks")


def get_random_customer() -> CustomerInfo:
    """Get a random customer using Unity Catalog function"""
    try:
        w = get_workspace_client()
        
        # Execute the Unity Catalog function
        sql_query = "SELECT * FROM retail_consumer_goods.conversational_commerce_search.get_random_customer_info()"
        
        # Execute the SQL query
        result = w.statement_execution.execute_statement(
            warehouse_id=DATABRICKS_WAREHOUSE_ID,
            statement=sql_query,
            wait_timeout="30s"
        )
        
        if result.result and result.result.data_array:
            # Extract customer data from the first row
            # Column order from Unity Catalog function get_random_customer_info():
            # 0: customer_id, 1: customer_name, 2: customer_email, 3: customer_age,
            # 4: customer_gender, 5: customer_location, 6: persona, 
            # 7: preferred_categories, 8: total_orders, 9: total_spent
            # NOTE: brand_loyalty and price_sensitivity are NOT returned by this function
            row = result.result.data_array[0]
            return CustomerInfo(
                customer_id=str(row[0]),
                customer_name=str(row[1]),
                customer_email=str(row[2]),
                customer_age=int(row[3]) if row[3] else None,
                customer_gender=str(row[4]) if row[4] else None,
                customer_location=str(row[5]) if row[5] else None,
                persona=str(row[6]) if row[6] else None,
                brand_loyalty=None,  # Not returned by UC function
                price_sensitivity=None,  # Not returned by UC function
                preferred_categories=str(row[7]) if row[7] else None,
                total_orders=int(row[8]) if row[8] else 0,
                total_spent=float(row[9]) if row[9] else 0.0
            )
        else:
            raise HTTPException(status_code=500, detail="No customer data returned from database")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch customer from database: {str(e)}")


def get_customer_interactions(customer_name: str, customer_email: str) -> List[CustomerInteraction]:
    """Get customer interactions using Unity Catalog function (with caching)"""
    # OPTIMIZATION: Check cache first
    cache_key = f"interactions_{customer_email}"
    cached = get_cached_customer(cache_key)
    if cached is not None:
        return cached
    
    try:
        w = get_workspace_client()
        
        # Execute the Unity Catalog function for customer interactions
        sql_query = f"SELECT * FROM retail_consumer_goods.conversational_commerce_search.get_customer_interactions('{customer_name}', '{customer_email}') LIMIT 5"
        
        # Execute the SQL query
        result = w.statement_execution.execute_statement(
            warehouse_id=DATABRICKS_WAREHOUSE_ID,
            statement=sql_query,
            wait_timeout="30s"
        )
        
        interactions = []
        if result.result and result.result.data_array:
            for row in result.result.data_array:
                interactions.append(CustomerInteraction(
                    customer_name=str(row[0]),
                    customer_email=str(row[1]),
                    product_name=str(row[2]),
                    product_price=float(row[3]),
                    interaction_type=str(row[4]),
                    interaction_timestamp=str(row[5]),
                    customer_rating=float(row[6]) if row[6] else None,
                    product_category=str(row[7]) if row[7] else None,
                    product_brand=str(row[8]) if row[8] else None,
                    days_since_interaction=int(row[9]) if row[9] else None
                ))
        
        # Cache the interactions
        cache_customer(cache_key, interactions)
        return interactions
    except Exception as e:
        return []


@lru_cache(maxsize=10)
def _get_endpoint_task_type(endpoint_name: str) -> str:
    """Get the task type of a serving endpoint (cached to avoid repeated API calls)."""
    try:
        w = get_workspace_client()
        ep = w.serving_endpoints.get(endpoint_name)
        return ep.task
    except Exception as e:
        return "unknown"


@lru_cache(maxsize=10)
def is_endpoint_supported(endpoint_name: str) -> bool:
    """Check if the endpoint has a supported task type (cached for performance)."""
    task_type = _get_endpoint_task_type(endpoint_name)
    supported_task_types = ["agent/v1/chat", "agent/v2/chat", "llm/v1/chat"]
    return task_type in supported_task_types


def parse_databricks_output_for_products(databricks_output: Any) -> Optional[List[Dict[str, Any]]]:
    """
    Parse product data from Databricks agent output
    
    The agent uses UC functions that return product data. This function
    extracts that data from the agent's tool call results.
    """
    try:
        # databricks_output can be a dict or a list
        if isinstance(databricks_output, dict):
            # Pattern 1: Direct product list
            if 'products' in databricks_output:
                return parse_product_list(databricks_output['products'])
            
            # Pattern 2: Tool results array
            if 'tool_results' in databricks_output:
                tool_results = databricks_output['tool_results']
                for result in tool_results:
                    if isinstance(result, dict) and 'products' in result:
                        return parse_product_list(result['products'])
            
            # Pattern 3: Nested in outputs
            if 'outputs' in databricks_output:
                outputs = databricks_output['outputs']
                if isinstance(outputs, list):
                    for output in outputs:
                        if isinstance(output, dict):
                            # Check if this output contains product data
                            if 'data' in output and isinstance(output['data'], list):
                                products = parse_product_list(output['data'])
                                if products:
                                    return products
            
            # Pattern 4: Direct array field (data, results, items, etc.)
            for key in ['data', 'results', 'items', 'records']:
                if key in databricks_output and isinstance(databricks_output[key], list):
                    products = parse_product_list(databricks_output[key])
                    if products:
                        return products
        
        # Pattern 5: Direct list of product dictionaries
        elif isinstance(databricks_output, list):
            return parse_product_list(databricks_output)
        
        return None
        
    except Exception as e:
        return None


def parse_product_list(product_data: Any) -> Optional[List[Dict[str, Any]]]:
    """
    Parse a list of products into the format expected by frontend
    
    Handles multiple UC function schemas:
    - get_smart_product_recommendations: product_id, product_name, category, subcategory, brand, price, description, avg_rating
    - product_lookup_by_description: product_id, name, category, subcategory, price, description (no brand/rating)
    """
    try:
        if not isinstance(product_data, list):
            return None
        
        products = []
        for idx, item in enumerate(product_data):
            if not isinstance(item, dict):
                continue
            
            # Handle both field name variations: 'product_name' vs 'name'
            product_name = item.get("product_name") or item.get("name") or ""
            
            # Extract brand (handle empty strings from CSV)
            brand_value = item.get("brand", "")
            brand = brand_value if brand_value and brand_value.strip() else "Unknown"
            
            # Extract rating (handle empty strings from CSV)
            rating_value = item.get("avg_rating", "") or item.get("rating", "")
            try:
                avg_rating = float(rating_value) if rating_value and str(rating_value).strip() else 0.0
            except (ValueError, TypeError):
                avg_rating = 0.0
            
            # Clean description - remove product ID references
            raw_description = str(item.get("description", ""))
            # Remove all variations of product ID references
            # Pattern 1: "of the product prod_XXXXX" or "of the product with prod_XXXXX"
            cleaned_description = re.sub(r'\s+of the product(?:\s+with)?\s+prod_\d+', '', raw_description)
            # Pattern 2: "with product id prod_XXXXX"
            cleaned_description = re.sub(r'\s+with product id prod_\d+', '', cleaned_description)
            # Pattern 3: "(prod_XXXXX)" in parentheses
            cleaned_description = re.sub(r'\s*\(prod_\d+\)', '', cleaned_description)
            # Pattern 4: Any remaining "prod_XXXXX" standalone
            cleaned_description = re.sub(r'\s*prod_\d+\s*', ' ', cleaned_description)
            # Clean up any double spaces and trim
            cleaned_description = ' '.join(cleaned_description.split()).strip()
            
            # Map UC function output to frontend Product schema
            product = {
                "product_id": str(item.get("product_id", "")),
                "name": str(product_name),
                "category": str(item.get("category", "")),
                "subcategory": str(item.get("subcategory", "")),
                "brand": brand,
                "price": float(item.get("price", 0.0)),
                "description": cleaned_description,
                "avg_rating": avg_rating,
            }
            
            # Only add if we have minimum required fields
            if product["product_id"] and product["name"] and product["price"] > 0:
                products.append(product)
        
        return products if products else None
        
    except Exception as e:
        return None


# ============================================================================
# REMOVED REDUNDANT EXTRACTION FUNCTIONS
# ============================================================================
# The following functions were removed as they're redundant with the AI agent's capabilities:
# - extract_price_budget() - AI agent extracts price from natural language
# - extract_brand_from_query() - AI agent extracts brand from natural language  
# - extract_category_from_query() - AI agent extracts category from natural language
# - filter_products_by_price() - AI agent respects price constraints via tool parameters
# - filter_products_by_text_mention() - AI agent curates product lists directly
# - filter_products_combined() - Not needed, agent handles all filtering
# - filter_products_by_category() - Not needed, agent handles category filtering
#
# Performance improvement: ~7-11ms per request by eliminating redundant regex operations
# ============================================================================


def query_model_endpoint(endpoint_name: str, messages: List[Dict[str, str]], max_tokens: int) -> tuple[str, Any]:
    """Query the Databricks model serving endpoint and return (text_content, full_response)"""
    try:
        # Validate endpoint
        if not is_endpoint_supported(endpoint_name):
            raise HTTPException(
                status_code=400,
                detail=f"Endpoint {endpoint_name} is not supported. Must be a chat-compatible endpoint."
            )
        
        # Query the endpoint
        deploy_client = get_deploy_client('databricks')
        response = deploy_client.predict(
            endpoint=endpoint_name,
            inputs={'messages': messages, "max_tokens": max_tokens},
        )
        
        # Parse response
        text_content = ""
        if "messages" in response:
            text_content = response["messages"][-1]["content"]
        elif "choices" in response:
            choice_message = response["choices"][0]["message"]
            choice_content = choice_message.get("content")
            
            # Case 1: The content is a list of structured objects
            if isinstance(choice_content, list):
                text_content = "".join([
                    part.get("text", "") 
                    for part in choice_content 
                    if part.get("type") == "text"
                ])
            # Case 2: The content is a simple string
            elif isinstance(choice_content, str):
                text_content = choice_content
        
        if not text_content:
            raise HTTPException(
                status_code=500,
                detail="Unexpected response format from model endpoint"
            )
        
        # Return both text and full response for product extraction
        return text_content, response
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to query model endpoint: {str(e)}"
        )


# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/favicon.svg")
async def favicon():
    """Serve the SVG favicon"""
    possible_paths = [
        Path(__file__).parent / "dist" / "favicon.svg",  # Databricks deployment (flattened)
        Path(__file__).parent / "frontend-dist" / "dist" / "favicon.svg",  # Databricks deployment (nested)
        Path(__file__).parent.parent / "Conversational-Commerce-Frontend" / "dist" / "favicon.svg",  # Local dev
    ]
    
    for favicon_path in possible_paths:
        if favicon_path.exists():
            return FileResponse(favicon_path, media_type="image/svg+xml")
    
    raise HTTPException(status_code=404, detail="Favicon not found")

@app.get("/logo-3bags.svg")
async def logo():
    """Serve the 3-bags logo"""
    possible_paths = [
        Path(__file__).parent / "dist" / "logo-3bags.svg",  # Databricks deployment (flattened)
        Path(__file__).parent / "frontend-dist" / "dist" / "logo-3bags.svg",  # Databricks deployment (nested)
        Path(__file__).parent.parent / "Conversational-Commerce-Frontend" / "dist" / "logo-3bags.svg",  # Local dev
    ]
    
    for logo_path in possible_paths:
        if logo_path.exists():
            return FileResponse(logo_path, media_type="image/svg+xml")
    
    raise HTTPException(status_code=404, detail="Logo not found")

@app.get("/hero-conversational-commerce.svg")
async def hero_image():
    """Serve the hero conversational commerce image"""
    possible_paths = [
        Path(__file__).parent / "dist" / "hero-conversational-commerce.svg",  # Databricks deployment (flattened)
        Path(__file__).parent / "frontend-dist" / "dist" / "hero-conversational-commerce.svg",  # Databricks deployment (nested)
        Path(__file__).parent.parent / "Conversational-Commerce-Frontend" / "dist" / "hero-conversational-commerce.svg",  # Local dev
    ]
    
    for hero_path in possible_paths:
        if hero_path.exists():
            return FileResponse(hero_path, media_type="image/svg+xml")
    
    raise HTTPException(status_code=404, detail="Hero image not found")

@app.get("/")
async def root():
    """Serve the React frontend"""
    # Try multiple locations for the frontend (local dev vs Databricks deployment)
    possible_paths = [
        Path(__file__).parent / "dist" / "index.html",  # Databricks deployment (flattened)
        Path(__file__).parent / "frontend-dist" / "dist" / "index.html",  # Databricks deployment (nested)
        Path(__file__).parent.parent / "Conversational-Commerce-Frontend" / "dist" / "index.html",  # Local dev
    ]
    
    for frontend_path in possible_paths:
        if frontend_path.exists():
            return FileResponse(frontend_path)
    
    # Fallback to API health check if frontend not built
    return {
            "status": "healthy",
            "service": "Conversational Commerce Search API",
            "version": "1.0.0",
        "note": "Frontend not found. Build the React app first: cd '../Conversational-Commerce-Frontend' && npm run build",
        "debug": {
            "current_file": str(Path(__file__).resolve()),
            "parent_dir": str(Path(__file__).parent.resolve()),
            "tried_paths": [str(p.resolve()) for p in possible_paths]
        }
        }


@app.get("/api/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "serving_endpoint": SERVING_ENDPOINT,
        "warehouse_configured": bool(DATABRICKS_WAREHOUSE_ID),
        "timestamp": datetime.now().isoformat()
    }


@app.get("/api/debug/files")
async def debug_files():
    """Debug endpoint to check file structure"""
    current_dir = Path(__file__).parent
    
    def list_directory(path: Path, max_depth: int = 2, current_depth: int = 0):
        """Recursively list directory contents"""
        if current_depth >= max_depth or not path.is_dir():
            return []
        
        items = []
        try:
            for item in sorted(path.iterdir()):
                items.append({
                    "name": item.name,
                    "type": "directory" if item.is_dir() else "file",
                    "path": str(item.relative_to(current_dir)),
                    "children": list_directory(item, max_depth, current_depth + 1) if item.is_dir() else []
                })
        except Exception as e:
            items.append({"error": str(e)})
        
        return items
    
    return {
        "current_file": str(Path(__file__).resolve()),
        "parent_dir": str(current_dir.resolve()),
        "directory_tree": list_directory(current_dir),
        "frontend_paths_checked": [
            {
                "path": str((current_dir / "dist" / "index.html").resolve()),
                "exists": (current_dir / "dist" / "index.html").exists()
            },
            {
                "path": str((current_dir / "frontend-dist" / "dist" / "index.html").resolve()),
                "exists": (current_dir / "frontend-dist" / "dist" / "index.html").exists()
            },
            {
                "path": str((current_dir.parent / "Conversational-Commerce-Frontend" / "dist" / "index.html").resolve()),
                "exists": (current_dir.parent / "Conversational-Commerce-Frontend" / "dist" / "index.html").exists()
            }
        ]
    }


@app.get("/api/customer/random", response_model=CustomerInfo)
async def get_random_customer_endpoint():
    """Get a random customer profile"""
    try:
        # OPTIMIZATION: Run blocking DB call in thread pool
        customer = await asyncio.to_thread(get_random_customer)
        return customer
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _fetch_admin_customers_from_db() -> List[CustomerInfo]:
    """Helper function to fetch admin customers from database (blocking operation)"""
    w = get_workspace_client()
    
    # SQL query to get 6 random customers from each persona
    # Using uuid() for truly random ordering on each execution
    # uuid() generates unique values ensuring different results every time
    sql_query = """
    WITH ranked AS (
        SELECT
            customer_id,
            name AS customer_name,
            email AS customer_email,
            age AS customer_age,
            gender AS customer_gender,
            location AS customer_location,
            persona,
            preferred_categories,
            total_orders,
            total_spent,
            ROW_NUMBER() OVER (
            PARTITION BY persona
            ORDER BY uuid()
            ) AS row_num
        FROM retail_consumer_goods.conversational_commerce_search.customers
        )

        SELECT customer_id,
                    customer_name,
                    customer_email,
                    customer_age,
                    customer_gender,
                    customer_location,
                    persona,
                    preferred_categories,
                    total_orders,
                    total_spent
        FROM ranked
        WHERE row_num <= 6
        ORDER BY persona, row_num
    """
    
    # Execute the SQL query
    result = w.statement_execution.execute_statement(
        warehouse_id=DATABRICKS_WAREHOUSE_ID,
        statement=sql_query,
        wait_timeout="30s"
    )
    
    customers = []
    if result.result and result.result.data_array:
        # Parse each customer row
        for row in result.result.data_array:
            customers.append(CustomerInfo(
                customer_id=str(row[0]),
                customer_name=str(row[1]),
                customer_email=str(row[2]),
                customer_age=int(row[3]) if row[3] else None,
                customer_gender=str(row[4]) if row[4] else None,
                customer_location=str(row[5]) if row[5] else None,
                persona=str(row[6]) if row[6] else None,
                brand_loyalty=None,  # Not in this query
                price_sensitivity=None,  # Not in this query
                preferred_categories=str(row[7]) if row[7] else None,
                total_orders=int(row[8]) if row[8] else 0,
                total_spent=float(row[9]) if row[9] else 0.0
            ))
    
    logger.info(f"Fetched {len(customers)} customers for admin view (cached)")
    return customers


@app.get("/api/admin/customers", response_model=List[CustomerInfo])
async def get_admin_customers():
    """
    Get 36 customers (6 from each persona) for admin experience
    Personas: Tech Enthusiast, Fashion Forward, Home Decorator, Book Lover, Fitness Enthusiast, Bargain Hunter
    
    OPTIMIZATION: Uses 10-minute cache to avoid repeated Databricks queries
    """
    # OPTIMIZATION: Check cache first (10-minute TTL)
    cache_key = "admin_customers"
    cached = get_cached_customer(cache_key)
    if cached is not None:
        logger.info(f"Returning {len(cached)} admin customers from cache")
        return cached
    
    try:
        # OPTIMIZATION: Run blocking DB call in thread pool
        customers = await asyncio.to_thread(_fetch_admin_customers_from_db)
        
        # Cache the results for 10 minutes
        cache_customer(cache_key, customers)
        
        return customers
    except Exception as e:
        logger.error(f"Failed to fetch admin customers: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch admin customers: {str(e)}")


@app.delete("/api/admin/customers/cache")
async def clear_admin_customers_cache():
    """
    Clear the admin customers cache to force fresh data fetch on next request.
    This ensures new random customers are fetched when admin logs out and back in.
    """
    cache_key = "admin_customers"
    if cache_key in customer_cache:
        del customer_cache[cache_key]
        logger.info("Admin customers cache cleared")
        return {"message": "Admin customers cache cleared successfully"}
    else:
        logger.info("Admin customers cache was already empty")
        return {"message": "Cache was already empty"}


@app.get("/api/admin/customer-profile/{customer_id}")
async def get_customer_profile_details(customer_id: str):
    """
    Get detailed customer profile including:
    - Recent browsing events
    - External signals (social media)
    - Basket intelligence (frequently bought together)
    - Recent shopping history
    
    OPTIMIZATION: Executes all 5 queries in parallel for ~5x speedup
    """
    try:
        import asyncio
        from concurrent.futures import ThreadPoolExecutor
        
        def execute_query(query: str, query_name: str):
            """Execute a single query and return results"""
            try:
                w = get_workspace_client()
                result = w.statement_execution.execute_statement(
                    warehouse_id=DATABRICKS_WAREHOUSE_ID,
                    statement=query.format(customer_id=customer_id),
                    wait_timeout="30s"
                )
                return query_name, result
            except Exception as e:
                logger.error(f"Error executing {query_name} query: {str(e)}")
                return query_name, None
        
        # Define all queries
        profile_query = """
        SELECT 
            customer_id,
            customer_name,
            email,
            persona,
            preferred_categories,
            total_orders,
            total_spent,
            last_product_name,
            last_product_category,
            last_purchase_ts,
            purchase_amount,
            last_browse_channel,
            last_browse_device,
            last_browse_search,
            last_browse_topic,
            last_external_platform,
            last_external_signal_type,
            last_external_topic,
            last_external_engagement_score,
            last_external_url,
            top_cross_sell_products
        FROM retail_consumer_goods.conversational_commerce_search.customer_profile_summary
        WHERE customer_id = '{customer_id}'
        LIMIT 1
        """
        
        browsing_query = """
        SELECT 
            session_id,
            event_timestamp,
            channel,
            page_type,
            device_type,
            search_query,
            focus_topic,
            dwell_seconds
        FROM retail_consumer_goods.conversational_commerce_search.customer_browsing_events
        WHERE customer_id = '{customer_id}'
        ORDER BY event_timestamp DESC
        LIMIT 5
        """
        
        external_query = """
        SELECT 
            signal_timestamp,
            platform,
            signal_type,
            content_topic,
            engagement_score,
            source_url
        FROM retail_consumer_goods.conversational_commerce_search.customer_external_signals
        WHERE customer_id = '{customer_id}'
        ORDER BY signal_timestamp DESC
        LIMIT 5
        """
        
        basket_query = """
        SELECT 
            anchor_product_name,
            associated_product_name,
            pair_count,
            affinity_share
        FROM retail_consumer_goods.conversational_commerce_search.customer_basket_intelligence
        WHERE customer_id = '{customer_id}'
        ORDER BY affinity_share DESC
        LIMIT 5
        """
        
        interactions_query = """
        SELECT 
            p.name as product_name,
            p.price,
            i.interaction_type,
            i.timestamp,
            p.category
        FROM retail_consumer_goods.conversational_commerce_search.interactions i
        JOIN retail_consumer_goods.conversational_commerce_search.products p 
            ON i.product_id = p.product_id
        WHERE i.customer_id = '{customer_id}'
        ORDER BY i.timestamp DESC
        LIMIT 5
        """
        
        # Execute all queries in parallel using ThreadPoolExecutor
        queries = [
            (profile_query, "profile"),
            (browsing_query, "browsing"),
            (external_query, "external"),
            (basket_query, "basket"),
            (interactions_query, "shopping")
        ]
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(execute_query, query, name) for query, name in queries]
            results = {name: result for name, result in [f.result() for f in futures]}
        
        # Process profile data
        profile_data = {}
        if results["profile"] and results["profile"].result and results["profile"].result.data_array and len(results["profile"].result.data_array) > 0:
            row = results["profile"].result.data_array[0]
            profile_data = {
                "customer_id": str(row[0]) if row[0] else None,
                "customer_name": str(row[1]) if row[1] else None,
                "email": str(row[2]) if row[2] else None,
                "persona": str(row[3]) if row[3] else None,
                "preferred_categories": str(row[4]) if row[4] else None,
                "total_orders": int(row[5]) if row[5] else 0,
                "total_spent": float(row[6]) if row[6] else 0.0,
                "last_product_name": str(row[7]) if row[7] else None,
                "last_product_category": str(row[8]) if row[8] else None,
                "last_purchase_ts": str(row[9]) if row[9] else None,
                "purchase_amount": float(row[10]) if row[10] else None,
                "last_browse_channel": str(row[11]) if row[11] else None,
                "last_browse_device": str(row[12]) if row[12] else None,
                "last_browse_search": str(row[13]) if row[13] else None,
                "last_browse_topic": str(row[14]) if row[14] else None,
                "last_external_platform": str(row[15]) if row[15] else None,
                "last_external_signal_type": str(row[16]) if row[16] else None,
                "last_external_topic": str(row[17]) if row[17] else None,
                "last_external_engagement_score": float(row[18]) if row[18] else None,
                "last_external_url": str(row[19]) if row[19] else None,
                "top_cross_sell_products": str(row[20]) if row[20] else None,
            }
        
        # Process browsing events
        browsing_events = []
        if results["browsing"] and results["browsing"].result and results["browsing"].result.data_array:
            for row in results["browsing"].result.data_array:
                browsing_events.append({
                    "session_id": str(row[0]) if row[0] else None,
                    "event_timestamp": str(row[1]) if row[1] else None,
                    "channel": str(row[2]) if row[2] else None,
                    "page_type": str(row[3]) if row[3] else None,
                    "device_type": str(row[4]) if row[4] else None,
                    "search_query": str(row[5]) if row[5] else None,
                    "focus_topic": str(row[6]) if row[6] else None,
                    "dwell_seconds": int(row[7]) if row[7] else 0,
                })
        
        # Process external signals
        external_signals = []
        if results["external"] and results["external"].result and results["external"].result.data_array:
            for row in results["external"].result.data_array:
                external_signals.append({
                    "signal_timestamp": str(row[0]) if row[0] else None,
                    "platform": str(row[1]) if row[1] else None,
                    "signal_type": str(row[2]) if row[2] else None,
                    "content_topic": str(row[3]) if row[3] else None,
                    "engagement_score": float(row[4]) if row[4] else 0.0,
                    "source_url": str(row[5]) if row[5] else None,
                })
        
        # Process basket intelligence
        basket_intelligence = []
        if results["basket"] and results["basket"].result and results["basket"].result.data_array:
            for row in results["basket"].result.data_array:
                basket_intelligence.append({
                    "anchor_product": str(row[0]) if row[0] else None,
                    "associated_product": str(row[1]) if row[1] else None,
                    "pair_count": int(row[2]) if row[2] else 0,
                    "affinity_share": float(row[3]) if row[3] else 0.0,
                })
        
        # Process shopping history
        shopping_history = []
        if results["shopping"] and results["shopping"].result and results["shopping"].result.data_array:
            for row in results["shopping"].result.data_array:
                shopping_history.append({
                    "product_name": str(row[0]) if row[0] else None,
                    "price": float(row[1]) if row[1] else 0.0,
                    "interaction_type": str(row[2]) if row[2] else None,
                    "timestamp": str(row[3]) if row[3] else None,
                    "category": str(row[4]) if row[4] else None,
                })
        
        return {
            "profile": profile_data,
            "browsing_events": browsing_events,
            "external_signals": external_signals,
            "basket_intelligence": basket_intelligence,
            "shopping_history": shopping_history
        }
        
    except Exception as e:
        logger.error(f"Failed to fetch customer profile: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch customer profile: {str(e)}")


def _fetch_products_from_db(category: Optional[str], subcategory: Optional[str], limit: int) -> List[Product]:
    """Helper function to fetch products from database (blocking operation)"""
    w = get_workspace_client()
    
    # Build SQL query to fetch directly from products table
    sql_query = "SELECT product_id, name, category, subcategory, price, brand, description, avg_rating FROM retail_consumer_goods.conversational_commerce_search.products"
    
    # Add filters if provided
    where_clauses = []
    if category:
        where_clauses.append(f"category = '{category}'")
    if subcategory:
        where_clauses.append(f"subcategory = '{subcategory}'")
    
    if where_clauses:
        sql_query += " WHERE " + " AND ".join(where_clauses)
    
    # Add random ordering so each request returns different products
    sql_query += " ORDER BY RAND()"
    
    # Add limit
    sql_query += f" LIMIT {limit}"
    
    debug_print(f"Executing SQL: {sql_query}")
    
    # Execute the SQL query
    result = w.statement_execution.execute_statement(
        warehouse_id=DATABRICKS_WAREHOUSE_ID,
        statement=sql_query,
        wait_timeout="30s"
    )
    
    # Parse the results
    if result.result and result.result.data_array:
        # Extract product data from result rows
        parsed_products = []
        for row in result.result.data_array:
            try:
                product = {
                    "product_id": str(row[0]) if row[0] else "",
                    "name": str(row[1]) if row[1] else "",
                    "category": str(row[2]) if row[2] else "",
                    "subcategory": str(row[3]) if row[3] else "",
                    "price": float(row[4]) if row[4] else 0.0,
                    "brand": str(row[5]) if len(row) > 5 and row[5] else "Unknown",
                    "description": str(row[6]) if len(row) > 6 and row[6] else "",
                    "avg_rating": float(row[7]) if len(row) > 7 and row[7] else 0.0,
                }
                parsed_products.append(product)
            except (IndexError, ValueError) as e:
                logger.warning(f"Failed to parse product row: {e}")
                continue
        
        debug_print(f"Successfully fetched {len(parsed_products)} products")
        return [Product(**p) for p in parsed_products]
    
    debug_print("No products found in result")
    return []


@app.get("/api/products", response_model=List[Product])
async def get_all_products_endpoint(category: Optional[str] = None, subcategory: Optional[str] = None, limit: int = 100):
    """
    Get all products, optionally filtered by category and subcategory.
    Products are returned in random order for variety.
    """
    try:
        # OPTIMIZATION: Run blocking DB call in thread pool
        products = await asyncio.to_thread(_fetch_products_from_db, category, subcategory, limit)
        return products
    except Exception as e:
        debug_print(f"Error fetching products: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/customer/{customer_name}/interactions", response_model=List[CustomerInteraction])
async def get_customer_interactions_endpoint(customer_name: str, customer_email: str):
    """Get customer interaction history"""
    try:
        # OPTIMIZATION: Run blocking DB call in thread pool
        interactions = await asyncio.to_thread(get_customer_interactions, customer_name, customer_email)
        return interactions
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """
    Main chat endpoint for conversational commerce
    Processes user queries and returns AI-generated responses with product recommendations
    """
    try:
        # Use configured MAX_TOKENS if not provided in request
        max_tokens = request.max_tokens if request.max_tokens is not None else MAX_TOKENS
        
        # Build messages array with customer context
        # Keep recent conversation history (6 messages = 3 exchanges) for context
        recent_messages = request.messages[-6:] if len(request.messages) > 6 else request.messages
        messages_for_model = []
        
        # Add customer context to the latest user message
        # The AI agent will extract price/brand/category directly from the natural language query
        customer_intro = f"Customer Name: {request.customer_name}, Customer email: {request.customer_email}. "
        
        for i, msg in enumerate(recent_messages):
            if msg.role == "user":
                # Check if this is the LAST user message (current query)
                is_latest_message = (i == len(recent_messages) - 1)
                
                if is_latest_message:
                    # Prepend customer info to the latest message only
                    combined_content = f"{customer_intro}{msg.content}"
                else:
                    # Historical messages don't need customer info repeated
                    combined_content = msg.content
                
                messages_for_model.append({
                    "role": "user",
                    "content": combined_content
                })
            else:
                # Keep assistant messages as-is for conversation history
                messages_for_model.append({
                    "role": msg.role,
                    "content": msg.content
                })
        
        # Debug: Print what we're sending to the agent
        if DEBUG_MODE:
            debug_print("\n" + "="*80)
            debug_print("🔵 AGENT INPUT:")
            debug_print(json.dumps({
                "endpoint": SERVING_ENDPOINT,
                "messages": messages_for_model
            }, indent=2))
            debug_print("="*80 + "\n")
        
        # OPTIMIZATION: Run blocking AI endpoint call in thread pool to avoid blocking event loop
        response_content, full_response = await asyncio.to_thread(
            query_model_endpoint,
            endpoint_name=SERVING_ENDPOINT,
            messages=messages_for_model,
            max_tokens=max_tokens
        )
        
        # Debug: Print agent's response
        if DEBUG_MODE:
            debug_print("\n" + "="*80)
            debug_print("🟢 AGENT RESPONSE:")
            debug_print(json.dumps(full_response, indent=2))
            debug_print("="*80 + "\n")
        
        # Extract products from agent response
        # STRATEGY: Trust the agent's final response as the source of truth
        # The agent curates products from the tool response - we just need to parse what it recommends
        extracted_products = None
        
        if isinstance(full_response, dict):
            # Get the LAST assistant message - this is the agent's final curated response
            messages = full_response.get('messages', [])
            final_assistant_content = None
            
            for msg in reversed(messages):
                if isinstance(msg, dict) and msg.get('role') == 'assistant':
                    content = msg.get('content', '')
                    # Make sure it's not empty and not just a tool call announcement
                    if content and len(content) > 50:
                        final_assistant_content = content
                        break
            
            # Use final_assistant_content if available, otherwise fall back to response_content
            content_to_parse = final_assistant_content or response_content
            
            if content_to_parse:
                # Extract product info from agent's text response
                # Agent follows this format: "1. Product Name - $Price (Rating/5) - Description"
                # Example: "1. Under Armour Camping West - $105.01 (4.7/5) - Water-resistant with multiple compartments"
                
                product_pattern = r'\d+\.\s+(.+?)\s+-\s+\$?([\d,]+\.?\d*)\s+\([\d.]+/\d+\)'
                matches = re.findall(product_pattern, content_to_parse, re.MULTILINE)
                
                debug_print(f"📝 Found {len(matches)} products mentioned in agent text")
                if DEBUG_MODE and matches:
                    debug_print(f"   Product names extracted: {[m[0].strip() for m in matches]}")
                
                if matches:
                    
                    # We found product names and prices, but we need full product data
                    # We'll need to match against the tool call response to get complete info
                    messages = full_response.get('messages', [])
                    
                    # Get products from tool call to use as lookup
                    # Look for product recommendation tool responses
                    tool_products = []
                    for msg in reversed(messages):
                        if isinstance(msg, dict) and msg.get('role') == 'tool':
                            tool_name = msg.get('name', '')
                            
                            # Check if this is a product-related tool
                            is_product_tool = any(keyword in tool_name.lower() for keyword in [
                                'product', 'recommendation', 'search'
                            ])
                            
                            if not is_product_tool:
                                continue
                            
                            content = msg.get('content', '')
                            try:
                                if isinstance(content, str):
                                    # Check for error response first
                                    if content.startswith('Error:'):
                                        continue
                                    
                                    tool_data = json.loads(content)
                                    if isinstance(tool_data, dict) and tool_data.get('format') == 'CSV':
                                        csv_string = tool_data.get('value', '')
                                        if not csv_string:
                                            continue
                                        
                                        csv_reader = csv.DictReader(StringIO(csv_string))
                                        tool_products = list(csv_reader)
                                        break
                            except Exception:
                                pass
                    
                    # Match mentioned products to full product data
                    extracted_products = []
                    unmatched_products = []  # Track products mentioned but not in tool response
                    
                    if tool_products:
                        for product_name, price in matches:
                            # Clean up product name (remove markdown, extra spaces)
                            product_name = product_name.strip().replace('**', '').replace('*', '').strip()
                            
                            # Find matching product in tool response
                            found = False
                            for tp in tool_products:
                                tp_name = tp.get('product_name', '').strip()
                                if not tp_name:
                                    tp_name = tp.get('name', '').strip()
                                
                                if tp_name.lower() == product_name.lower():
                                    # Clean description - remove product IDs (e.g., "prod_009868")
                                    description = tp.get('description', '')
                                    description = re.sub(r'\bprod_\d+\b', '', description)
                                    description = re.sub(r'\s+', ' ', description).strip()
                                    
                                    # Need to map tool response fields to our expected format
                                    product_dict = {
                                        'product_id': tp.get('product_id'),
                                        'name': tp_name,
                                        'category': tp.get('category'),
                                        'subcategory': tp.get('subcategory'),
                                        'brand': tp.get('brand'),
                                        'price': float(tp.get('price', 0)),
                                        'description': description,
                                        'avg_rating': float(tp.get('avg_rating', 0))
                                    }
                                    extracted_products.append(product_dict)
                                    found = True
                                    break
                            
                            if not found:
                                unmatched_products.append((product_name, price))
                    else:
                        # No tool products at all - all matches are unmatched
                        unmatched_products = matches
                    
                    # If agent mentioned products not in tool response, they don't match search criteria
                    # Don't fetch from DB - just log it and show "no results" with examples
                    if unmatched_products:
                        debug_print(f"⚠️ Agent mentioned {len(unmatched_products)} products not returned by tool - no matching products based on search criteria and customer profile. Ignoring.")
            
            if extracted_products:
                debug_print(f"✅ Successfully extracted {len(extracted_products)} products from agent response")
                
                # ==================================================================================
                # COMMENTED OUT: Post-processing filters (category, brand, price validation)
                # Per user request: Show all products from agent output without additional filtering
                # ==================================================================================
                
                # # CRITICAL FIX: Validate products match the requested category
                # # Filter out products that don't match user's specific request (e.g., no headphones when asking for laptops)
                # products_before_filtering = len(extracted_products)
                # if requested_category:
                #     debug_print(f"🔍 Validating products against requested category: '{requested_category}'")
                #     original_count = len(extracted_products)
                #     validated_products_list = []
                #     
                #     for product in extracted_products:
                #         product_category = product.get('category', '').lower()
                #         product_subcategory = product.get('subcategory', '').lower()
                #         requested_lower = requested_category.lower()
                #         
                #         # Check if product matches requested category/subcategory
                #         # CRITICAL: Prioritize subcategory matching to avoid false positives
                #         is_match = False
                #         
                #         # 1. Try exact subcategory match first (most specific)
                #         if product_subcategory == requested_lower:
                #             is_match = True
                #         # 2. Try substring match in subcategory (e.g., "laptop" in "laptops")
                #         elif requested_lower in product_subcategory:
                #             # CRITICAL FIX: "fiction" should NOT match "non-fiction"
                #             if requested_lower == "fiction":
                #                 if "non-fiction" not in product_subcategory:
                #                     is_match = True
                #             else:
                #                 is_match = True
                #         # 3. Only if no subcategory match, try exact category match
                #         elif product_category == requested_lower:
                #             is_match = True
                #         # 4. For broad category requests only (e.g., "Electronics", "Books")
                #         # Be very careful with substring matching in category to avoid false positives
                #         elif requested_lower in product_category:
                #             # Only match if it's a main category request, not a subcategory like "Garden"
                #             # Check if requested is a known main category
                #             main_categories = ['electronics', 'clothing', 'home & garden', 'books', 'sports & outdoors']
                #             if requested_lower in main_categories:
                #                 is_match = True
                #         
                #         if is_match:
                #             validated_products_list.append(product)
                #     
                #     if validated_products_list:
                #         extracted_products = validated_products_list
                #         debug_print(f"   ✅ {len(validated_products_list)} products passed validation")
                #     else:
                #         debug_print(f"   ❌ All {original_count} products were filtered out by category validation")
                #         extracted_products = []
                # 
                # # CRITICAL FIX: Validate products match the requested brand
                # # Filter out products from wrong brands (e.g., Home Depot when asking for Target)
                # if extracted_products and requested_brand:
                #     debug_print(f"🏷️ Validating products against requested brand: '{requested_brand}'")
                #     original_count = len(extracted_products)
                #     brand_validated_list = []
                #     
                #     for product in extracted_products:
                #         product_brand = product.get('brand', '').strip()
                #         # Normalize apostrophes for matching
                #         requested_brand_normalized = requested_brand.lower().replace('\u2019', "'").replace('`', "'")
                #         product_brand_normalized = product_brand.lower().replace('\u2019', "'").replace('`', "'")
                #         
                #         # Check for exact or partial match
                #         if product_brand and requested_brand_normalized in product_brand_normalized:
                #             brand_validated_list.append(product)
                #         else:
                #             debug_print(f"   ❌ Filtered out: {product.get('name')} (brand: {product_brand}, requested: {requested_brand})")
                #     
                #     if brand_validated_list:
                #         extracted_products = brand_validated_list
                #         debug_print(f"   ✅ {len(brand_validated_list)} products passed brand validation")
                #     else:
                #         debug_print(f"   ⚠️ All {original_count} products were filtered out by brand validation")
                #         extracted_products = []
                # 
                # # CRITICAL: If all products were filtered out, override agent response
                # # Don't show mismatched products to users
                # if not extracted_products and products_before_filtering > 0:
                #     debug_print(f"🚫 Overriding agent response - all products filtered out")
                #     criteria_parts = []
                #     if requested_category:
                #         criteria_parts.append(f"in the '{requested_category}' category")
                #     if max_price_budget:
                #         criteria_parts.append(f"under ${max_price_budget}")
                #     if requested_brand:
                #         criteria_parts.append(f"from {requested_brand}")
                #     
                #     criteria_str = " ".join(criteria_parts) if criteria_parts else "matching your criteria"
                #     
                #     response_content = f"I apologize, but I couldn't find any products {criteria_str}. "
                #     
                #     if requested_category:
                #         response_content += f"It appears we don't have '{requested_category}' items available "
                #         if max_price_budget:
                #             response_content += f"within your ${max_price_budget} budget. "
                #         else:
                #             response_content += "in our current inventory. "
                #     
                #     response_content += "\n\nWould you like to try:\n"
                #     response_content += "• Searching in a different category?\n"
                #     if max_price_budget:
                #         response_content += "• Adjusting your price range?\n"
                #     if requested_brand:
                #         response_content += "• Trying a different brand?\n"
                #     response_content += "• Broadening your search terms?"
                
                if extracted_products:
                    # Agent has already curated and filtered the products
                    # Just sort them by price for consistent display
                    extracted_products.sort(key=lambda p: p.get('price', 0))
            else:
                # No products found in agent response text
                # This can happen if the agent didn't format the response correctly or had no products to show
                debug_print("⚠️ No products found in agent response (expected format: '1. Product Name - $Price (Rating/5) - Description')")
        
        # Convert dict products to Product models with proper validation
        validated_products = None
        if extracted_products:
            try:
                validated_products = [Product(**product) for product in extracted_products]
            except Exception as validation_error:
                # Continue with empty products rather than failing the entire request
                validated_products = None
        
        # CRITICAL FIX: If agent hallucinated products (no tool results but mentioned products),
        # replace the content with a helpful "no results" message
        final_content = response_content
        if not validated_products and extracted_products is not None and len(extracted_products) == 0:
            # Check if the original agent response mentioned products
            if any(keyword in response_content.lower() for keyword in ['recommend:', 'based on', '$', 'rating', '/5']):
                # Agent likely hallucinated products - replace with no results message
                final_content = "Sorry, no matches found for your search. Try rephrasing your request or explore our product categories."
                debug_print("🔄 Replaced hallucinated agent response with 'no results' message")
        
        # If we have validated products, return the final assistant content
        if validated_products:
            if isinstance(full_response, dict):
                messages = full_response.get('messages', [])
                for msg in reversed(messages):
                    if isinstance(msg, dict) and msg.get('role') == 'assistant':
                        content = msg.get('content', '')
                        if content and len(content) > 50:
                            final_content = content
                            break
        
        return ChatResponse(
            content=final_content,
            products=validated_products,
            timestamp=datetime.now()
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to process chat request: {str(e)}"
        )


def send_order_confirmation_email(order: OrderSubmission, order_id: str) -> bool:
    """
    Send order confirmation email
    Returns True if email sent successfully, False otherwise
    """
    if not EMAIL_ENABLED:
        return False
    
    try:
        # Create email message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f'🛒 New Order Placed - Order #{order_id}'
        msg['From'] = f'AI Shopping Assistant <{SMTP_USERNAME}>'
        msg['To'] = ORDER_NOTIFICATION_EMAIL
        
        # Create HTML email body
        items_html = ""
        for item in order.items:
            items_html += f"""
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #eee;">
                    <strong>{item.name}</strong><br>
                    <span style="color: #666; font-size: 12px;">{item.brand} - {item.category}</span>
                </td>
                <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: center;">
                    x{item.quantity}
                </td>
                <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: right;">
                    ${item.price:.2f}
                </td>
            </tr>
            """
        
        html = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="background: linear-gradient(135deg, #FF3621 0%, #E62F1C 100%); color: white; padding: 30px; border-radius: 10px 10px 0 0;">
                    <h1 style="margin: 0; font-size: 28px;">🛒 New Order Received!</h1>
                    <p style="margin: 10px 0 0 0; opacity: 0.9;">Order #{order_id}</p>
                </div>
                
                <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
                    <h2 style="color: #FF3621; margin-top: 0;">Customer Information</h2>
                    <p><strong>Name:</strong> {order.full_name}</p>
                    <p><strong>Email:</strong> {order.email}</p>
                    <p><strong>Phone:</strong> {order.phone}</p>
                    
                    <h2 style="color: #FF3621; margin-top: 30px;">Shipping Address</h2>
                    <p>
                        {order.address}<br>
                        {order.city}, {order.state} {order.zip_code}
                    </p>
                    
                    <h2 style="color: #FF3621; margin-top: 30px;">Order Details</h2>
                    <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 5px;">
                        <thead>
                            <tr style="background: #FF3621; color: white;">
                                <th style="padding: 10px; text-align: left;">Product</th>
                                <th style="padding: 10px; text-align: center;">Qty</th>
                                <th style="padding: 10px; text-align: right;">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            {items_html}
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2" style="padding: 10px 15px; text-align: right; color: #666;">
                                    Subtotal:
                                </td>
                                <td style="padding: 10px 15px; text-align: right; color: #666;">
                                    ${order.subtotal:.2f}
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" style="padding: 10px 15px; text-align: right; color: #666;">
                                    Sales Tax (6.5%):
                                </td>
                                <td style="padding: 10px 15px; text-align: right; color: #666;">
                                    ${order.tax:.2f}
                                </td>
                            </tr>
                            <tr style="border-top: 2px solid #FF3621;">
                                <td colspan="2" style="padding: 15px; text-align: right; font-weight: bold; font-size: 18px;">
                                    Total:
                                </td>
                                <td style="padding: 15px; text-align: right; font-weight: bold; font-size: 18px; color: #FF3621;">
                                    ${order.total_price:.2f}
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                    
                    <h2 style="color: #FF3621; margin-top: 30px;">Payment Method</h2>
                    <p><strong>{order.payment_method.replace('_', ' ').title()}</strong>
                    {f' ending in {order.card_last_four}' if order.card_last_four else ''}</p>
                    
                    <div style="margin-top: 40px; padding: 20px; background: white; border-left: 4px solid #FF3621; border-radius: 5px;">
                        <p style="margin: 0; color: #666;">
                            <strong>Order placed at:</strong> {datetime.now().strftime('%B %d, %Y at %I:%M %p')}
                        </p>
                    </div>
                </div>
                
                <div style="text-align: center; margin-top: 30px; color: #999; font-size: 12px;">
                    <p>Conversational Commerce Search - AI-Powered Shopping Assistant</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        msg.attach(MIMEText(html, 'html'))
        
        # Send email
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
        
        return True
        
    except Exception as e:
        return False


def _fetch_customer_orders_from_lakebase(customer_name: str, customer_email: str):
    """Helper function to fetch orders from Lakebase (blocking operation)"""
    if not LAKEBASE_ENABLED or not lakebase:
        return []
    
    # Query to get all orders for this customer with their items
    query = """
        SELECT 
            h.order_id,
            h.order_timestamp,
            h.customer_name,
            h.customer_email,
            h.subtotal,
            h.tax,
            h.total_price,
            d.name,
            d.quantity,
            d.price
        FROM ORDERDB.ORDER_HEADER h
        LEFT JOIN ORDERDB.ORDER_DETAILS d ON h.order_id = d.order_id
        WHERE h.customer_name = %s AND h.customer_email = %s
        ORDER BY h.order_timestamp DESC
    """
    
    rows = lakebase.query(query, (customer_name, customer_email))
    
    # Group items by order_id
    orders_dict = {}
    for row in rows:
        order_id = row[0]
        if order_id not in orders_dict:
            orders_dict[order_id] = {
                'orderId': order_id,
                'timestamp': row[1].isoformat() if row[1] else None,
                'subtotal': float(row[4]) if row[4] else 0,
                'tax': float(row[5]) if row[5] else 0,
                'total': float(row[6]) if row[6] else 0,
                'items': []
            }
        
        # Add item if exists (LEFT JOIN may have orders without details)
        if row[7]:  # item name exists
            orders_dict[order_id]['items'].append({
                'name': row[7],
                'quantity': int(row[8]) if row[8] else 0,
                'price': float(row[9]) if row[9] else 0
            })
    
    # Convert to list (already in descending order from SQL)
    return list(orders_dict.values())


@app.get("/api/orders/{customer_name}")
async def get_customer_orders(customer_name: str, customer_email: str):
    """
    Fetch all orders for a customer from Lakebase
    Returns orders in descending order (most recent first)
    """
    try:
        # OPTIMIZATION: Run blocking Lakebase query in thread pool
        orders = await asyncio.to_thread(_fetch_customer_orders_from_lakebase, customer_name, customer_email)
        return orders
    except Exception as e:
        return []


def _persist_order_to_lakebase(order: OrderSubmission, order_id: str, order_timestamp: datetime):
    """Helper function to persist order to Lakebase (blocking operation)"""
    if not LAKEBASE_ENABLED or not lakebase:
        return
    
    try:
        # Insert ORDER_HEADER
        header_sql = """
            INSERT INTO ORDERDB.ORDER_HEADER (
                order_id, order_timestamp, customer_name, customer_email, phone,
                address, city, state, zip_code, payment_method, card_last_four,
                subtotal, tax, total_price, created_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        header_params = (
            order_id,
            order_timestamp,
            order.full_name,
            order.email,
            order.phone,
            order.address,
            order.city,
            order.state,
            order.zip_code,
            order.payment_method,
            order.card_last_four,
            order.subtotal,
            order.tax,
            order.total_price,
            order_timestamp
        )
        lakebase.query(header_sql, header_params)
        
        # Insert ORDER_DETAILS for each item
        detail_sql = """
            INSERT INTO ORDERDB.ORDER_DETAILS (
                order_detail_id, order_id, line_number, product_id, name,
                category, brand, price, quantity, line_total, created_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        for idx, item in enumerate(order.items, start=1):
            # Generate unique detail ID using UUID
            detail_unique_id = str(uuid.uuid4()).split('-')[0].upper()
            detail_id = f"ODT-{order_timestamp.strftime('%Y%m%d')}-{detail_unique_id}"
            detail_params = (
                detail_id,
                order_id,
                idx,
                item.product_id,
                item.name,
                item.category,
                item.brand,
                item.price,
                item.quantity,
                item.price * item.quantity,  # line_total
                order_timestamp
            )
            lakebase.query(detail_sql, detail_params)
    except Exception as db_error:
        # Don't fail the order submission if DB write fails
        pass


@app.post("/api/submit-order", response_model=OrderResponse)
async def submit_order(order: OrderSubmission):
    """
    Submit order, persist to Lakebase, and send email notification
    """
    try:
        # Generate unique order ID and timestamp
        order_timestamp = datetime.now()
        # Use UUID to ensure uniqueness (take first 8 chars of hex for readability)
        unique_id = str(uuid.uuid4()).split('-')[0].upper()
        order_id = f"ORD-{order_timestamp.strftime('%Y%m%d')}-{unique_id}"
        
        # OPTIMIZATION: Run blocking Lakebase operations in thread pool
        await asyncio.to_thread(_persist_order_to_lakebase, order, order_id, order_timestamp)
        
        # OPTIMIZATION: Run blocking email operation in thread pool
        email_sent = await asyncio.to_thread(send_order_confirmation_email, order, order_id)
        
        # Return success response
        return OrderResponse(
            success=True,
            order_id=order_id,
            message=f"Order {order_id} placed successfully!",
            email_sent=email_sent
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to submit order: {str(e)}"
        )


@app.get("/api/config")
async def get_config():
    """Get frontend configuration"""
    return {
        "serving_endpoint": SERVING_ENDPOINT,
        "max_tokens": MAX_TOKENS,
        "email_enabled": EMAIL_ENABLED,
        "features": {
            "customer_profiles": True,
            "interaction_history": True,
            "vector_search": True,
            "multi_turn_conversations": True,
            "order_notifications": EMAIL_ENABLED
        }
    }


# ============================================================================
# Static Files - Serve React Frontend
# ============================================================================

# Mount static files for React frontend
# Try multiple locations for the frontend (local dev vs Databricks deployment)
possible_frontend_dists = [
    Path(__file__).parent / "dist",  # Databricks deployment (flattened)
    Path(__file__).parent / "frontend-dist" / "dist",  # Databricks deployment (nested)
    Path(__file__).parent.parent / "Conversational-Commerce-Frontend" / "dist",  # Local dev
]

frontend_dist = None
for dist_path in possible_frontend_dists:
    if dist_path.exists():
        frontend_dist = dist_path
        break

if frontend_dist:
    app.mount("/assets", StaticFiles(directory=str(frontend_dist / "assets")), name="assets")


# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    port = int(os.getenv("PORT", "8000"))
    host = os.getenv("HOST", "0.0.0.0")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )

