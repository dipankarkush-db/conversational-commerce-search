"""
Lakebase singleton service for Postgres connection.
Manages connection lifecycle and token refresh.
"""
import os
import uuid
import time
import psycopg2
from databricks.sdk import WorkspaceClient
from databricks.sdk.config import Config
from typing import List, Tuple, Any
import logging

logger = logging.getLogger(__name__)


class Lakebase:
    """Singleton service for Lakebase (Postgres) database connection."""
    
    _instance = None
    _connection = None
    _connection_time = None
    _TOKEN_LIFETIME = 59 * 60  # 59 minutes in seconds
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Lakebase, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize configuration from environment variables."""
        if not hasattr(self, '_initialized'):
            self.databricks_host = os.getenv("DATABRICKS_HOST")
            self.lakebase_instance_name = os.getenv("LAKEBASE_INSTANCE_NAME")
            self.lakebase_db_name = os.getenv("LAKEBASE_DB_NAME")
            self.db_user = os.getenv("LAKEBASE_DB_USER")  
            self._initialized = True
    
    def _get_connection(self):
        """
        Get or create Lakebase connection.
        Refreshes token if connection is older than 59 minutes.
        """
        # Check if required env vars are set
        if not all([self.lakebase_instance_name, self.lakebase_db_name]):
            raise Exception(
                f"Missing required environment variables: "
                f"LAKEBASE_INSTANCE_NAME={self.lakebase_instance_name}, "
                f"LAKEBASE_DB_NAME={self.lakebase_db_name}"
            )
        
        current_time = time.time()
        
        # Check if we need to create a new connection or refresh token
        if (self._connection is None or 
            self._connection_time is None or 
            (current_time - self._connection_time) >= self._TOKEN_LIFETIME):
            
            # Close existing connection if any
            if self._connection:
                try:
                    self._connection.close()
                except Exception as e:
                    logger.warning(f"Error closing old connection: {e}")
            
            try:
                # Get Databricks workspace client (uses default app authentication)
                w = WorkspaceClient()
                
                # Generate new database credential
                cred = w.database.generate_database_credential(
                    request_id=str(uuid.uuid4()),
                    instance_names=[self.lakebase_instance_name]
                )
                
                # Get database instance info
                instance = w.database.get_database_instance(name=self.lakebase_instance_name)
                
                # Create new connection
                self._connection = psycopg2.connect(
                    host=instance.read_write_dns,
                    dbname=self.lakebase_db_name,
                    user=self.db_user,
                    password=cred.token,
                    sslmode="require",
                )
                
                self._connection_time = current_time
            
            except Exception as e:
                logger.error(f"❌ [Here]Failed to connect to Lakebase: {e}")
                raise
        
        return self._connection
    
    def query(self, sql: str, params: Tuple[Any, ...] = None) -> List[Tuple]:
        """
        Execute SQL query and return results.
        
        Args:
            sql: SQL query string (use %s for parameters)
            params: Tuple of parameters for parameterized query
            
        Returns:
            List of tuples (rows)
        """
        conn = self._get_connection()
        
        try:
            with conn.cursor() as cur:
                if params:
                    cur.execute(sql, params)
                else:
                    cur.execute(sql)
                
                # Check if it's a SELECT query
                is_select = sql.strip().upper().startswith('SELECT')
                
                if is_select:
                    rows = cur.fetchall()
                    conn.commit()  # Commit to close transaction
                else:
                    # For INSERT/UPDATE/DELETE, commit and return empty list
                    conn.commit()
                    rows = []
                
                return rows
        except Exception as e:
            # Rollback on error to reset transaction state
            try:
                conn.rollback()
            except Exception as rollback_error:
                logger.error(f"Failed to rollback transaction: {rollback_error}")
            raise e
    
    def close(self):
        """Close the database connection."""
        if self._connection:
            try:
                self._connection.close()
                self._connection = None
                self._connection_time = None
            except Exception as e:
                logger.error(f"Error closing connection: {e}")


# Singleton instance
lakebase = Lakebase()

