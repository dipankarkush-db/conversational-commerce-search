# Conversational Commerce Search - NRF Conference Video Script
## Duration: ~4 minutes 30 seconds

---

### **[0:00 - 0:40] SECTION 1: THE ENGINEERING CHALLENGE**
**[Visual: Clean visualization of a search index architecture. A query enters one side, hits a bottleneck of keyword matching, and results drop out. No "frustrated user" faces, just a technical diagram showing the disconnect.]**

**Narrator:** "Standard e-commerce search relies on keyword matching. It’s deterministic and rigid. When a user asks a complex question, the system breaks because it lacks two critical dimensions: semantic understanding and user context."

**[Visual: Text appears: 'The Missing Link: Context + Semantics'. Transition to the application architecture diagram showing 'Databricks Lakebase' and 'Unity Catalog'.]**

**Narrator:** "We built Conversational Commerce Search to solve this using a hybrid retrieval system. It’s not just wrapping an LLM around a database. It’s a sophisticated engineering pipeline built on Databricks Unity Catalog."

---

### **[0:40 - 1:30] SECTION 2: DATA INGESTION & VECTORIZATION**
**[Visual: Screen recording of the Admin Panel, specifically the 'Customer Profile' modal. Cursor highlights the 'Recent Shopping History' and 'Basket Intelligence' sections.]**

**Narrator:** "It starts with the data. We ingest real-time signals—clickstreams, purchases, and even external social signals—into our Lakebase. But we don't just store them; we vectorize them."

**[Visual: Animated overlay showing raw data turning into vectors (arrays of numbers). Show the `user_features` and `product_desc_index` tables conceptually.]**

**Narrator:** "Every customer profile is converted into a high-dimensional vector embedding. This allows us to mathematically represent a user's taste—their price sensitivity, brand affinity, and style preferences—in the same geometric space as our product catalog."

---

### **[1:30 - 2:50] SECTION 3: ANATOMY OF A SEARCH QUERY**
**[Visual: Transition to the main app 'AI Shopping Assistant'. The user types: *"I am moving to a new apartment and need durability without overspending."*]**

**Narrator:** "Let's look at what happens under the hood when a query runs. This triggers our core function: `get_smart_product_recommendations`."

**[Visual: Split screen. Left side: The chat interface showing the 'Thinking' state. Right side: A simplified flowchart of the function logic overlaying the code.]**

**Narrator:** "First, **Semantic Analysis**. The system parses 'moving to a new apartment' not as keywords, but as an intent vector. It understands this implies a need for home essentials across categories."

**[Visual: Highlight 'Step 2: Collaborative Filtering' on the flowchart.]**

**Narrator:** "Second, **Collaborative Filtering**. The engine identifies the user's vector and finds 'nearest neighbor' shoppers—people with similar profiles. It looks at what *they* bought for new apartments, leveraging collective intelligence."

**[Visual: Highlight 'Step 3: Hybrid Scoring' on the flowchart.]**

**Narrator:** "Third, **Hybrid Scoring**. We execute a multi-factor ranking algorithm. We combine the semantic score from the query with the user's affinity score. We apply a penalty if the price exceeds their historical sensitivity and boost items with high durability ratings."

**[Visual: The results load on the left screen. Highlight the 'Why this?' text.]**

**Narrator:** "The result isn't a random list. It's a deterministic output based on a weighted probability model: 35% user similarity, 25% semantic match, and 15% interaction history. This ensures relevance."

---

### **[2:50 - 3:40] SECTION 4: EXPLAINABLE AI & TRANSPARENCY**
**[Visual: Mouse hovers over a recommended vacuum cleaner. A tooltip or text block explains: *"Recommended because users similar to you rated this highly for durability."*]**

**Narrator:** "Crucially, this is Explainable AI. Because we track the provenance of the score—whether it came from the vector match or the collaborative filtering—we can tell the user *exactly* why an item was chosen."

**[Visual: User switches to the 'Browse' tab. The products re-shuffle.]**

**Narrator:** "This logic extends to the Browse interface. We re-rank the static catalog dynamically. The 'default' sort order is actually a personalized query running in the background, ensuring that even passive browsing is optimized for the individual."

---

### **[3:40 - 4:15] SECTION 5: OPERATIONAL EFFICIENCY**
**[Visual: Back to the Admin view, showing the 'Basket Intelligence' graph.]**

**Narrator:** "For the engineering team, this architecture is efficient. By pre-computing embeddings and using Databricks Vector Search, we achieve sub-second latency even with complex, multi-stage filtering."

**[Visual: Show the 'Orders Panel' processing a checkout.]**

**Narrator:** "It scales horizontally. Whether you have ten thousand users or ten million, the vector search complexity remains logarithmic, ensuring consistent performance."

---

### **[4:15 - 4:30] SECTION 6: CONCLUSION**
**[Visual: Simple logo on a white background. URL at the bottom.]**

**Narrator:** "Conversational Commerce Search. It’s professional-grade personalized retrieval, built for scale. Experience the engineering difference today."

---
