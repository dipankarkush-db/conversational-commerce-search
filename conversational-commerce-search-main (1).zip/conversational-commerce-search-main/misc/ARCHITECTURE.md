# Architecture Overview - React + FastAPI Databricks App

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         USER BROWSER                                 │
│                                                                       │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │              React Frontend (Port 5173)                     │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │    │
│  │  │ Launch   │  │  Chat    │  │ Product  │  │  User    │  │    │
│  │  │ Page     │  │Interface │  │  Cards   │  │ Profile  │  │    │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │    │
│  │                        │                                    │    │
│  │                        │ API Calls (REST)                  │    │
│  │                        ▼                                    │    │
│  │                  ┌──────────┐                              │    │
│  │                  │ api.ts   │                              │    │
│  │                  │ Service  │                              │    │
│  │                  └──────────┘                              │    │
│  └────────────────────────┼───────────────────────────────────┘    │
└────────────────────────────┼────────────────────────────────────────┘
                             │
                             │ HTTP/HTTPS
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│                    FastAPI Backend (Port 8000)                       │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                      API Endpoints                           │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │   │
│  │  │  /health │  │/customer │  │  /chat   │  │ /config  │   │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │   │
│  └──────────────────────┬──────────────────────────────────────┘   │
│                         │                                            │
│  ┌──────────────────────▼──────────────────────────────────────┐   │
│  │              Business Logic Layer                            │   │
│  │  • Customer context building                                 │   │
│  │  • Message formatting                                        │   │
│  │  • Error handling & fallbacks                               │   │
│  └──────────────────────┬──────────────────────────────────────┘   │
└────────────────────────┼────────────────────────────────────────────┘
                         │
                         │ Databricks SDK
                         │
┌────────────────────────▼────────────────────────────────────────────┐
│                    DATABRICKS PLATFORM                               │
│                                                                       │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                    Unity Catalog                               │ │
│  │  ┌──────────────────────────────────────────────────────────┐ │ │
│  │  │  Catalog: retail_consumer_goods                          │ │ │
│  │  │  Schema: conversational_commerce_search                  │ │ │
│  │  │                                                           │ │ │
│  │  │  Functions:                                              │ │ │
│  │  │  • get_random_customer_info()                           │ │ │
│  │  │  • get_customer_interactions(name, email)              │ │ │
│  │  │                                                           │ │ │
│  │  │  Tables:                                                 │ │ │
│  │  │  • products                                              │ │ │
│  │  │  • customers                                             │ │ │
│  │  │  • interactions                                          │ │ │
│  │  │  • product_embeddings                                    │ │ │
│  │  └──────────────────────────────────────────────────────────┘ │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                       │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                    Vector Search                               │ │
│  │  • Product embeddings (BGE-Large-EN)                          │ │
│  │  • Semantic similarity search                                 │ │
│  │  • Real-time indexing                                         │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                       │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                    Model Serving                               │ │
│  │  Endpoint: conversational_commerce_agent                      │ │
│  │  Model: Claude 3.5 Sonnet                                     │ │
│  │  Task: llm/v1/chat or agent/v1/chat                          │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                       │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                    SQL Warehouse                               │ │
│  │  • Execute UC functions                                        │ │
│  │  • Query customer data                                         │ │
│  │  • Fetch interaction history                                  │ │
│  └───────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────┘
```

## 🔄 Request Flow

### 1. Customer Login Flow

```
User clicks "Start Shopping"
         │
         ▼
React: handleLogin()
         │
         ▼
API: GET /api/customer/random
         │
         ▼
FastAPI: get_random_customer()
         │
         ▼
Databricks: WorkspaceClient.statement_execution
         │
         ▼
Unity Catalog: get_random_customer_info()
         │
         ▼
SQL Warehouse: Execute function
         │
         ▼
Return: CustomerInfo JSON
         │
         ▼
React: Display customer profile
```

### 2. Chat Message Flow

```
User types message
         │
         ▼
React: handleSendMessage()
         │
         ▼
API: POST /api/chat
  Body: {
    customer_id,
    customer_name,
    customer_email,
    messages: [...],
    max_tokens: 400
  }
         │
         ▼
FastAPI: chat_endpoint()
         │
         ├─► Build customer context
         │   (name, persona, preferences,
         │    recent interactions)
         │
         ├─► Format messages array
         │   [system, ...history, user]
         │
         ▼
MLflow: get_deploy_client('databricks')
         │
         ▼
Model Serving: conversational_commerce_agent
         │
         ├─► Claude 3.5 Sonnet
         │   (Natural language understanding)
         │
         ├─► Unity Catalog Functions
         │   (Product recommendations)
         │
         ├─► Vector Search
         │   (Semantic similarity)
         │
         ▼
Return: AI Response
         │
         ▼
FastAPI: Parse response
         │
         ▼
React: Display message + products
```

## 📦 Component Breakdown

### Frontend Components

```
App.tsx
├── LaunchPage.tsx (Login screen)
│   └── Button (Start Shopping)
│
└── ChatInterface.tsx (Main app)
    ├── UserProfilePanel.tsx
    │   ├── Customer info display
    │   └── Recent interactions
    │
    ├── ChatMessage.tsx (Message display)
    │   └── ProductCard.tsx (Product recommendations)
    │
    └── Input + Send Button
```

### Backend Endpoints

```
FastAPI (main.py)
│
├── GET /
│   └── Health check
│
├── GET /api/health
│   └── Detailed status
│
├── GET /api/customer/random
│   ├── Call: get_random_customer()
│   └── Return: CustomerInfo
│
├── GET /api/customer/{name}/interactions
│   ├── Call: get_customer_interactions()
│   └── Return: List[CustomerInteraction]
│
├── POST /api/chat
│   ├── Build customer context
│   ├── Call: query_model_endpoint()
│   └── Return: ChatResponse
│
└── GET /api/config
    └── Return: Frontend configuration
```

## 🔐 Authentication Flow

```
┌─────────────┐
│   Browser   │
└──────┬──────┘
       │
       │ 1. Request with Databricks token
       │
┌──────▼──────┐
│   FastAPI   │
└──────┬──────┘
       │
       │ 2. Initialize WorkspaceClient
       │    (uses DATABRICKS_HOST + TOKEN)
       │
┌──────▼──────────────┐
│  Databricks SDK     │
│  WorkspaceClient    │
└──────┬──────────────┘
       │
       │ 3. Authenticate & execute
       │
┌──────▼──────────────┐
│  Databricks         │
│  Platform           │
└─────────────────────┘
```

## 🌐 Data Flow

### Customer Data

```
Unity Catalog (customers table)
         │
         ▼
get_random_customer_info() function
         │
         ▼
SQL Warehouse execution
         │
         ▼
FastAPI: GET /api/customer/random
         │
         ▼
React: UserProfile state
         │
         ▼
Display in UserProfilePanel
```

### Interaction History

```
Unity Catalog (interactions table)
         │
         ▼
get_customer_interactions() function
         │
         ▼
SQL Warehouse execution
         │
         ▼
FastAPI: GET /api/customer/{name}/interactions
         │
         ▼
React: Display in sidebar
```

### Chat Messages

```
User Input
         │
         ▼
React: messages state
         │
         ▼
FastAPI: POST /api/chat
         │
         ├─► Add customer context
         │
         ├─► Query model endpoint
         │   │
         │   ├─► Claude 3.5 Sonnet
         │   │
         │   └─► Unity Catalog functions
         │       (for product data)
         │
         ▼
AI Response
         │
         ▼
React: Display in ChatMessage
```

## 🔧 Configuration Flow

### Environment Variables

```
Databricks Apps
         │
         ▼
app.yaml resources
         │
         ├─► serving-endpoint
         │   └─► SERVING_ENDPOINT env var
         │
         └─► sql-warehouse
             └─► DATABRICKS_WAREHOUSE_ID env var
         │
         ▼
FastAPI reads env vars
         │
         ▼
WorkspaceClient initialization
         │
         ▼
Connect to Databricks resources
```

## 📊 State Management

### React State Flow

```
App.tsx
├── currentUser: UserProfile | null
├── isLoading: boolean
│
└── ChatInterface.tsx
    ├── messages: Message[]
    ├── input: string
    ├── isLoading: boolean
    │
    └── UserProfilePanel.tsx
        └── user: UserProfile (props)
```

### Backend State

```
FastAPI (Stateless)
│
├── Request comes in
│
├── Process with Databricks
│
├── Return response
│
└── No state stored
    (All state in React or Databricks)
```

## 🚀 Deployment Architecture

### Development

```
localhost:5173 (React Dev Server)
         │
         │ API calls
         ▼
localhost:8000 (FastAPI Dev Server)
         │
         │ Databricks SDK
         ▼
Databricks Workspace
```

### Production (Databricks Apps)

```
Databricks App (Frontend)
         │
         │ HTTPS
         ▼
Databricks App (Backend)
         │
         │ Internal network
         ▼
Unity Catalog / Model Serving
(Same workspace)
```

## 🎯 Key Design Decisions

### 1. Separation of Concerns
- **Frontend:** Pure UI/UX, no business logic
- **Backend:** Business logic, Databricks integration
- **Databricks:** Data storage, AI models

### 2. API-First Design
- RESTful endpoints
- JSON request/response
- Stateless backend

### 3. Error Handling
- Frontend: Fallback to mock data
- Backend: Try-catch with logging
- User-friendly error messages

### 4. Type Safety
- Frontend: TypeScript interfaces
- Backend: Pydantic models
- API: Consistent JSON schemas

### 5. Scalability
- Frontend: Can deploy to CDN
- Backend: Horizontal scaling
- Databricks: Auto-scaling

---

**This architecture provides:**
- ✅ Separation of concerns
- ✅ Scalability
- ✅ Maintainability
- ✅ Type safety
- ✅ Error resilience
- ✅ Production readiness

