/**
 * API Service for Conversational Commerce Search
 * Connects React frontend to FastAPI backend
 */

// In production (Databricks Apps), use relative URLs (same origin)
// In development, use localhost
const API_BASE_URL = import.meta.env.VITE_API_URL || (
  import.meta.env.MODE === 'production' ? '' : 'http://localhost:8000'
);

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface Product {
  product_id: string;
  name: string;
  category: string;
  subcategory: string;
  brand: string;
  price: number;
  description: string;
  avg_rating: number;
  features?: Record<string, any>;
}

export interface ChatRequest {
  customer_id: string;
  customer_name: string;
  customer_email: string;
  messages: Message[];
  max_tokens?: number;
}

export interface ChatResponse {
  content: string;
  products?: Product[];
  timestamp: string;
}

export interface CustomerInfo {
  customer_id: string;
  customer_name: string;
  customer_email: string;
  customer_age?: number;
  customer_gender?: string;
  customer_location?: string;
  persona?: string;
  brand_loyalty?: string;
  price_sensitivity?: string;
  preferred_categories?: string;
  total_orders?: number;
  total_spent?: number;
}

export interface CustomerInteraction {
  customer_name: string;
  customer_email: string;
  product_name: string;
  product_price: number;
  interaction_type: string;
  interaction_timestamp: string;
  customer_rating?: number;
  product_category?: string;
  product_brand?: string;
  days_since_interaction?: number;
}

export interface OrderItem {
  product_id: string;
  name: string;
  category: string;
  brand: string;
  price: number;
  quantity: number;
}

export interface OrderSubmission {
  customer_name: string;
  customer_email: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total_price: number;
  full_name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip_code: string;
  payment_method: string;
  card_last_four?: string;
}

export interface OrderResponse {
  success: boolean;
  order_id: string;
  message: string;
  email_sent: boolean;
}

/**
 * Health check endpoint
 */
export async function checkHealth(): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/health`);
  if (!response.ok) {
    throw new Error('API health check failed');
  }
  return response.json();
}

/**
 * Get a random customer profile
 */
export async function getRandomCustomer(): Promise<CustomerInfo> {
  const url = `${API_BASE_URL}/api/customer/random`;
  
  const response = await fetch(url);
  
  if (!response.ok) {
    const errorText = await response.text();
    console.error('❌ Error response:', errorText);
    throw new Error(`Failed to fetch customer: ${response.status} ${errorText}`);
  }
  
  const data = await response.json();
  return data;
}

/**
 * Get admin customers (6 from each persona)
 */
export async function getAdminCustomers(): Promise<CustomerInfo[]> {
  const url = `${API_BASE_URL}/api/admin/customers`;
  
  const response = await fetch(url);
  
  if (!response.ok) {
    const errorText = await response.text();
    console.error('❌ Error response:', errorText);
    throw new Error(`Failed to fetch admin customers: ${response.status} ${errorText}`);
  }
  
  const data = await response.json();
  return data;
}

/**
 * Clear admin customers cache to force fresh data on next fetch
 */
export async function clearAdminCustomersCache(): Promise<void> {
  const url = `${API_BASE_URL}/api/admin/customers/cache`;
  
  const response = await fetch(url, {
    method: 'DELETE'
  });
  
  if (!response.ok) {
    const errorText = await response.text();
    console.error('❌ Error response:', errorText);
    throw new Error(`Failed to clear admin cache: ${response.status} ${errorText}`);
  }
  
  await response.json();
}

/**
 * Get customer interaction history
 */
export async function getCustomerInteractions(
  customerName: string,
  customerEmail: string
): Promise<CustomerInteraction[]> {
  const params = new URLSearchParams({
    customer_email: customerEmail
  });
  
  const response = await fetch(
    `${API_BASE_URL}/api/customer/${encodeURIComponent(customerName)}/interactions?${params}`
  );
  
  if (!response.ok) {
    throw new Error('Failed to fetch customer interactions');
  }
  return response.json();
}

/**
 * Send chat message and get AI response
 */
export async function sendChatMessage(request: ChatRequest): Promise<ChatResponse> {
  const response = await fetch(`${API_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(request),
  });
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || 'Failed to send chat message');
  }
  
  return response.json();
}

/**
 * Get API configuration
 */
export async function getConfig(): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/config`);
  if (!response.ok) {
    throw new Error('Failed to fetch config');
  }
  return response.json();
}

/**
 * Submit order and send email notification
 */
export async function submitOrder(order: OrderSubmission): Promise<OrderResponse> {
  const response = await fetch(`${API_BASE_URL}/api/submit-order`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(order),
  });
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || 'Failed to submit order');
  }
  
  return response.json();
}

/**
 * Get customer orders from Lakebase (descending order - most recent first)
 */
export async function getCustomerOrders(
  customerName: string,
  customerEmail: string
): Promise<Array<{
  orderId: string;
  timestamp: string;
  subtotal: number;
  tax: number;
  total: number;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
}>> {
  const params = new URLSearchParams({
    customer_email: customerEmail
  });
  
  const response = await fetch(
    `${API_BASE_URL}/api/orders/${encodeURIComponent(customerName)}?${params}`
  );
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || 'Failed to fetch customer orders');
  }
  
  return response.json();
}

