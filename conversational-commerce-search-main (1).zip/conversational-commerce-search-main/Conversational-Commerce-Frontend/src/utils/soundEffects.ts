/**
 * Sound Effects Utility using Web Audio API
 * Generates success chimes without requiring audio files
 */

// Create audio context (singleton)
let audioContext: AudioContext | null = null;

const getAudioContext = (): AudioContext => {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioContext;
};

// Sound preference management
const SOUND_ENABLED_KEY = 'convo-commerce-sound-enabled';

export const isSoundEnabled = (): boolean => {
  const stored = localStorage.getItem(SOUND_ENABLED_KEY);
  // Default to enabled if not set
  return stored === null ? true : stored === 'true';
};

export const setSoundEnabled = (enabled: boolean): void => {
  localStorage.setItem(SOUND_ENABLED_KEY, enabled.toString());
};

/**
 * Play a musical note progression (do-re-mi-fa-sol)
 * Each step plays the next note in the scale for a satisfying progression
 */
export const playSuccessChime = (stepNumber: number = 1) => {
  // Check if sound is enabled
  if (!isSoundEnabled()) {
    return;
  }

  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    // Musical scale frequencies (C5 major scale: do-re-mi-fa-sol)
    const notes = [
      523, // Do (C5) - Step 1
      587, // Re (D5) - Step 2
      659, // Mi (E5) - Step 3
      698, // Fa (F5) - Step 4
      784  // Sol (G5) - Step 5
    ];

    // Get the frequency for this step (wrap around if more than 5 steps)
    const frequency = notes[(stepNumber - 1) % notes.length];

    // Create oscillator for the musical note
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    // Set the note frequency
    oscillator.frequency.setValueAtTime(frequency, now);

    // Envelope - quick attack, bell-like decay
    gainNode.gain.setValueAtTime(0, now);
    gainNode.gain.linearRampToValueAtTime(0.22, now + 0.01); // Sharp attack
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.35); // Bell-like fade

    // Use sine wave for pure, clean tone
    oscillator.type = 'sine';

    // Play
    oscillator.start(now);
    oscillator.stop(now + 0.35);
  } catch (error) {
    // Silently fail if audio context is not available
    console.debug('Audio playback not available:', error);
  }
};

/**
 * Initialize audio context on user interaction
 * Call this when user clicks "Start Shopping" or similar
 */
export const initializeAudio = () => {
  try {
    const ctx = getAudioContext();
    // Resume context if it's suspended (browser autoplay policy)
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
  } catch (error) {
    console.debug('Audio initialization not available:', error);
  }
};

