import { useState, useEffect, useRef } from 'react';
import { LaunchPage } from './components/LaunchPage';
import { ChatInterface } from './components/ChatInterface';
import { Header } from './components/Header';
import { CartDrawer } from './components/CartDrawer';
import { CartPanel } from './components/CartPanel';
import { OrdersPanel } from './components/OrdersPanel';
import { MiniCart } from './components/MiniCart';
import { Sidebar } from './components/Sidebar';
import { BrowseProducts } from './components/BrowseProducts';
import { AdminAuthModal } from './components/AdminAuthModal';
import { AdminCustomerGrid } from './components/AdminCustomerGrid';
import { CartProvider, useCart } from './contexts/CartContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { ShoppingBag, ShoppingCart, Receipt, Grid3x3, Sparkles } from 'lucide-react';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner';
import { getRandomCustomer, getCustomerInteractions, getCustomerOrders, clearAdminCustomersCache, CustomerInfo, CustomerInteraction } from './services/api';

interface UserProfile {
  customer_id: string;
  name: string;
  email: string;
  gender?: string;
  persona: string;
  preferred_categories: string[];
  price_sensitivity: string;
  brand_loyalty: string;
  total_purchases: number;
  total_spent: number;
  favorite_brands: string[];
  recent_searches: string[];
  purchase_history: PurchaseItem[];
}

interface PurchaseItem {
  product_name: string;
  category: string;
  price: number;
  date: string;
  rating?: number;
}

interface Order {
  orderId: string;
  timestamp: Date;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
  subtotal: number;
  tax: number;
  total: number;
}

function MainApp() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [customerInteractions, setCustomerInteractions] = useState<CustomerInteraction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [showMiniCart, setShowMiniCart] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [headerSearchValue, setHeaderSearchValue] = useState('');
  const [activeTab, setActiveTab] = useState('ai-assistant');
  const [isSearchLoading, setIsSearchLoading] = useState(false);
  const { itemCount, clearCart } = useCart();
  const miniCartRef = useRef<HTMLDivElement>(null);
  
  // Admin state
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [showAdminAuthModal, setShowAdminAuthModal] = useState(false);
  const [showAdminGrid, setShowAdminGrid] = useState(false);

  // Fetch orders from Lakebase for current customer
  const fetchOrders = async (customerName: string, customerEmail: string) => {
    try {
      const fetchedOrders = await getCustomerOrders(customerName, customerEmail);
      // Convert timestamp strings to Date objects
      const ordersWithDates = fetchedOrders.map(order => ({
        ...order,
        timestamp: new Date(order.timestamp)
      }));
      setOrders(ordersWithDates);
    } catch (error) {
      console.error('Failed to fetch orders:', error);
      setOrders([]); // Set empty array on error
    }
  };

  // Handle clicking outside mini cart to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (miniCartRef.current && !miniCartRef.current.contains(event.target as Node)) {
        setShowMiniCart(false);
      }
    };

    if (showMiniCart) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showMiniCart]);

  // Handle cart hover
  const handleCartHover = (isHovering: boolean) => {
    if (isHovering && itemCount > 0) {
      setShowMiniCart(true);
    }
  };

  const handleLogin = async () => {
    setIsLoading(true);
    
    // Clear cart for new customer session
    clearCart();
    
    try {
      // Fetch a random customer from the FastAPI backend
      const customer = await getRandomCustomer();
      
      // Convert CustomerInfo to UserProfile format
      const userProfile: UserProfile = {
        customer_id: customer.customer_id,
        name: customer.customer_name,
        email: customer.customer_email,
        gender: customer.customer_gender,
        persona: customer.persona || 'Unknown',
        preferred_categories: customer.preferred_categories 
          ? customer.preferred_categories.split(',').map(c => c.trim())
          : [],
        price_sensitivity: customer.price_sensitivity || 'Medium',
        brand_loyalty: customer.brand_loyalty || 'Medium',
        total_purchases: customer.total_orders || 0,
        total_spent: customer.total_spent || 0,
        favorite_brands: [],
        recent_searches: [],
        purchase_history: []
      };
      
      setCurrentUser(userProfile);
      toast.success(`Welcome, ${customer.customer_name}!`);
      
      // ⚡ OPTIMIZATION: Fetch interactions and orders in parallel (non-blocking)
      // Don't await - let them load in background
      Promise.allSettled([
        // Fetch customer interactions
        getCustomerInteractions(customer.customer_name, customer.customer_email)
          .then(setCustomerInteractions)
          .catch((error) => {
            console.error('⚠️ Failed to fetch interactions:', error);
            setCustomerInteractions([]);
          }),
        
        // Fetch customer order history from Lakebase
        fetchOrders(customer.customer_name, customer.customer_email)
      ]);
    } catch (error) {
      console.error('❌ Failed to fetch customer:', error);
      console.error('❌ Error details:', error);
      toast.error('Failed to load customer profile from database. Please check logs.');
      // NO FALLBACK - force it to fail so we can see the real error
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCustomerInteractions([]);
    clearCart(); // Clear shopping cart on logout
    setOrders([]); // Clear orders on logout
    toast.info('Logged out successfully');
  };

  const handleAdminClick = () => {
    // Always require password when entering admin experience
    setIsAdminAuthenticated(false);
    setShowAdminAuthModal(true);
  };

  const handleAdminAuthenticate = () => {
    setIsAdminAuthenticated(true);
    setShowAdminAuthModal(false);
    setShowAdminGrid(true);
    toast.success('Admin access granted');
  };

  const handleAdminSelectCustomer = async (customer: CustomerInfo) => {
    setIsLoading(true);
    setShowAdminGrid(false);
    
    // Clear cart for new customer session
    clearCart();
    
    try {
      // Convert CustomerInfo to UserProfile format
      const userProfile: UserProfile = {
        customer_id: customer.customer_id,
        name: customer.customer_name,
        email: customer.customer_email,
        gender: customer.customer_gender,
        persona: customer.persona || 'Unknown',
        preferred_categories: customer.preferred_categories 
          ? customer.preferred_categories.split(',').map(c => c.trim())
          : [],
        price_sensitivity: customer.price_sensitivity || 'Medium',
        brand_loyalty: customer.brand_loyalty || 'Medium',
        total_purchases: customer.total_orders || 0,
        total_spent: customer.total_spent || 0,
        favorite_brands: [],
        recent_searches: [],
        purchase_history: []
      };
      
      setCurrentUser(userProfile);
      setIsAdminMode(true); // Mark as admin mode
      toast.success(`Viewing ${customer.customer_name}'s profile`);
      
      // Fetch interactions and orders in parallel
      Promise.allSettled([
        getCustomerInteractions(customer.customer_name, customer.customer_email)
          .then(setCustomerInteractions)
          .catch((error) => {
            console.error('Failed to fetch interactions:', error);
            setCustomerInteractions([]);
          }),
        fetchOrders(customer.customer_name, customer.customer_email)
      ]);
    } catch (error) {
      console.error('Failed to load customer:', error);
      toast.error('Failed to load customer profile');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdminBackToGrid = () => {
    setCurrentUser(null);
    setCustomerInteractions([]);
    clearCart();
    setOrders([]);
    setIsAdminMode(false);
    // Keep authentication - just go back to grid (no password needed)
    setShowAdminGrid(true);
  };

  const handleAdminBackToLaunch = async () => {
    setShowAdminGrid(false);
    setIsAdminMode(false);
    setCurrentUser(null);
    setCustomerInteractions([]);
    clearCart();
    setOrders([]);
    // Clear authentication so password is required next time
    setIsAdminAuthenticated(false);
    
    // Clear admin customers cache so new customers are fetched next time
    try {
      await clearAdminCustomersCache();
      console.log('Admin customers cache cleared');
    } catch (error) {
      console.error('Failed to clear admin cache:', error);
      // Don't show error to user, just log it
    }
  };

  const handleOrderSubmitted = async () => {
    // Refetch orders from Lakebase after submission
    if (currentUser) {
      await fetchOrders(currentUser.name, currentUser.email);
    }
    setIsCheckoutOpen(false); // Close checkout after order
    setIsCartOpen(false); // Close cart drawer too
  };

  // Show loading experience when fetching customer
  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF3621] mb-4"></div>
          <p className="text-gray-600">Loading your profile...</p>
        </div>
        <Toaster />
      </div>
    );
  }

  // Show admin customer grid if in admin mode
  if (showAdminGrid) {
    return (
      <>
        <AdminCustomerGrid 
          onSelectCustomer={handleAdminSelectCustomer}
          onBack={handleAdminBackToLaunch}
        />
        <Toaster />
      </>
    );
  }

  // Show launch page if no user is logged in
  if (!currentUser) {
    return (
      <>
        <LaunchPage 
          onLogin={handleLogin} 
          onAdminClick={handleAdminClick}
          isLoading={false} 
        />
        <AdminAuthModal
          isOpen={showAdminAuthModal}
          onClose={() => {
            setShowAdminAuthModal(false);
            // If closing modal without auth, make sure we're not stuck
            setIsAdminAuthenticated(false);
            setShowAdminGrid(false);
          }}
          onAuthenticate={handleAdminAuthenticate}
        />
        <Toaster />
      </>
    );
  }

  // Show main app when user is logged in
  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      {/* Admin Auth Modal - Show when admin needs to re-authenticate */}
      <AdminAuthModal
        isOpen={showAdminAuthModal}
        onClose={() => {
          setShowAdminAuthModal(false);
          // If in admin mode and closing without auth, go back to launch
          if (isAdminMode) {
            setCurrentUser(null);
            setCustomerInteractions([]);
            clearCart();
            setOrders([]);
            setIsAdminMode(false);
            setIsAdminAuthenticated(false);
          }
        }}
        onAuthenticate={handleAdminAuthenticate}
      />
      
      {/* Enhanced Header */}
      <Header 
        cartCount={itemCount}
        onCartClick={() => setIsCheckoutOpen(true)}
        ordersCount={orders.length}
        onOrdersClick={() => setIsOrdersOpen(true)}
        userName={currentUser.name}
        userEmail={currentUser.email}
        totalPurchases={currentUser.total_purchases}
        onLogout={isAdminMode ? handleAdminBackToGrid : handleLogout}
        searchValue={headerSearchValue}
        onSearchChange={setHeaderSearchValue}
        onSearchSubmit={() => {
          if (headerSearchValue.trim()) {
            // Switch to AI Assistant tab
            setActiveTab('ai-assistant');
            // Trigger chat interface to send the message
            const event = new CustomEvent('headerSearch', { detail: headerSearchValue });
            window.dispatchEvent(event);
            setHeaderSearchValue(''); // Clear header search after submitting
          }
        }}
        onPopulateSearch={setHeaderSearchValue}
        onCartHover={handleCartHover}
        isAdminMode={isAdminMode}
        isSearchDisabled={isSearchLoading}
      />

      {/* Mini Cart - Shows on cart hover, persists until clicked outside */}
      <div ref={miniCartRef} className="fixed top-12 right-36 z-50 pointer-events-none">
        <div className="pointer-events-auto">
          <MiniCart 
            isVisible={showMiniCart} 
            onViewCart={() => {
              setShowMiniCart(false);
              setIsCheckoutOpen(true);
            }}
            onClose={() => setShowMiniCart(false)}
          />
        </div>
      </div>

      {/* Main Content with Sidebar */}
      <div className="container mx-auto px-4 py-1">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Sidebar - Hidden on mobile */}
          <div className="hidden lg:block lg:col-span-1">
            <Sidebar
              userName={currentUser.name}
              userEmail={currentUser.email}
              totalPurchases={currentUser.total_purchases}
              totalSpent={`$${currentUser.total_spent.toFixed(2)}`}
              persona={currentUser.persona}
              priceSensitivity={currentUser.price_sensitivity}
              brandLoyalty={currentUser.brand_loyalty}
              preferences={currentUser.preferred_categories}
              interactions={customerInteractions}
              isSearchDisabled={isSearchLoading}
            />
          </div>

          {/* Main Content Area with Tabs */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-1 bg-gray-50 p-0.5 rounded-full h-11 border border-gray-200 items-center">
                <TabsTrigger 
                  value="browse" 
                  className="flex items-center justify-center gap-2 rounded-full data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:border-2 data-[state=active]:border-[#FF3621] font-medium text-gray-600 data-[state=active]:text-gray-900 text-sm h-10 px-4 transition-all"
                >
                  <Grid3x3 className="w-4 h-4" />
                  Browse Products
                </TabsTrigger>
                <TabsTrigger 
                  value="ai-assistant" 
                  className="flex items-center justify-center gap-2 rounded-full data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:border-2 data-[state=active]:border-[#FF3621] font-medium text-gray-600 data-[state=active]:text-gray-900 text-sm h-10 px-4 transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  AI Shopping Assistant
                </TabsTrigger>
              </TabsList>

              <TabsContent value="browse" className={activeTab !== 'browse' ? 'hidden' : ''} forceMount>
                <BrowseProducts 
                  userPreferredCategories={currentUser.preferred_categories}
                />
              </TabsContent>

              <TabsContent value="ai-assistant" className={activeTab !== 'ai-assistant' ? 'hidden' : ''} forceMount>
                <ChatInterface 
                  user={currentUser} 
                  interactions={customerInteractions} 
                  onLogout={handleLogout}
                  onLoadingChange={setIsSearchLoading}
                />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      
      {/* Checkout Panel (CartPanel for form submission) */}
      <CartPanel 
        isOpen={isCheckoutOpen} 
        onClose={() => setIsCheckoutOpen(false)}
        customerName={currentUser?.name}
        customerEmail={currentUser?.email}
        onOrderSubmitted={handleOrderSubmitted}
        isAdminMode={isAdminMode}
      />

      {/* Orders Panel */}
      <OrdersPanel
        isOpen={isOrdersOpen}
        onClose={() => setIsOrdersOpen(false)}
        orders={orders}
      />

      <Toaster />
    </div>
  );
}

// Wrap with CartProvider
export default function App() {
  return (
    <CartProvider>
      <MainApp />
    </CartProvider>
  );
}
