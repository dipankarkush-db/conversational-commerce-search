import { useState } from "react";
import { User, Clock, Heart, ShoppingBag, ChevronDown, ChevronUp, X } from "lucide-react";
import { Card } from "./ui/card";
import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./ui/tabs";
import { EXAMPLE_QUERIES_BY_CATEGORY } from "../constants/exampleQueries";

interface CustomerInteraction {
  interaction_type: string;
  product_name: string;
  product_price: number;
  days_since_interaction: number;
}

interface SidebarProps {
  userName: string;
  userEmail: string;
  totalPurchases: number;
  totalSpent: string;
  persona: string;
  priceSensitivity: string;
  brandLoyalty: string;
  preferences: string[];
  interactions?: CustomerInteraction[];
  isSearchDisabled?: boolean;
}

export function Sidebar({
  userName,
  userEmail,
  totalPurchases,
  totalSpent,
  persona,
  priceSensitivity,
  brandLoyalty,
  preferences,
  interactions = [],
  isSearchDisabled = false,
}: SidebarProps) {
  const [isHistoryExpanded, setIsHistoryExpanded] = useState(false);
  const [isProfileExpanded, setIsProfileExpanded] = useState(false);

  const initials = userName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  const getInteractionEmoji = (type: string) => {
    const emojiMap: Record<string, string> = {
      'purchase': '💰',
      'view': '👀',
      'cart_add': '🛒',
      'rating': '⭐',
      'review': '📝'
    };
    return emojiMap[type.toLowerCase()] || '📦';
  };

  const getInteractionLabel = (type: string) => {
    const labelMap: Record<string, string> = {
      'purchase': 'PURCHASE',
      'view': 'VIEW',
      'cart_add': 'CART ADD',
      'rating': 'RATING',
      'review': 'REVIEW'
    };
    return labelMap[type.toLowerCase()] || type.toUpperCase();
  };

  const [isCategoriesExpanded, setIsCategoriesExpanded] = useState(false);
  const [showExamplesModal, setShowExamplesModal] = useState(false);

  const handleExampleClick = (query: { emoji: string; text: string }) => {
    // Don't allow if search is disabled
    if (isSearchDisabled) {
      return;
    }
    // Populate header search bar
    const event = new CustomEvent('populateHeaderSearch', { detail: query.text });
    window.dispatchEvent(event);
    // Close modal
    setShowExamplesModal(false);
  };

  return (
    <div className="space-y-3 p-4 bg-oat-light rounded-xl">
      {/* User Profile Card - Databricks Style */}
      <Card className="p-4 border border-gray-lines shadow-sm hover:shadow-md hover:border-[#FF3621] transition-all duration-200 bg-white rounded-md">
        <div className="flex items-start gap-3">
          <Avatar className="h-14 w-14 ring-2 ring-orange-200/30">
            <AvatarFallback className="bg-[#FF3621] text-white font-semibold text-lg">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-bold text-navy-900">{userName}</h3>
            <p className="text-xs text-gray-navigation truncate mb-3">{userEmail}</p>
            <div className="flex gap-4">
              <div>
                <div className="text-xl font-bold text-[#FF3621]">{totalPurchases}</div>
                <div className="text-xs text-gray-navigation font-medium">Purchases</div>
              </div>
              <div>
                <div className="text-xl font-bold text-[#FF3621]">{totalSpent}</div>
                <div className="text-xs text-gray-navigation font-medium">Spent</div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Recent Shopping History - Databricks Style */}
      {interactions.length > 0 && (
        <Card className="border border-gray-lines shadow-sm hover:shadow-md hover:border-[#FF3621] transition-all duration-200 overflow-hidden bg-white rounded-md">
          <button
            type="button"
            className="w-full flex items-center justify-between p-4 cursor-pointer hover:bg-oat-light transition-colors text-left"
            onClick={(e) => {
              e.preventDefault();
              setIsHistoryExpanded(!isHistoryExpanded);
            }}
          >
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-orange-200/20 rounded">
                <Clock className="w-4 h-4 text-[#FF3621]" />
              </div>
              <h3 className="font-semibold text-navy-900 text-base">Recent Shopping History</h3>
            </div>
            {isHistoryExpanded ? (
              <ChevronUp className="w-4 h-4 text-gray-navigation flex-shrink-0" />
            ) : (
              <ChevronDown className="w-4 h-4 text-gray-navigation flex-shrink-0" />
            )}
          </button>
          
          {isHistoryExpanded && (
            <div className="px-4 pb-4">
              <div className="space-y-2.5 max-h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-navy-300 scrollbar-track-oat-light">
                {interactions.slice(0, 7).map((interaction, index) => (
                  <div 
                    key={index}
                    className="p-3 bg-oat-light rounded border-l-3 border-l-[#FF3621] hover:bg-oat-medium transition-colors"
                  >
                    <div className="mb-1.5">
                      <Badge variant={interaction.interaction_type === 'purchase' ? 'default' : 'outline'} 
                             className={interaction.interaction_type === 'purchase' ? 'bg-green-600 text-white text-xs py-0.5 px-2.5 font-medium' : 'text-xs py-0.5 px-2.5 font-medium border-gray-lines text-navy-900'}>
                        {getInteractionEmoji(interaction.interaction_type)} {getInteractionLabel(interaction.interaction_type)}
                      </Badge>
                    </div>
                    <p className="text-sm font-semibold text-navy-900 line-clamp-1 mb-1.5">
                      {interaction.product_name}
                    </p>
                    <div className="flex items-center justify-between text-xs text-navy-700">
                      <span className="font-bold text-[#FF3621]">${interaction.product_price.toFixed(2)}</span>
                      <span className="font-medium">{interaction.days_since_interaction}d ago</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>
      )}

      {/* Shopping Profile - Databricks Style */}
      <Card className="border border-gray-lines shadow-sm hover:shadow-md hover:border-[#FF3621] transition-all duration-200 overflow-hidden bg-white rounded-md">
        <button
          type="button"
          className="w-full flex items-center justify-between p-4 cursor-pointer hover:bg-oat-light transition-colors text-left"
          onClick={(e) => {
            e.preventDefault();
            setIsProfileExpanded(!isProfileExpanded);
          }}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-orange-200/20 rounded">
              <User className="w-4 h-4 text-[#FF3621]" />
            </div>
            <h3 className="font-semibold text-navy-900 text-base">Shopping Profile</h3>
          </div>
          {isProfileExpanded ? (
            <ChevronUp className="w-4 h-4 text-gray-navigation flex-shrink-0" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-navigation flex-shrink-0" />
          )}
        </button>
        
        {isProfileExpanded && (
          <div className="px-4 pb-4 space-y-3 text-sm">
            <div className="flex justify-between items-center p-2.5 bg-oat-light rounded">
              <span className="text-navy-700 font-medium">Persona</span>
              <p className="text-navy-900 font-semibold text-right">{persona}</p>
            </div>
            <div className="flex justify-between items-center p-2.5 bg-oat-light rounded">
              <span className="text-navy-700 font-medium">Price Sensitivity</span>
              <p className="text-navy-900 font-semibold text-right">{priceSensitivity}</p>
            </div>
            <div className="flex justify-between items-center p-2.5 bg-oat-light rounded">
              <span className="text-navy-700 font-medium">Brand Loyalty</span>
              <p className="text-navy-900 font-semibold text-right">{brandLoyalty}</p>
            </div>
          </div>
        )}
      </Card>

      {/* Preferences - Databricks Style */}
      <Card className="p-4 border border-gray-lines shadow-sm hover:shadow-md hover:border-[#FF3621] transition-all duration-200 bg-white rounded-md">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="p-1.5 bg-orange-200/20 rounded">
            <Heart className="w-4 h-4 text-[#FF3621]" />
          </div>
          <h3 className="text-base font-semibold text-navy-900">Preferences</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {preferences.map((pref, index) => (
            <Badge key={index} className="text-xs bg-orange-200/20 text-[#FF3621] hover:bg-orange-200/30 border-0 px-3 py-1 font-medium rounded">
              {pref}
            </Badge>
          ))}
        </div>
      </Card>

      {/* Categories - Collapsible - Databricks Style */}
      <Card className="border border-gray-lines shadow-sm hover:shadow-md hover:border-[#FF3621] transition-all duration-200 overflow-hidden bg-white rounded-md">
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault();
            setIsCategoriesExpanded(!isCategoriesExpanded);
          }}
          className="w-full flex items-center justify-between p-4 cursor-pointer hover:bg-oat-light transition-colors text-left"
        >
          <div className="flex items-center gap-2.5">
            <span className="text-xl">🛍️</span>
            <h3 className="font-semibold text-navy-900 text-base">Categories Available</h3>
          </div>
          {isCategoriesExpanded ? (
            <ChevronUp className="w-4 h-4 text-gray-navigation flex-shrink-0" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-navigation flex-shrink-0" />
          )}
        </button>
        
        {isCategoriesExpanded && (
          <div className="px-4 pb-4">
            <div className="space-y-2 text-xs">
          <div className="flex items-start gap-3 p-3 bg-oat-light rounded hover:bg-orange-200/20 hover:border hover:border-[#FF5F46]/30 transition-colors">
            <span className="text-xl">📚</span>
            <div className="flex-1">
              <div className="font-semibold text-navy-900 mb-1">Books</div>
              <div className="text-navy-700 leading-relaxed">Fiction, Non-Fiction, Science, History, Biography, Self-Help</div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-oat-light rounded hover:bg-orange-200/20 hover:border hover:border-[#FF5F46]/30 transition-colors">
            <span className="text-xl">📱</span>
            <div className="flex-1">
              <div className="font-semibold text-navy-900 mb-1">Electronics</div>
              <div className="text-navy-700 leading-relaxed">Smartphones, Laptops, Headphones, Tablets, Smart Watches, Gaming</div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-oat-light rounded hover:bg-orange-200/20 hover:border hover:border-[#FF5F46]/30 transition-colors">
            <span className="text-xl">⚽</span>
            <div className="flex-1">
              <div className="font-semibold text-navy-900 mb-1">Sports & Outdoors</div>
              <div className="text-navy-700 leading-relaxed">Fitness, Outdoor Gear, Sports Equipment, Athletic Wear, Camping</div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-oat-light rounded hover:bg-orange-200/20 hover:border hover:border-[#FF5F46]/30 transition-colors">
            <span className="text-xl">👕</span>
            <div className="flex-1">
              <div className="font-semibold text-navy-900 mb-1">Clothing</div>
              <div className="text-navy-700 leading-relaxed">Shirts, Pants, Dresses, Shoes, Accessories, Outerwear</div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-oat-light rounded hover:bg-orange-200/20 hover:border hover:border-[#FF5F46]/30 transition-colors">
            <span className="text-xl">🏠</span>
            <div className="flex-1">
              <div className="font-semibold text-navy-900 mb-1">Home & Garden</div>
              <div className="text-navy-700 leading-relaxed">Furniture, Kitchen, Bathroom, Garden, Decor, Storage</div>
            </div>
          </div>
        </div>
          </div>
        )}
      </Card>

      {/* Browse Examples Button - Databricks Style */}
      <Card className="border border-gray-lines shadow-sm hover:shadow-md hover:border-[#FF3621] transition-all duration-200 overflow-hidden bg-white rounded-md">
        <button
          type="button"
          onClick={() => !isSearchDisabled && setShowExamplesModal(true)}
          disabled={isSearchDisabled}
          className={`w-full flex items-center justify-between p-4 transition-colors text-left ${
            isSearchDisabled 
              ? 'cursor-not-allowed opacity-50 bg-oat-medium' 
              : 'cursor-pointer hover:bg-oat-light'
          }`}
          title={isSearchDisabled ? "Please wait for current search to complete" : "Browse example queries by category"}
        >
          <div className="flex items-center gap-2.5">
            <span className="text-xl">💡</span>
            <h3 className="font-semibold text-navy-900 text-base">Browse Examples by Category</h3>
          </div>
        </button>
      </Card>

      {/* Examples Modal Overlay - Databricks Style */}
      {showExamplesModal && (
        <div className="fixed inset-0 bg-navy-900/60 z-50 flex items-center justify-center p-4" onClick={() => setShowExamplesModal(false)}>
          <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-hidden border border-gray-lines" onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-lines bg-oat-light">
              <h2 className="text-2xl font-semibold text-navy-900">Browse Examples by Category</h2>
              <button
                onClick={() => setShowExamplesModal(false)}
                className="p-2 hover:bg-orange-200/20 rounded transition-colors"
              >
                <X className="w-5 h-5 text-gray-navigation hover:text-[#FF3621]" />
              </button>
            </div>
            
            {/* Modal Content */}
            <div className="h-[calc(80vh-5rem)]">
              <Tabs defaultValue={Object.keys(EXAMPLE_QUERIES_BY_CATEGORY)[0]} className="h-full flex flex-col">
                {/* Tab Headers - Single Line with Horizontal Scroll */}
                <div className="px-6 pt-4 overflow-x-auto flex-shrink-0">
                  <TabsList className="inline-flex w-auto min-w-full">
                    {Object.keys(EXAMPLE_QUERIES_BY_CATEGORY).map((category) => (
                      <TabsTrigger 
                        key={category} 
                        value={category} 
                        className="text-xs whitespace-nowrap flex-shrink-0"
                      >
                        {category.replace(/^[\u{1F300}-\u{1F9FF}\s]+/u, '')}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </div>
                
                {/* Tab Content - Scrollable */}
                {Object.entries(EXAMPLE_QUERIES_BY_CATEGORY).map(([category, queries]) => (
                  <TabsContent key={category} value={category} className="flex-1 overflow-y-auto px-6 pb-6 mt-0 pt-4">
                    <h3 className="text-lg font-semibold text-navy-900 mb-3 flex items-center gap-2">
                      {category.match(/^[\u{1F300}-\u{1F9FF}]/u) ? category : `${queries[0]?.emoji} ${category}`}
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {queries.map((query, queryIndex) => (
                        <button
                          key={queryIndex}
                          onClick={() => handleExampleClick(query)}
                          disabled={isSearchDisabled}
                          className={`text-left text-sm p-4 rounded border transition-all flex items-center gap-3 ${
                            isSearchDisabled
                              ? 'cursor-not-allowed opacity-50 bg-oat-medium text-gray-navigation border-gray-lines'
                              : 'text-navy-700 hover:text-[#FF3621] hover:bg-orange-200/20 border-transparent hover:border-[#FF5F46]/30'
                          }`}
                          title={isSearchDisabled ? "Please wait for current search to complete" : ""}
                        >
                          <span className="text-xl">{query.emoji}</span>
                          <span>{query.text}</span>
                        </button>
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

