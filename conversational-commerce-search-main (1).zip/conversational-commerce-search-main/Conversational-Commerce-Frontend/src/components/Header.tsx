import { useEffect, useState } from "react";
import { Search, ShoppingCart, User, Sparkles, Receipt, LogOut, Volume2, VolumeX } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { isSoundEnabled, setSoundEnabled } from "../utils/soundEffects";

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
  userName: string;
  userEmail: string;
  totalPurchases: number;
  ordersCount?: number;
  onOrdersClick?: () => void;
  onLogout?: () => void;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  onSearchSubmit?: () => void;
  onCartHover?: (isHovering: boolean) => void;
  onPopulateSearch?: (value: string) => void;
  isAdminMode?: boolean;
  isSearchDisabled?: boolean;
}

export function Header({ 
  cartCount, 
  onCartClick, 
  userName,
  userEmail,
  totalPurchases,
  ordersCount = 0,
  onOrdersClick,
  onLogout,
  searchValue = '',
  onSearchChange,
  onSearchSubmit,
  onCartHover,
  onPopulateSearch,
  isAdminMode = false,
  isSearchDisabled = false
}: HeaderProps) {
  // Sound toggle state
  const [soundEnabled, setSoundEnabledState] = useState(isSoundEnabled());

  const toggleSound = () => {
    const newValue = !soundEnabled;
    setSoundEnabledState(newValue);
    setSoundEnabled(newValue);
  };

  // Get user initials
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && onSearchSubmit) {
      onSearchSubmit();
    }
  };

  // Listen for populate search event
  useEffect(() => {
    const handlePopulateSearch = (e: CustomEvent) => {
      const query = e.detail;
      if (query && onPopulateSearch) {
        onPopulateSearch(query);
      }
    };

    window.addEventListener('populateHeaderSearch', handlePopulateSearch as EventListener);
    return () => {
      window.removeEventListener('populateHeaderSearch', handlePopulateSearch as EventListener);
    };
  }, [onPopulateSearch]);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-navy-800 bg-navy-900 shadow-lg">
      <div className="container mx-auto px-4">
        {/* Top bar */}
        <div className="flex items-center justify-between py-3 gap-4">
          {/* Logo - Databricks Style */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center justify-center w-10 h-10 bg-[#FF3621] rounded shadow-md">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div className="hidden md:block">
              <div className="font-semibold text-white">Conversational Commerce</div>
              <div className="text-xs text-navy-300">AI-Powered Shopping Assistant</div>
            </div>
          </div>

          {/* Search Bar - Databricks Style */}
          {onSearchChange && onSearchSubmit && (
            <div className="hidden lg:flex flex-1 max-w-2xl">
              <div className="relative w-full">
                <Input
                  type="text"
                  placeholder={isSearchDisabled ? "Please wait for current search to complete..." : "Ask me anything... (e.g., 'wireless headphones under $350')"}
                  value={searchValue}
                  onChange={(e) => onSearchChange(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={isSearchDisabled}
                  className="w-full h-12 pr-14 pl-4 rounded-full bg-white border-gray-lines focus:border-[#FF3621] focus:ring-[#FF3621] disabled:opacity-60 disabled:cursor-not-allowed"
                />
                <Button
                  onClick={onSearchSubmit}
                  disabled={!searchValue.trim() || isSearchDisabled}
                  className="absolute right-1 top-1 h-10 w-10 p-0 rounded-full bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] disabled:opacity-50"
                >
                  <Search className="h-5 w-5 text-white" />
                </Button>
              </div>
            </div>
          )}

          {/* Right side actions - Databricks Style */}
          <div className="flex items-center gap-3">
            {/* Sound Toggle Button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover:bg-navy-800" 
              onClick={toggleSound}
              title={soundEnabled ? "Mute sounds" : "Enable sounds"}
            >
              {soundEnabled ? (
                <Volume2 className="h-5 w-5 text-navy-300 hover:text-white" />
              ) : (
                <VolumeX className="h-5 w-5 text-navy-400 hover:text-white" />
              )}
            </Button>

            {/* Orders Button */}
            {onOrdersClick && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="relative hover:bg-navy-800" 
                onClick={onOrdersClick}
              >
                <Receipt className="h-5 w-5 text-navy-300 hover:text-white" />
                {ordersCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-green-600 text-white text-xs border-2 border-navy-900">
                    {ordersCount}
                  </Badge>
                )}
              </Button>
            )}
            
            {/* Cart Button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="relative hover:bg-navy-800" 
              onClick={onCartClick}
              onMouseEnter={() => onCartHover && onCartHover(true)}
            >
              <ShoppingCart className="h-5 w-5 text-navy-300 hover:text-white" />
              {cartCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-gradient-to-r from-[#FF3621] to-[#FF5F46] text-white text-xs border-2 border-navy-900">
                  {cartCount}
                </Badge>
              )}
            </Button>
            
            {/* User Profile - Databricks Style */}
            <div 
              className="hidden md:flex items-center gap-2 pl-3 border-l border-navy-800 px-2 py-1"
            >
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-[#FF3621] text-white font-semibold text-sm">
                  {isAdminMode ? 'AD' : getInitials(userName)}
                </AvatarFallback>
              </Avatar>
              <div className="hidden lg:block">
                <div className="text-sm font-medium text-white">
                  {isAdminMode ? 'Admin Experience' : userName}
                </div>
                <div className="text-xs text-navy-300">
                  {isAdminMode ? `Viewing: ${userName}` : `${totalPurchases} purchases`}
                </div>
              </div>
            </div>
            
            {/* Logout Button */}
            {onLogout && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="hover:bg-navy-800" 
                onClick={onLogout}
                title="Logout"
              >
                <LogOut className="h-5 w-5 text-navy-300 hover:text-[#FF5F46]" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

