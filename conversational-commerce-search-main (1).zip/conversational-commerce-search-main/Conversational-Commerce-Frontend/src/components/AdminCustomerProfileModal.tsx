import { useEffect, useState } from 'react';
import { X, Clock, ShoppingCart, Globe, Package, TrendingUp, ChevronRight } from 'lucide-react';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CustomerProfileData {
  profile: {
    customer_name: string;
    email: string;
    persona: string;
    total_orders: number;
    total_spent: number;
    last_product_name?: string;
    last_product_category?: string;
    last_purchase_ts?: string;
    purchase_amount?: number;
    top_cross_sell_products?: string;
  };
  browsing_events: Array<{
    session_id: string;
    event_timestamp: string;
    channel: string;
    page_type: string;
    device_type: string;
    search_query: string;
    focus_topic: string;
    dwell_seconds: number;
  }>;
  external_signals: Array<{
    signal_timestamp: string;
    platform: string;
    signal_type: string;
    content_topic: string;
    engagement_score: number;
    source_url: string;
  }>;
  basket_intelligence: Array<{
    anchor_product: string;
    associated_product: string;
    pair_count: number;
    affinity_share: number;
  }>;
  shopping_history: Array<{
    product_name: string;
    price: number;
    interaction_type: string;
    timestamp: string;
    category: string;
  }>;
}

interface AdminCustomerProfileModalProps {
  customerId: string;
  customerName: string;
  isOpen: boolean;
  onClose: () => void;
}

export function AdminCustomerProfileModal({ 
  customerId, 
  customerName, 
  isOpen, 
  onClose 
}: AdminCustomerProfileModalProps) {
  const [data, setData] = useState<CustomerProfileData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && customerId) {
      fetchCustomerProfile();
    }
  }, [isOpen, customerId]);

  const fetchCustomerProfile = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/admin/customer-profile/${customerId}`);
      if (!response.ok) throw new Error('Failed to fetch profile');
      const profileData = await response.json();
      setData(profileData);
    } catch (err) {
      setError('Failed to load customer profile');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const formatTimestamp = (timestamp: string | undefined) => {
    if (!timestamp) return 'N/A';
    try {
      return new Date(timestamp).toLocaleString();
    } catch {
      return timestamp;
    }
  };

  const formatTimeAgo = (timestamp: string | undefined) => {
    if (!timestamp) return '';
    try {
      const date = new Date(timestamp);
      const now = new Date();
      const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
      
      if (diff < 60) return `${diff}s ago`;
      if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
      if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
      return `${Math.floor(diff / 86400)}d ago`;
    } catch {
      return '';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="relative bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#FF3621] to-[#FF5F46] text-white p-6 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold">{customerName}</h2>
            {data?.profile && (
              <p className="text-sm opacity-90">{data.profile.email}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-full transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden flex flex-col p-6">
          {loading && (
            <div className="flex items-center justify-center h-64">
              <div className="text-gray-500">Loading profile...</div>
            </div>
          )}

          {error && (
            <div className="bg-orange-200/20 border border-orange-200 text-[#FF3621] px-4 py-3 rounded">
              {error}
            </div>
          )}

          {data && (
            <Tabs defaultValue="shopping" className="flex-1 flex flex-col min-h-0">
              <TabsList className="w-full bg-white border border-gray-200 p-1 rounded-lg mb-4 flex-shrink-0">
                <TabsTrigger 
                  value="shopping" 
                  className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white px-4 py-2"
                >
                  <ShoppingCart className="w-4 h-4" />
                  Shopping
                </TabsTrigger>
                <TabsTrigger 
                  value="activity" 
                  className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white px-4 py-2"
                >
                  <Clock className="w-4 h-4" />
                  Activity
                </TabsTrigger>
                <TabsTrigger 
                  value="signals" 
                  className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white px-4 py-2"
                >
                  <Globe className="w-4 h-4" />
                  Signals
                </TabsTrigger>
                <TabsTrigger 
                  value="patterns" 
                  className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white px-4 py-2"
                >
                  <Package className="w-4 h-4" />
                  Patterns
                </TabsTrigger>
              </TabsList>

              {/* Shopping Tab */}
              <TabsContent value="shopping" className="flex-1 overflow-y-auto mt-0 min-h-0">
                <section className="border border-gray-200 rounded-lg p-5 bg-white">
                  <div className="flex items-center gap-2 mb-4">
                    <ShoppingCart className="w-5 h-5 text-[#FF3621]" />
                    <h3 className="text-lg font-semibold text-gray-900">Recent Shopping History</h3>
                  </div>
                  {data.shopping_history.length > 0 ? (
                    <div className="space-y-3">
                      {data.shopping_history.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Badge className="bg-gray-200 text-gray-700 text-xs">
                                {item.interaction_type.toUpperCase()}
                              </Badge>
                              <span className="font-medium text-gray-900">{item.product_name}</span>
                            </div>
                            <div className="text-sm text-gray-500 mt-1">
                              ${item.price.toFixed(2)} • {item.category}
                            </div>
                          </div>
                          <div className="text-right text-sm text-gray-500">
                            {formatTimeAgo(item.timestamp)}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">No shopping history available</p>
                  )}
                </section>
              </TabsContent>

              {/* Activity Tab */}
              <TabsContent value="activity" className="flex-1 overflow-y-auto mt-0 min-h-0">
                <section className="border border-gray-200 rounded-lg p-5 bg-white">
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="w-5 h-5 text-[#FF3621]" />
                    <h3 className="text-lg font-semibold text-gray-900">Recent Browsing History</h3>
                  </div>
                  {data.browsing_events.length > 0 ? (
                    <div className="space-y-3">
                      {data.browsing_events.map((event, idx) => (
                        <div key={idx} className="p-3 bg-gray-50 rounded">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge className="bg-blue-100 text-blue-700 text-xs">
                                {event.channel}
                              </Badge>
                              <Badge className="bg-purple-100 text-purple-700 text-xs">
                                {event.device_type}
                              </Badge>
                            </div>
                            <span className="text-xs text-gray-500">{formatTimeAgo(event.event_timestamp)}</span>
                          </div>
                          <div className="text-sm text-gray-900">
                            <span className="font-medium">{event.page_type}</span> • {event.focus_topic}
                          </div>
                          {event.search_query && (
                            <div className="text-sm text-gray-600 mt-1">
                              Search: "{event.search_query}"
                            </div>
                          )}
                          <div className="text-xs text-gray-500 mt-1">
                            Dwell time: {event.dwell_seconds}s
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">No browsing history available</p>
                  )}
                </section>
              </TabsContent>

              {/* Signals Tab */}
              <TabsContent value="signals" className="flex-1 overflow-y-auto mt-0 min-h-0">
                <section className="border border-gray-200 rounded-lg p-5 bg-white">
                  <div className="flex items-center gap-2 mb-4">
                    <Globe className="w-5 h-5 text-[#FF3621]" />
                    <h3 className="text-lg font-semibold text-gray-900">External Intelligence</h3>
                  </div>
                  {data.external_signals.length > 0 ? (
                    <div className="space-y-3">
                      {data.external_signals.map((signal, idx) => (
                        <div key={idx} className="p-3 bg-gray-50 rounded">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge className="bg-pink-100 text-pink-700 text-xs">
                                {signal.platform}
                              </Badge>
                              <Badge className="bg-green-100 text-green-700 text-xs">
                                {signal.signal_type}
                              </Badge>
                            </div>
                            <span className="text-xs text-gray-500">{formatTimeAgo(signal.signal_timestamp)}</span>
                          </div>
                          <div className="text-sm text-gray-900 font-medium mb-1">
                            {signal.content_topic}
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="text-xs text-gray-600">
                              Engagement Score: {(signal.engagement_score * 100).toFixed(0)}%
                            </div>
                            {signal.source_url && (
                              <a 
                                href={signal.source_url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                              >
                                View Source <ChevronRight className="w-3 h-3" />
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">No external signals available</p>
                  )}
                </section>
              </TabsContent>

              {/* Patterns Tab */}
              <TabsContent value="patterns" className="flex-1 overflow-y-auto mt-0 min-h-0">
                <section className="border border-gray-200 rounded-lg p-5 bg-white">
                  <div className="flex items-center gap-2 mb-4">
                    <Package className="w-5 h-5 text-[#FF3621]" />
                    <h3 className="text-lg font-semibold text-gray-900">Basket Intelligence</h3>
                    <span className="text-xs text-gray-500">(Frequently Bought Together)</span>
                  </div>
                  {data.basket_intelligence.length > 0 ? (
                    <div className="space-y-3">
                      {data.basket_intelligence.map((basket, idx) => (
                        <div key={idx} className="p-3 bg-gray-50 rounded flex items-center">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-gray-900">{basket.anchor_product}</span>
                              <span className="text-gray-400">+</span>
                              <span className="text-sm font-medium text-gray-900">{basket.associated_product}</span>
                            </div>
                            <div className="flex items-center gap-4 mt-1 text-xs text-gray-600">
                              <span>Bought together: {basket.pair_count}x</span>
                              <span>Affinity: {(basket.affinity_share * 100).toFixed(1)}%</span>
                            </div>
                          </div>
                          <TrendingUp className="w-4 h-4 text-green-500" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">No basket intelligence data available</p>
                  )}
                </section>
              </TabsContent>
            </Tabs>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 p-4 bg-gray-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-medium transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

