import { useState, useEffect } from 'react';
import { useCart } from '../contexts/CartContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { X, Plus, Minus, Trash2, ShoppingBag, Package, CreditCard, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { submitOrder, type OrderSubmission } from '../services/api';

interface CartPanelProps {
  isOpen: boolean;
  onClose: () => void;
  customerName?: string;
  customerEmail?: string;
  onOrderSubmitted?: () => void;
  isAdminMode?: boolean;
}

// Generate product image URL with enhanced keyword mapping for best results
const getProductImageUrl = (category: string, subcategory: string, productId: string): string => {
  // Enhanced image mapping for specific subcategories using reliable sources
  const subcategoryImages: Record<string, string> = {
    // Electronics - High quality tech images
    'Headphones': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
    'Laptops': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Laptop': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Smartphones': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Tablets': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Tablet': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Phone': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Camera': 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=400&fit=crop',
    'Smart Watches': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Smart Watch': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Watch': 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=400&h=400&fit=crop',
    'Gaming': 'https://images.unsplash.com/photo-1486401899868-0e435ed85128?w=400&h=400&fit=crop',
    'TV': 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=400&fit=crop',
    
    // Books - Relevant book imagery
    'Fiction': 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop',
    'Non-Fiction': 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=400&fit=crop',
    'Science': 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400&h=400&fit=crop',
    'History': 'https://images.unsplash.com/photo-1461360228754-6e81c478b882?w=400&h=400&fit=crop',
    'Biography': 'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=400&h=400&fit=crop',
    'Self-Help': 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&h=400&fit=crop',
    'Textbook': 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400&h=400&fit=crop',
    'Children': 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=400&fit=crop',
    
    // Sports & Outdoors - Distinct imagery for each subcategory
    // Fitness - Indoor gym/workout equipment
    'Fitness': 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=400&fit=crop', // Dumbbells and gym equipment
    // Outdoor Gear - Mountain/hiking gear
    'Outdoor Gear': 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=400&h=400&fit=crop', // Camping mountains
    // Sports Equipment - Ball sports and equipment
    'Sports Equipment': 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=400&h=400&fit=crop', // Basketball close-up
    // Athletic Wear - Running/sports clothing
    'Athletic Wear': 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=400&fit=crop', // Athletic shoes/sportswear
    // Camping - Tents and camping scenes
    'Camping': 'https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?w=400&h=400&fit=crop', // Camping tent
    'Cycling': 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=400&h=400&fit=crop',
    
    // Clothing - Fashion photography
    'Outerwear': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Pants': 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400&h=400&fit=crop',
    'Shirts': 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=400&h=400&fit=crop',
    'Jacket': 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop',
    'Coat': 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400&h=400&fit=crop',
    'Dress': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Dresses': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Shoes': 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
    'Accessories': 'https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=400&h=400&fit=crop',
    'Hat': 'https://images.unsplash.com/photo-1521369909029-2afed882baee?w=400&h=400&fit=crop',
    
    // Home & Garden - Interior and lifestyle imagery
    'Furniture': 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&h=400&fit=crop',
    'Kitchen': 'https://images.unsplash.com/photo-1556911220-bff31c812dba?w=400&h=400&fit=crop',
    'Decor': 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=400&h=400&fit=crop',
    'Garden': 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400&h=400&fit=crop',
    'Tools': 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400&h=400&fit=crop',
    
    // Other categories
    'Toys': 'https://images.unsplash.com/photo-1558060370-d644479cb6f7?w=400&h=400&fit=crop',
    'Food': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=400&fit=crop',
    'Health': 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400&h=400&fit=crop',
    'Beauty': 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop',
    'Automotive': 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=400&h=400&fit=crop',
  };
  
  // Try exact match first
  if (subcategoryImages[subcategory]) {
    return subcategoryImages[subcategory];
  }
  
  // Try partial match
  const subcategoryLower = subcategory.toLowerCase();
  for (const [key, imageUrl] of Object.entries(subcategoryImages)) {
    if (subcategoryLower.includes(key.toLowerCase()) || key.toLowerCase().includes(subcategoryLower)) {
      return imageUrl;
    }
  }
  
  // Category-based fallback
  const categoryLower = category.toLowerCase();
  if (categoryLower.includes('home') || categoryLower.includes('garden') || categoryLower.includes('furniture')) {
    return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('electronics') || categoryLower.includes('tech')) {
    return 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('book')) {
    return 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('clothing') || categoryLower.includes('fashion')) {
    return 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('sports') || categoryLower.includes('outdoor')) {
    return 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400&h=400&fit=crop';
  }
  
  // Final fallback
  return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop';
};

// Generate random checkout data for demo purposes
const generateRandomCheckoutData = (customerName?: string, customerEmail?: string) => {
  // Use diverse, realistic US area codes (not 555)
  const phones = [
    '+1 (415) 234-5678',  // San Francisco, CA
    '+1 (212) 987-6543',  // New York, NY
    '+1 (312) 456-7890',  // Chicago, IL
    '+1 (713) 321-6549',  // Houston, TX
    '+1 (206) 789-3456',  // Seattle, WA
    '+1 (305) 654-9870',  // Miami, FL
    '+1 (617) 852-3691',  // Boston, MA
    '+1 (720) 147-8520',  // Denver, CO
    '+1 (503) 963-2580',  // Portland, OR
    '+1 (512) 258-7413',  // Austin, TX
    '+1 (602) 741-9630',  // Phoenix, AZ
    '+1 (404) 369-8520'   // Atlanta, GA
  ];
  
  const addresses = [
    { street: '123 Main Street, Apt 4B', city: 'San Francisco', state: 'CA', zip: '94102' },
    { street: '456 Oak Avenue, Suite 12', city: 'Los Angeles', state: 'CA', zip: '90001' },
    { street: '789 Pine Road, Unit 5C', city: 'Seattle', state: 'WA', zip: '98101' },
    { street: '321 Elm Boulevard', city: 'Portland', state: 'OR', zip: '97201' },
    { street: '654 Maple Drive, Floor 3', city: 'Austin', state: 'TX', zip: '73301' },
    { street: '987 Cedar Lane, Apt 8A', city: 'Denver', state: 'CO', zip: '80201' }
  ];
  
  const cards = [
    { number: '4532 1234 5678 9010', expiry: '12/25', cvv: '123', type: 'credit_card' },
    { number: '5425 2334 3010 9910', expiry: '03/26', cvv: '456', type: 'credit_card' },
    { number: '4024 0071 5111 9910', expiry: '08/25', cvv: '789', type: 'debit_card' },
    { number: '4532 8888 9999 0000', expiry: '11/26', cvv: '321', type: 'credit_card' },
    { number: '5200 8282 8282 8210', expiry: '05/27', cvv: '654', type: 'debit_card' },
    { number: '4916 7389 4523 7890', expiry: '09/25', cvv: '987', type: 'credit_card' }
  ];
  
  const randomPhone = phones[Math.floor(Math.random() * phones.length)];
  const randomAddress = addresses[Math.floor(Math.random() * addresses.length)];
  const randomCard = cards[Math.floor(Math.random() * cards.length)];
  
  return {
    fullName: customerName || 'Guest User',
    email: customerEmail || 'guest@example.com',
    phone: randomPhone,
    address: randomAddress.street,
    city: randomAddress.city,
    state: randomAddress.state,
    zipCode: randomAddress.zip,
    paymentMethod: randomCard.type,
    cardNumber: randomCard.number,
    cardName: customerName || 'Guest User',
    expiryDate: randomCard.expiry,
    cvv: randomCard.cvv
  };
};

export function CartPanel({ isOpen, onClose, customerName, customerEmail, onOrderSubmitted, isAdminMode = false }: CartPanelProps) {
  const { items, itemCount, subtotal, tax, totalPrice, updateQuantity, removeItem, clearCart } = useCart();
  const [showCheckout, setShowCheckout] = useState(false); // Show cart first, then checkout
  const [showSuccess, setShowSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderIdDisplay, setOrderIdDisplay] = useState('');
  
  // Checkout form state with random prefilled data
  const [checkoutData, setCheckoutData] = useState(
    generateRandomCheckoutData(customerName, customerEmail)
  );

  // Regenerate random data when customer changes
  useEffect(() => {
    setCheckoutData(generateRandomCheckoutData(customerName, customerEmail));
  }, [customerName, customerEmail]);

  const handleInputChange = (field: string, value: string) => {
    setCheckoutData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmitOrder = async () => {
    setIsSubmitting(true);
    
    try {
      // Get last 4 digits of card number
      const cardLast4 = checkoutData.cardNumber.replace(/\s/g, '').slice(-4);
      
      // Generate random phone number for order submission using real US area codes
      const areaCodes = [
        '212', '213', '214', '215', '216', '217', '224', '225', '229', '234',
        '239', '240', '248', '251', '252', '253', '254', '256', '260', '262',
        '267', '269', '270', '281', '301', '302', '303', '304', '305', '310',
        '312', '313', '314', '315', '316', '317', '318', '319', '320', '321',
        '330', '334', '336', '337', '339', '347', '351', '352', '360', '361',
        '402', '404', '405', '406', '407', '408', '409', '410', '412', '413',
        '414', '415', '417', '419', '423', '424', '425', '430', '432', '434',
        '435', '440', '442', '443', '469', '470', '475', '478', '479', '480',
        '484', '501', '502', '503', '504', '505', '507', '508', '509', '510',
        '512', '513', '515', '516', '517', '518', '520', '530', '540', '541',
        '559', '561', '562', '563', '567', '570', '571', '573', '574', '575',
        '580', '585', '586', '601', '602', '603', '605', '606', '607', '608',
        '609', '610', '612', '614', '615', '616', '617', '618', '619', '620',
        '623', '626', '630', '631', '636', '641', '646', '650', '651', '657',
        '660', '661', '662', '667', '678', '682', '701', '702', '703', '704',
        '706', '707', '708', '712', '713', '714', '715', '716', '717', '718',
        '719', '720', '724', '727', '731', '732', '734', '737', '740', '747',
        '754', '757', '760', '763', '765', '770', '772', '773', '774', '775',
        '781', '785', '786', '801', '802', '803', '804', '805', '806', '808',
        '810', '812', '813', '814', '815', '816', '817', '818', '828', '830',
        '831', '832', '843', '845', '847', '848', '850', '854', '856', '857',
        '858', '859', '860', '862', '863', '864', '865', '870', '872', '878',
        '901', '903', '904', '906', '907', '908', '909', '910', '912', '913',
        '914', '915', '916', '917', '918', '919', '920', '925', '928', '929',
        '931', '936', '937', '940', '941', '947', '949', '951', '952', '954',
        '956', '959', '970', '971', '972', '973', '978', '979', '980', '984'
      ];
      const randomAreaCode = areaCodes[Math.floor(Math.random() * areaCodes.length)];
      const randomPhone = `+1 (${randomAreaCode}) ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`;
      
      // Prepare order data
      const orderData: OrderSubmission = {
        customer_name: customerName || 'Guest',
        customer_email: customerEmail || 'guest@example.com',
        items: items.map(item => ({
          product_id: item.product_id,
          name: item.name,
          category: item.category,
          brand: item.brand || 'Unknown',
          price: item.price,
          quantity: item.quantity
        })),
        subtotal: subtotal,
        tax: tax,
        total_price: totalPrice,
        full_name: checkoutData.fullName,
        email: checkoutData.email,
        phone: randomPhone,
        address: checkoutData.address,
        city: checkoutData.city,
        state: checkoutData.state,
        zip_code: checkoutData.zipCode,
        payment_method: checkoutData.paymentMethod,
        card_last_four: cardLast4
      };
      
      // Submit order to backend
      const response = await submitOrder(orderData);
      
      // Capture order details before clearing
      const orderTotal = totalPrice;
      const orderId = response.order_id;
      
      // Show success toast with order details
      const emailMsg = response.email_sent 
        ? `✅ Order ${orderId} placed! Total: $${orderTotal.toFixed(2)}\n📧 Confirmation sent to dipankar.kushari@gmail.com`
        : `✅ Order ${orderId} placed! Total: $${orderTotal.toFixed(2)}`;
      
      toast.success(emailMsg, { duration: 5000 });
      
      // Clear cart immediately
      clearCart();
      
      // Refetch orders from Lakebase
      if (onOrderSubmitted) {
        await onOrderSubmitted();
      }
      
      // Reset UI and close panel immediately
      setShowSuccess(false);
      setShowCheckout(false);
      setOrderIdDisplay('');
      onClose();
      
    } catch (error) {
      console.error('Order submission error:', error);
      toast.error('Failed to submit order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleProceedToCheckout = () => {
    setShowCheckout(true);
  };

  const handleBackToCart = () => {
    setShowCheckout(false);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Slide-out Panel */}
      <div className="fixed top-0 right-0 h-full w-full sm:w-[480px] bg-white z-50 shadow-2xl transform transition-transform duration-300 ease-in-out flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-gradient-to-br from-[#FF3621] to-[#FF5F46] rounded-lg flex items-center justify-center">
              {showCheckout ? <CreditCard className="w-4 h-4 text-white" /> : <ShoppingBag className="w-4 h-4 text-white" />}
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">
                {showSuccess ? 'Order Confirmed!' : showCheckout ? 'Checkout' : 'Your Cart'}
              </h2>
              <p className="text-xs text-gray-500">
                {showSuccess ? 'Thank you for your order' : showCheckout ? 'Complete your purchase' : `${itemCount} ${itemCount === 1 ? 'item' : 'items'}`}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>

        {/* Success View */}
        {showSuccess ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6">
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6 animate-bounce">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Order Submitted!</h3>
            <p className="text-gray-600 text-center mb-2">
              Your order has been successfully placed.
            </p>
            {orderIdDisplay && (
              <p className="text-sm font-mono bg-gray-100 px-3 py-1 rounded mb-2">
                {orderIdDisplay}
              </p>
            )}
            <p className="text-sm text-gray-500 text-center mb-2">
              Order Total: <span className="font-bold text-[#FF3621]">${totalPrice.toFixed(2)}</span>
            </p>
            <p className="text-xs text-green-600 text-center">
              📧 Confirmation email sent!
            </p>
          </div>
        ) : showCheckout ? (
          /* Checkout Form View */
          <>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-6">
                {/* Order Summary */}
                <Card className="p-4 bg-gray-50">
                  <h3 className="font-semibold text-gray-900 mb-3">Order Summary</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal ({itemCount} items)</span>
                      <span className="font-semibold">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Sales Tax (6.5%)</span>
                      <span className="font-semibold">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Shipping</span>
                      <span className="text-green-600 font-semibold">FREE</span>
                    </div>
                    <div className="border-t border-gray-300 pt-2 mt-2 flex justify-between">
                      <span className="font-bold text-gray-900">Total</span>
                      <span className="font-bold text-[#FF3621]">${totalPrice.toFixed(2)}</span>
                    </div>
                  </div>
                </Card>

                {/* Contact Information */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Contact Information</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                      <Input
                        value={checkoutData.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <Input
                        type="email"
                        value={checkoutData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                      <Input
                        type="tel"
                        value={checkoutData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>

                {/* Shipping Address */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Shipping Address</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                      <Input
                        value={checkoutData.address}
                        onChange={(e) => handleInputChange('address', e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                        <Input
                          value={checkoutData.city}
                          onChange={(e) => handleInputChange('city', e.target.value)}
                          className="w-full"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                        <Input
                          value={checkoutData.state}
                          onChange={(e) => handleInputChange('state', e.target.value)}
                          className="w-full"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">ZIP Code</label>
                      <Input
                        value={checkoutData.zipCode}
                        onChange={(e) => handleInputChange('zipCode', e.target.value)}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Method */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Payment Method</h3>
                  <div className="space-y-3">
                    <div className="flex gap-3">
                      <button
                        onClick={() => handleInputChange('paymentMethod', 'credit_card')}
                        className={`flex-1 p-3 border-2 rounded-lg transition-all ${
                          checkoutData.paymentMethod === 'credit_card'
                            ? 'border-[#FF3621] bg-orange-200/20'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <CreditCard className="w-5 h-5 mx-auto mb-1" />
                        <div className="text-xs font-medium">Credit Card</div>
                      </button>
                      <button
                        onClick={() => handleInputChange('paymentMethod', 'debit_card')}
                        className={`flex-1 p-3 border-2 rounded-lg transition-all ${
                          checkoutData.paymentMethod === 'debit_card'
                            ? 'border-[#FF3621] bg-orange-200/20'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <CreditCard className="w-5 h-5 mx-auto mb-1" />
                        <div className="text-xs font-medium">Debit Card</div>
                      </button>
                    </div>

                    {/* Card Details */}
                    {(checkoutData.paymentMethod === 'credit_card' || checkoutData.paymentMethod === 'debit_card') && (
                      <div className="space-y-3 pt-3">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Card Number</label>
                          <Input
                            value={checkoutData.cardNumber}
                            onChange={(e) => handleInputChange('cardNumber', e.target.value)}
                            placeholder="1234 5678 9012 3456"
                            className="w-full"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Cardholder Name</label>
                          <Input
                            value={checkoutData.cardName}
                            onChange={(e) => handleInputChange('cardName', e.target.value)}
                            className="w-full"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                            <Input
                              value={checkoutData.expiryDate}
                              onChange={(e) => handleInputChange('expiryDate', e.target.value)}
                              placeholder="MM/YY"
                              className="w-full"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">CVV</label>
                            <Input
                              value={checkoutData.cvv}
                              onChange={(e) => handleInputChange('cvv', e.target.value)}
                              placeholder="123"
                              maxLength={4}
                              className="w-full"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Checkout Footer */}
            <div className="border-t border-gray-200 p-6 bg-gray-50 space-y-3">
              {isAdminMode && (
                <div className="bg-orange-200/20 border border-orange-200 rounded-md p-3 mb-3">
                  <p className="text-sm text-[#FF3621] font-medium">
                    Admin View: Order placement is disabled. You can add/remove items but cannot complete checkout.
                  </p>
                </div>
              )}
              <Button
                onClick={handleSubmitOrder}
                disabled={isSubmitting || isAdminMode}
                className="w-full bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white font-semibold py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </span>
                ) : isAdminMode ? (
                  'Order Placement Disabled (Admin Mode)'
                ) : (
                  `Submit Order - $${totalPrice.toFixed(2)}`
                )}
              </Button>
              <Button
                onClick={handleBackToCart}
                variant="outline"
                className="w-full"
                disabled={isSubmitting}
              >
                Back to Cart
              </Button>
            </div>
          </>
        ) : (
          /* Cart View */
          <>
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                <Package className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-base font-semibold text-gray-900 mb-1">Your cart is empty</h3>
              <p className="text-sm text-gray-500 mb-4">
                Start chatting to discover products and add them to your cart!
              </p>
              <Button
                onClick={onClose}
                className="bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white"
              >
                Continue Shopping
              </Button>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto p-4">
              {/* Cart Items */}
              <div className="space-y-3 mb-4">
                {items.map((item) => (
                  <Card key={item.product_id} className="p-3 hover:shadow-md transition-shadow">
                    <div className="flex gap-3">
                      {/* Product Image */}
                      <div className="w-16 h-16 overflow-hidden rounded-lg flex-shrink-0 bg-gray-100">
                        <img 
                          src={getProductImageUrl(item.category, item.subcategory || '', item.product_id)}
                          alt={item.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            // Fallback to generic shopping bag icon if image fails
                            e.currentTarget.style.display = 'none';
                            const iconContainer = e.currentTarget.parentElement;
                            if (iconContainer) {
                              iconContainer.className = 'w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0';
                              iconContainer.innerHTML = '📦';
                            }
                          }}
                        />
                      </div>

                      {/* Product Details */}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-sm text-gray-900 mb-0.5 truncate">
                          {item.name}
                        </h4>
                        {item.brand && (
                          <p className="text-xs text-gray-500 mb-1">{item.brand}</p>
                        )}
                        <p className="text-base font-bold text-[#FF3621] mb-2">
                          ${item.price.toFixed(2)}
                        </p>

                        {/* Quantity Controls */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                              className="p-1 bg-gray-100 hover:bg-gray-200 rounded transition-colors"
                            >
                              <Minus className="w-3.5 h-3.5 text-gray-600" />
                            </button>
                            <span className="w-7 text-center text-sm font-semibold text-gray-900">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                              className="p-1 bg-gray-100 hover:bg-gray-200 rounded transition-colors"
                            >
                              <Plus className="w-3.5 h-3.5 text-gray-600" />
                            </button>
                          </div>

                          <button
                            onClick={() => removeItem(item.product_id)}
                            className="p-1 text-maroon-600 hover:bg-orange-200/20 rounded transition-colors"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}

                {/* Clear Cart */}
                {items.length > 0 && (
                  <button
                    onClick={clearCart}
                    className="w-full text-xs text-maroon-600 hover:text-maroon-500 font-medium py-1"
                  >
                    Clear Cart
                  </button>
                )}
              </div>

              {/* Price Breakdown - Right after cart items */}
              <div className="bg-gray-50 p-3 rounded-lg border border-gray-200 space-y-1.5 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="text-gray-900">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Tax (6.5%)</span>
                  <span className="text-gray-900">${tax.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between pt-1.5 border-t border-gray-300">
                  <span className="text-gray-900 font-semibold">Total</span>
                  <span className="text-lg font-bold text-[#FF3621]">
                    ${totalPrice.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Admin Notice */}
              {isAdminMode && (
                <div className="bg-orange-200/20 border border-orange-200 rounded-md p-2.5 mb-3">
                  <p className="text-xs text-[#FF3621] font-medium">
                    Admin View: You can add/remove items but cannot place orders.
                  </p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="space-y-2">
                <Button
                  onClick={handleProceedToCheckout}
                  disabled={isAdminMode}
                  className="w-full bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white h-10 text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isAdminMode ? 'Checkout Disabled (Admin Mode)' : 'Proceed to Checkout →'}
                </Button>
                <Button
                  onClick={onClose}
                  variant="outline"
                  className="w-full bg-white hover:bg-gray-50 text-gray-900 border border-gray-300 h-10 text-sm font-semibold"
                >
                  Continue Shopping
                </Button>
              </div>
            </div>
          )}
          </>
        )}
      </div>
    </>
  );
}

