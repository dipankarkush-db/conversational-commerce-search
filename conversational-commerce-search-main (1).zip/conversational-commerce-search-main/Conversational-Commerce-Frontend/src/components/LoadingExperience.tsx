import { useState, useEffect, useMemo, useRef } from 'react';
import { Sparkles, ShoppingBag, TrendingUp, Zap, Search, Brain } from 'lucide-react';
import { playSuccessChime } from '../utils/soundEffects';

interface LoadingStep {
  id: number;
  icon: React.ReactNode;
  title: string;
  tip: string;
}

// Pool of tips to randomize
const TIP_POOL = [
  "💡 You can search using natural language like 'laptop for students under $800'",
  "✨ Our AI remembers your conversation context and previous interactions",
  "🎯 We analyze 1000+ products in real-time to find your perfect match",
  "🛍️ Try asking: 'Show me wireless headphones under $350' or 'Find phones with good cameras'",
  "💬 You can refine results by saying 'Show me more from Samsung' or 'Find cheaper options'",
  "🔍 Our vector search understands product features, not just keywords",
  "🎨 Try asking: 'Find me dresses for a fancy dinner under $1000'",
  "📚 Search across Books, Electronics, Clothing, Home & Garden, and Sports categories",
  "⚡ Ask for specific brands like 'Show me Nike athletic wear under $120'",
  "🎁 Perfect for gift shopping: 'Find electronics for tech enthusiasts under $500'",
  "🏃 Try: 'Show me fitness equipment for home workouts under $250'",
  "📱 Our AI can compare products: 'What are good phones with cameras under $500?'",
  "🌟 Get personalized results based on your shopping history and preferences",
  "🎯 Combine multiple filters: 'Show me Random House fiction books under $30'",
  "💎 Ask about specific features: 'Find noise-canceling headphones under $650'"
];

// Shuffle array helper
const shuffleArray = <T,>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

interface LoadingExperienceProps {
  mode?: 'login' | 'chat';
}

export function LoadingExperience({ mode = 'login' }: LoadingExperienceProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const previousStep = useRef(0);

  // Randomize tips on each mount
  const randomizedTips = useMemo(() => shuffleArray(TIP_POOL), []);

  // Create loading steps with randomized tips
  const LOADING_STEPS: LoadingStep[] = useMemo(() => {
    if (mode === 'login') {
      return [
        {
          id: 1,
          icon: <ShoppingBag className="w-6 h-6" />,
          title: "Finding your perfect profile",
          tip: randomizedTips[0]
        },
        {
          id: 2,
          icon: <TrendingUp className="w-6 h-6" />,
          title: "Loading shopping preferences",
          tip: randomizedTips[1]
        },
        {
          id: 3,
          icon: <Sparkles className="w-6 h-6" />,
          title: "Preparing personalized recommendations",
          tip: randomizedTips[2]
        },
        {
          id: 4,
          icon: <Zap className="w-6 h-6" />,
          title: "Almost ready",
          tip: randomizedTips[3]
        }
      ];
    } else {
      // Chat mode - different titles (5 steps × 5 seconds = 25 seconds)
      return [
        {
          id: 1,
          icon: <Search className="w-6 h-6" />,
          title: "Searching product catalog",
          tip: randomizedTips[4]
        },
        {
          id: 2,
          icon: <Brain className="w-6 h-6" />,
          title: "Analyzing your request",
          tip: randomizedTips[5]
        },
        {
          id: 3,
          icon: <Sparkles className="w-6 h-6" />,
          title: "Finding perfect matches",
          tip: randomizedTips[6]
        },
        {
          id: 4,
          icon: <TrendingUp className="w-6 h-6" />,
          title: "Personalizing results",
          tip: randomizedTips[7]
        },
        {
          id: 5,
          icon: <Zap className="w-6 h-6" />,
          title: "Preparing final results",
          tip: randomizedTips[8]
        }
      ];
    }
  }, [mode, randomizedTips]);

  useEffect(() => {
    // Calculate total duration based on mode
    const stepsCount = LOADING_STEPS.length;
    const totalDuration = stepsCount * 5; // 5 seconds per step (login: 20s, chat: 25s)
    
    // Step progression
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < stepsCount - 1) {
          return prev + 1;
        }
        return prev;
      });
    }, 5000); // 5 seconds per step

    // Smooth progress bar (updates every 100ms)
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev < 100) {
          return prev + (100 / (totalDuration * 10)); // 100 / (totalDuration × 10 updates/sec)
        }
        return 100;
      });
    }, 100);

    // Rotate tips faster for chat mode (every 3 seconds)
    const tipInterval = mode === 'chat' ? setInterval(() => {
      setCurrentTipIndex((prev) => (prev + 1) % randomizedTips.length);
    }, 3000) : null;

    return () => {
      clearInterval(stepInterval);
      clearInterval(progressInterval);
      if (tipInterval) clearInterval(tipInterval);
    };
  }, [LOADING_STEPS.length, mode, randomizedTips.length]);

  // Play success chime when a step completes
  useEffect(() => {
    // Only play sound if step has increased (step completed)
    // Don't play on initial render (previousStep.current === currentStep)
    if (currentStep > previousStep.current && currentStep > 0) {
      playSuccessChime(currentStep); // Pass the step number for musical progression (do-re-mi-fa-sol)
    }
    previousStep.current = currentStep;
  }, [currentStep]);

  // For login mode, keep full screen experience
  if (mode === 'login') {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="max-w-md w-full px-6">
          {/* Main Loading Animation */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#FF3621] to-[#FF5F46] rounded-2xl mb-4 animate-pulse">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-gray-900 text-lg font-semibold mb-2">
              Setting up your AI shopping assistant
            </h2>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#FF3621] to-[#E62F1C] transition-all duration-300 ease-out rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 text-center mt-2">
              {Math.round(progress)}%
            </p>
          </div>

          {/* Steps for login */}
          <div className="space-y-4 mb-8">
            {LOADING_STEPS.map((step, index) => {
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;
              
              return (
                <div
                  key={step.id}
                  className={`flex items-start gap-3 p-4 rounded-lg transition-all duration-500 ${
                    isActive 
                      ? 'bg-orange-200/20 border border-orange-200' 
                      : isCompleted 
                      ? 'bg-gray-50 opacity-60' 
                      : 'opacity-30'
                  }`}
                >
                  <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                    isActive 
                      ? 'bg-[#FF3621] text-white' 
                      : isCompleted 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 text-gray-400'
                  }`}>
                    {isCompleted ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                      </svg>
                    ) : (
                      step.icon
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className={`text-sm font-medium mb-1 transition-colors ${
                      isActive ? 'text-gray-900' : 'text-gray-600'
                    }`}>
                      {step.title}
                    </h3>
                    {isActive && (
                      <p className="text-xs text-gray-600 animate-fade-in">
                        {step.tip}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <p className="text-xs text-center text-gray-500">
            Connecting to Databricks • Unity Catalog • Vector Search
          </p>
        </div>
      </div>
    );
  }

  // For chat mode - Option 3: Enhanced with shimmer, compact centered steps, rotating tips
  const activeStep = LOADING_STEPS[currentStep];
  
  return (
    <div className="bg-gradient-to-br from-white to-orange-200/20 border border-orange-200 rounded-xl p-4 shadow-sm w-full">
      {/* Header with Icon and Step Counter */}
      <div className="flex items-start gap-3">
        {/* Animated Icon with Shimmer - Changes based on step */}
        <div className="relative flex-shrink-0 w-10 h-10 bg-gradient-to-br from-[#FF3621] to-[#FF5F46] rounded-lg flex items-center justify-center text-white overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
          <div className="relative z-10">
            {activeStep.icon}
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          {/* Title with Step Counter */}
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-semibold text-gray-900">
              {activeStep.title}
            </h3>
            <span className="text-sm text-gray-500 font-medium whitespace-nowrap ml-3">
              Step {currentStep + 1} of {LOADING_STEPS.length}
            </span>
          </div>

          {/* Elevated 3D Progress Bubbles */}
          <div className="flex items-center justify-center mb-3">
            <div className="flex items-center gap-2 py-2">
              {LOADING_STEPS.map((step, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div 
                    className={`relative w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all duration-500 ${
                      index < currentStep
                        ? 'bg-green-500 text-white shadow-[0_4px_12px_rgba(34,197,94,0.4)]' 
                        : index === currentStep
                        ? 'bg-gradient-to-br from-lava-500 to-lava-600 text-white shadow-[0_6px_20px_rgba(255,54,33,0.5)] scale-110'
                        : 'bg-white text-gray-400 shadow-[inset_0_2px_8px_rgba(0,0,0,0.1)] border border-gray-200'
                    }`}
                    style={{
                      transform: index === currentStep ? 'translateY(-2px) scale(1.1)' : 'translateY(0) scale(1)'
                    }}
                    title={step.title}
                  >
                    {/* Inner highlight for 3D effect */}
                    <div className={`absolute top-0.5 left-1/2 -translate-x-1/2 w-5 h-1.5 rounded-full blur-sm ${
                      index <= currentStep ? 'bg-white opacity-30' : 'bg-transparent'
                    }`} />
                    
                    {index < currentStep ? (
                      <svg className="w-3.5 h-3.5 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                      </svg>
                    ) : (
                      <span className="relative z-10">{index + 1}</span>
                    )}
                  </div>
                  {index < LOADING_STEPS.length - 1 && (
                    <div className={`h-0.5 w-4 transition-all duration-500 rounded-full ${
                      index < currentStep 
                        ? 'bg-green-400 shadow-[0_2px_8px_rgba(34,197,94,0.3)]' 
                        : 'bg-gray-300'
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Rotating Tips - More Compact */}
          <div className="bg-white border border-orange-200 rounded-lg p-2.5">
            <p className="text-xs text-gray-600 flex items-start gap-2 animate-fade-in leading-relaxed" key={currentTipIndex}>
              <span className="flex-shrink-0">💡</span>
              <span>{randomizedTips[currentTipIndex]}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

