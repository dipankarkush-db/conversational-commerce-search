import { useState, useEffect, useRef } from 'react';
import { SlidersHorizontal, X, ArrowUp } from 'lucide-react';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import { ImageWithFallback } from './ImageWithFallback';

interface Product {
  product_id: string;
  name: string;
  brand: string;
  category: string;
  subcategory: string;
  price: number;
  description?: string;
  avg_rating: number;
}

interface BrowseProductsProps {
  userPreferredCategories: string[];
}

const API_BASE_URL = import.meta.env.VITE_API_URL || (
  import.meta.env.MODE === 'production' ? '' : 'http://localhost:8000'
);

// Generate product image URL - same function used in cart and chat
const getProductImageUrl = (category: string, subcategory: string, productId: string): string => {
  // Enhanced image mapping for specific subcategories
  const subcategoryImages: Record<string, string> = {
    // Electronics
    'Headphones': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
    'Laptops': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Laptop': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Smartphones': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Tablets': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Tablet': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Phone': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Camera': 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=400&fit=crop',
    'Smart Watches': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Smart Watch': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Watch': 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=400&h=400&fit=crop',
    'Gaming': 'https://images.unsplash.com/photo-1486401899868-0e435ed85128?w=400&h=400&fit=crop',
    'TV': 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=400&fit=crop',
    
    // Books
    'Fiction': 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop',
    'Non-Fiction': 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=400&fit=crop',
    'Science': 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400&h=400&fit=crop',
    'History': 'https://images.unsplash.com/photo-1461360228754-6e81c478b882?w=400&h=400&fit=crop',
    'Biography': 'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=400&h=400&fit=crop',
    'Self-Help': 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&h=400&fit=crop',
    'Textbook': 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400&h=400&fit=crop',
    'Children': 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=400&fit=crop',
    
    // Sports & Outdoors
    'Fitness': 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=400&fit=crop',
    'Outdoor Gear': 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=400&h=400&fit=crop',
    'Hiking Boots': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Trail Shoes': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    'Hiking Shoes': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    'Hiking': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Trail': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    'Sports Equipment': 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=400&h=400&fit=crop',
    'Athletic Wear': 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=400&fit=crop',
    'Camping': 'https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?w=400&h=400&fit=crop',
    'Cycling': 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=400&h=400&fit=crop',
    
    // Clothing
    'Outerwear': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Pants': 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400&h=400&fit=crop',
    'Shirts': 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=400&h=400&fit=crop',
    'Jacket': 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop',
    'Coat': 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400&h=400&fit=crop',
    'Dress': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Dresses': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Shoes': 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
    'Accessories': 'https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=400&h=400&fit=crop',
    'Hat': 'https://images.unsplash.com/photo-1521369909029-2afed882baee?w=400&h=400&fit=crop',
    
    // Home & Garden
    'Furniture': 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&h=400&fit=crop',
    'Kitchen': 'https://images.unsplash.com/photo-1556911220-bff31c812dba?w=400&h=400&fit=crop',
    'Decor': 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=400&h=400&fit=crop',
    'Garden': 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400&h=400&fit=crop',
    'Tools': 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400&h=400&fit=crop',
    'Storage': 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop',
    'Organizer': 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop',
    'Organizers': 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop',
  };
  
  // Try exact match first
  if (subcategoryImages[subcategory]) {
    return subcategoryImages[subcategory];
  }
  
  // Try partial, case-insensitive match
  const subcategoryLower = subcategory.toLowerCase();
  for (const [key, imageUrl] of Object.entries(subcategoryImages)) {
    if (subcategoryLower.includes(key.toLowerCase()) || key.toLowerCase().includes(subcategoryLower)) {
      return imageUrl;
    }
  }
  
  // Category-based fallback
  const categoryLower = category.toLowerCase();
  if (categoryLower.includes('home') || categoryLower.includes('garden') || categoryLower.includes('furniture')) {
    return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('electronics') || categoryLower.includes('tech')) {
    return 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('book')) {
    return 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('clothing') || categoryLower.includes('fashion')) {
    return 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('sports') || categoryLower.includes('outdoor')) {
    return 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400&h=400&fit=crop';
  }
  
  // Final fallback
  return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop';
};

// Category to subcategories mapping
const CATEGORIES_MAP: Record<string, string[]> = {
  'Books': ['Fiction', 'Non-Fiction', 'Science', 'History', 'Biography', 'Self-Help'],
  'Electronics': ['Smartphones', 'Laptops', 'Headphones', 'Tablets', 'Smart Watches', 'Gaming'],
  'Sports & Outdoors': ['Fitness', 'Outdoor Gear', 'Sports Equipment', 'Athletic Wear', 'Camping'],
  'Clothing': ['Shirts', 'Pants', 'Dresses', 'Shoes', 'Accessories', 'Outerwear'],
  'Home & Garden': ['Furniture', 'Kitchen', 'Bathroom', 'Garden', 'Decor', 'Storage']
};

export function BrowseProducts({ userPreferredCategories }: BrowseProductsProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [sortBy, setSortBy] = useState('featured');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [expandedDescriptions, setExpandedDescriptions] = useState<Set<string>>(new Set());
  const { addItem } = useCart();
  const topRef = useRef<HTMLDivElement>(null);

  // Fetch products
  useEffect(() => {
    fetchProducts(false);
  }, [selectedCategory, selectedSubcategory]);

  // Scroll to top detection
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const fetchProducts = async (loadMore: boolean = false) => {
    if (loadMore) {
      setLoadingMore(true);
    } else {
      setLoading(true);
    }
    
    try {
      const params = new URLSearchParams();
      // Only add filters if not "all"
      if (selectedCategory && selectedCategory !== 'all') {
        params.append('category', selectedCategory);
      }
      if (selectedSubcategory && selectedSubcategory !== 'all') {
        params.append('subcategory', selectedSubcategory);
      }
      params.append('limit', '100');

      const response = await fetch(`${API_BASE_URL}/api/products?${params}`);
      if (!response.ok) throw new Error('Failed to fetch products');
      
      const data = await response.json();
      
      if (loadMore) {
        // Append new products to existing ones
        setProducts(prev => [...prev, ...data]);
      } else {
        // Replace products
        setProducts(data);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Failed to load products');
      if (!loadMore) {
        setProducts([]);
      }
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const handleLoadMore = () => {
    fetchProducts(true);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Sanitize description to remove product ID and metadata
  const sanitizeDescription = (description: string, productId: string): string => {
    if (!description) return '';
    
    let cleaned = description;
    
    // Remove product ID (case-insensitive)
    cleaned = cleaned.replace(new RegExp(productId, 'gi'), '');
    
    // Remove common patterns like "ID:", "Product ID:", etc.
    cleaned = cleaned.replace(/\b(product\s*)?id\s*:?\s*/gi, '');
    
    // Clean up extra whitespace, multiple spaces, and trim
    cleaned = cleaned.replace(/\s+/g, ' ').trim();
    
    // Remove leading punctuation that might be left over
    cleaned = cleaned.replace(/^[,\-:.\s]+/, '');
    
    return cleaned;
  };

  // Truncate description to approximately 60 characters
  const truncateDescription = (description: string, maxLength: number = 60): string => {
    if (description.length <= maxLength) return description;
    
    // Find the last space before maxLength to avoid cutting words
    const truncated = description.substring(0, maxLength);
    const lastSpace = truncated.lastIndexOf(' ');
    
    return lastSpace > 0 ? truncated.substring(0, lastSpace) : truncated;
  };

  // Toggle description expand/collapse
  const toggleDescription = (productId: string) => {
    setExpandedDescriptions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(productId)) {
        newSet.delete(productId);
      } else {
        newSet.add(productId);
      }
      return newSet;
    });
  };

  // Sort products
  const sortedProducts = [...products].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'name':
        return a.name.localeCompare(b.name);
      case 'rating':
        return b.avg_rating - a.avg_rating;
      default:
        return 0; // featured
    }
  });

  const handleAddToCart = (product: Product) => {
    addItem({
      product_id: product.product_id,
      name: product.name,
      brand: product.brand,
      category: product.category,
      subcategory: product.subcategory,
      price: product.price,
      quantity: 1,
      description: product.description
    });
    toast.success(`Added ${product.name} to cart!`);
  };

  const clearFilters = () => {
    setSelectedCategory('all');
    setSelectedSubcategory('all');
  };

  const availableSubcategories = (selectedCategory && selectedCategory !== 'all') ? CATEGORIES_MAP[selectedCategory] || [] : [];
  const hasActiveFilters = selectedCategory !== 'all' || selectedSubcategory !== 'all';

  return (
    <div className="space-y-6 relative" ref={topRef}>
      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 z-50 bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
          aria-label="Scroll to top"
        >
          <ArrowUp className="w-6 h-6" />
        </button>
      )}

      {/* Filters and Sort Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="gap-2"
            onClick={() => setShowFilters(!showFilters)}
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters
          </Button>
          <span className="text-sm text-gray-600">
            {loading ? 'Loading...' : `Showing ${sortedProducts.length} products`}
          </span>
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-[#FF3621] hover:text-[#FF5F46]"
            >
              <X className="w-4 h-4 mr-1" />
              Clear Filters
            </Button>
          )}
        </div>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="featured">Featured</SelectItem>
            <SelectItem value="price-low">Price: Low to High</SelectItem>
            <SelectItem value="price-high">Price: High to Low</SelectItem>
            <SelectItem value="rating">Top Rated</SelectItem>
            <SelectItem value="name">Name: A-Z</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Filter Panel */}
      {showFilters && (
        <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="font-semibold text-gray-900 mb-4">Filter Products</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Category Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <Select value={selectedCategory} onValueChange={(val) => {
                setSelectedCategory(val);
                setSelectedSubcategory('all'); // Reset subcategory when category changes
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {Object.keys(CATEGORIES_MAP).map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Subcategory Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Subcategory</label>
              <Select 
                value={selectedSubcategory} 
                onValueChange={setSelectedSubcategory}
                disabled={selectedCategory === 'all'}
              >
                <SelectTrigger>
                  <SelectValue placeholder={selectedCategory !== 'all' ? "All Subcategories" : "Select category first"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subcategories</SelectItem>
                  {availableSubcategories.map((subcat) => (
                    <SelectItem key={subcat} value={subcat}>{subcat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      )}

      {/* Products Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-white rounded-lg border border-gray-200 overflow-hidden animate-pulse">
              <div className="h-48 bg-gray-200"></div>
              <div className="p-4 space-y-3">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      ) : sortedProducts.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <div className="text-6xl mb-4">🛍️</div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No products found</h3>
          <p className="text-gray-500 mb-4">Try adjusting your filters or browse all products</p>
          {hasActiveFilters && (
            <Button onClick={clearFilters} variant="outline">
              Clear Filters
            </Button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedProducts.map((product) => (
              <div
                key={product.product_id}
                className="product-card bg-white rounded-lg border border-gray-200 hover:border-[#FF3621] overflow-hidden shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 group"
              >
                {/* Product Image */}
                <div className="relative h-48 overflow-hidden bg-gray-100">
                  <ImageWithFallback
                    src={getProductImageUrl(product.category, product.subcategory || '', product.product_id)}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  {product.avg_rating >= 4.5 && (
                    <div className="absolute top-2 right-2">
                      <div className="bg-[#FF3621] text-white text-xs px-2 py-1 rounded-full font-semibold shadow-md">
                        ⭐ Top Rated
                      </div>
                    </div>
                  )}
                </div>

                {/* Product Info */}
                <div className="p-5">
                  <div className="text-[11px] text-gray-400 mb-1 uppercase tracking-wide">{product.brand}</div>
                  <h3 className="text-base font-bold text-gray-900 mb-0 line-clamp-2 leading-tight">
                    {product.name}
                  </h3>
                  
                  {/* Product Description */}
                  {product.description && (() => {
                    const sanitized = sanitizeDescription(product.description, product.product_id);
                    const isExpanded = expandedDescriptions.has(product.product_id);
                    const needsTruncation = sanitized.length > 60;
                    const displayText = isExpanded || !needsTruncation 
                      ? sanitized 
                      : truncateDescription(sanitized);
                    
                    return sanitized ? (
                      <p className="text-[13px] text-gray-600 mb-3 leading-relaxed">
                        {displayText}
                        {needsTruncation && (
                          <>
                            {!isExpanded && '... '}
                            {isExpanded && <br />}
                            <button
                              onClick={() => toggleDescription(product.product_id)}
                              className="text-[#FF3621] hover:text-[#FF5F46] hover:underline font-medium inline-flex items-center gap-1"
                            >
                              {isExpanded ? 'show less' : (
                                <>
                                  more
                                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                  </svg>
                                </>
                              )}
                            </button>
                          </>
                        )}
                      </p>
                    ) : null;
                  })()}
                  
                  {/* Rating */}
                  <div className="flex items-center gap-1.5 mb-3">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <span 
                          key={star} 
                          className={`text-base ${star <= Math.round(product.avg_rating) ? 'text-yellow-400' : 'text-gray-300'}`}
                        >
                          ★
                        </span>
                      ))}
                    </div>
                    <span className="text-xs text-gray-500 font-medium">({product.avg_rating.toFixed(1)})</span>
                  </div>

                  {/* Category & Subcategory Badges */}
                  <div className="mb-4 flex flex-wrap gap-1.5">
                    <span className="inline-block text-[11px] bg-orange-50 text-orange-700 px-2.5 py-1 rounded-md font-medium">
                      {product.category}
                    </span>
                    {product.subcategory && (
                      <span className="inline-block text-[11px] bg-gray-100 text-gray-700 px-2.5 py-1 rounded-md font-medium">
                        {product.subcategory}
                      </span>
                    )}
                  </div>

                  {/* Price */}
                  <div className="mb-4">
                    <span className="text-2xl font-extrabold bg-gradient-to-r from-lava-600 to-lava-600 bg-clip-text text-transparent">
                      ${product.price.toFixed(2)}
                    </span>
                  </div>

                  {/* Add to Cart Button */}
                  <Button
                    onClick={() => handleAddToCart(product)}
                    className="w-full bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white shadow-sm hover:shadow-md transition-all duration-200 flex items-center justify-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    Add to Cart
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Load More Button */}
          {sortedProducts.length > 0 && (
            <div className="flex justify-center mt-8">
              <Button
                onClick={handleLoadMore}
                disabled={loadingMore}
                className="bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white px-8 py-3 text-base font-semibold"
              >
                {loadingMore ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Loading...
                  </>
                ) : (
                  <>🔄 Load More Products</>
                )}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
