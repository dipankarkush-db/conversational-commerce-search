import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { User, Mail, ShoppingBag, DollarSign, Tag, ChevronRight } from 'lucide-react';
import { CustomerInfo } from '../services/api';
import { AdminCustomerProfileModal } from './AdminCustomerProfileModal';

interface AdminCustomerCardProps {
  customer: CustomerInfo;
  onSelectCustomer: (customer: CustomerInfo) => void;
}

export function AdminCustomerCard({ customer, onSelectCustomer }: AdminCustomerCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Parse preferred categories
  const categories = customer.preferred_categories 
    ? customer.preferred_categories.split(',').map(c => c.trim()).slice(0, 3)
    : [];

  // Get persona badge color
  const getPersonaBadgeColor = (persona: string | undefined) => {
    if (!persona) return 'bg-gray-100 text-gray-700';
    
    const personaLower = persona.toLowerCase();
    if (personaLower.includes('tech')) return 'bg-blue-100 text-blue-700';
    if (personaLower.includes('fashion')) return 'bg-pink-100 text-pink-700';
    if (personaLower.includes('home')) return 'bg-green-100 text-green-700';
    if (personaLower.includes('book')) return 'bg-purple-100 text-purple-700';
    if (personaLower.includes('fitness')) return 'bg-orange-100 text-orange-700';
    if (personaLower.includes('bargain')) return 'bg-yellow-100 text-yellow-700';
    return 'bg-gray-100 text-gray-700';
  };

  const handleCardClick = () => {
    onSelectCustomer(customer);
  };

  const handleMoreClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card click
    setIsModalOpen(true);
  };

  return (
    <>
      <Card 
        className="p-5 border border-gray-200 hover:border-[#FF3621] transition-all hover:shadow-lg group bg-white cursor-pointer"
        onClick={handleCardClick}
      >
      {/* Header */}
      <div className="mb-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className="w-12 h-12 bg-gradient-to-br from-[#FF3621] to-[#FF5F46] rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-lg font-semibold text-[#FF3621] group-hover:text-[#E62F1C] transition-colors text-left w-full truncate">
                {customer.customer_name}
              </div>
              <div className="flex items-center gap-1.5 text-sm text-gray-500 mt-0.5">
                <Mail className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{customer.customer_email}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Persona Badge - Full Width Below Header */}
        {customer.persona && (
          <Badge className={`${getPersonaBadgeColor(customer.persona)} border-0 text-xs font-medium`}>
            {customer.persona}
          </Badge>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
          <ShoppingBag className="w-4 h-4 text-gray-600 flex-shrink-0" />
          <div className="min-w-0">
            <div className="text-xs text-gray-500">Orders</div>
            <div className="text-sm font-semibold text-gray-900">{customer.total_orders || 0}</div>
          </div>
        </div>
        <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
          <DollarSign className="w-4 h-4 text-gray-600 flex-shrink-0" />
          <div className="min-w-0">
            <div className="text-xs text-gray-500">Total Spent</div>
            <div className="text-sm font-semibold text-gray-900">
              ${(customer.total_spent || 0).toFixed(2)}
            </div>
          </div>
        </div>
      </div>

      {/* Preferred Categories */}
      {categories.length > 0 && (
        <div className="border-t border-gray-100 pt-3">
          <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-2">
            <Tag className="w-3.5 h-3.5" />
            <span>Preferred Categories</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {categories.map((category, idx) => (
              <Badge 
                key={idx} 
                variant="outline" 
                className="text-xs bg-white border-gray-200 text-gray-700"
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* More Details Button */}
      <div className="mt-3 pt-3 border-t border-gray-100">
        <button
          onClick={handleMoreClick}
          className="w-full flex items-center justify-center gap-2 text-sm font-medium text-[#FF3621] hover:text-[#E62F1C] transition-colors"
        >
          <span>More Details</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </Card>

    {/* Customer Profile Modal */}
    <AdminCustomerProfileModal
      customerId={customer.customer_id}
      customerName={customer.customer_name}
      isOpen={isModalOpen}
      onClose={() => setIsModalOpen(false)}
    />
    </>
  );
}

