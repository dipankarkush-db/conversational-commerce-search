import { Card } from './ui/card';
import { Button } from './ui/button';
import { User, LogOut, ShoppingBag, DollarSign, Heart, ChevronDown, ChevronUp, Clock, UserCircle } from 'lucide-react';
import { CustomerInteraction } from '../services/api';
import { useState } from 'react';

interface UserProfile {
  customer_id: string;
  name: string;
  email: string;
  gender?: string;
  persona: string;
  preferred_categories: string[];
  price_sensitivity: string;
  brand_loyalty: string;
  total_purchases: number;
  total_spent: number;
  favorite_brands: string[];
  recent_searches: string[];
  purchase_history: PurchaseItem[];
}

interface PurchaseItem {
  product_name: string;
  category: string;
  price: number;
  date: string;
  rating?: number;
}

interface UserProfilePanelProps {
  user: UserProfile;
  interactions: CustomerInteraction[];
  onLogout: () => void;
}

export function UserProfilePanel({ user, interactions, onLogout }: UserProfilePanelProps) {
  const [isHistoryExpanded, setIsHistoryExpanded] = useState(true);
  const [isProfileExpanded, setIsProfileExpanded] = useState(true);

  const getInteractionEmoji = (type: string) => {
    const emojiMap: Record<string, string> = {
      'purchase': '💰',
      'view': '👀',
      'cart_add': '🛒',
      'rating': '⭐',
      'review': '📝'
    };
    return emojiMap[type.toLowerCase()] || '📦';
  };

  // Get user initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="space-y-3">
      {/* User Info Card */}
      <Card className="p-3 border border-gray-200">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF3621] to-[#FF5F46] flex items-center justify-center flex-shrink-0 shadow-sm">
            <span className="text-white font-bold text-sm">
              {getInitials(user.name)}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 truncate text-sm">{user.name}</h3>
            <p className="text-xs text-gray-500 truncate">{user.email}</p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs">
            <ShoppingBag className="w-3.5 h-3.5 text-gray-400" />
            <span className="text-gray-600">{user.total_purchases} purchases</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <DollarSign className="w-3.5 h-3.5 text-gray-400" />
            <span className="text-gray-600">${user.total_spent.toFixed(2)} spent</span>
          </div>
        </div>
      </Card>

      {/* Shopping History & Activity */}
      <Card className="border border-gray-200">
        <button 
          type="button"
          className="w-full flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 transition-colors text-left border-b border-gray-100"
          onClick={(e) => {
            e.preventDefault();
            setIsHistoryExpanded(!isHistoryExpanded);
          }}
        >
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#FF3621]" />
            <h3 className="font-semibold text-gray-900 text-sm">Recent Shopping History</h3>
          </div>
          {isHistoryExpanded ? (
            <ChevronUp className="w-4 h-4 text-gray-400 flex-shrink-0" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
          )}
        </button>
        
        {isHistoryExpanded && (
          <div className="p-3">
            {interactions.length > 0 ? (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {interactions.slice(0, 5).map((interaction, index) => (
                  <div 
                    key={index}
                    className="p-2.5 bg-gray-50 rounded border-l-2 border-l-[#FF3621]"
                  >
                    <div className="text-sm font-medium text-[#FF3621] mb-1">
                      {getInteractionEmoji(interaction.interaction_type)} {interaction.interaction_type.replace('_', ' ').toUpperCase()}
                    </div>
                    <div className="text-base text-gray-900 font-semibold leading-tight mb-1">
                      {interaction.product_name.length > 35 
                        ? `${interaction.product_name.substring(0, 35)}...`
                        : interaction.product_name
                      }
                    </div>
                    <div className="text-sm text-gray-500">
                      ${interaction.product_price.toFixed(2)} • {interaction.days_since_interaction}d ago
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 italic text-center py-4">
                No recent interactions found
              </p>
            )}
          </div>
        )}
      </Card>

      {/* Persona Card */}
      <Card className="border border-gray-200">
        <button 
          type="button"
          className="w-full flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 transition-colors text-left border-b border-gray-100"
          onClick={(e) => {
            e.preventDefault();
            setIsProfileExpanded(!isProfileExpanded);
          }}
        >
          <div className="flex items-center gap-2">
            <UserCircle className="w-4 h-4 text-[#FF3621]" />
            <h3 className="font-semibold text-gray-900 text-sm">Shopping Profile</h3>
          </div>
          {isProfileExpanded ? (
            <ChevronUp className="w-4 h-4 text-gray-400 flex-shrink-0" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
          )}
        </button>
        
        {isProfileExpanded && (
          <div className="p-3 space-y-2 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-gray-500">Persona</span>
              <p className="text-gray-900 font-medium text-right">{user.persona}</p>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-500">Price Sensitivity</span>
              <p className="text-gray-900 text-right">{user.price_sensitivity}</p>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-500">Brand Loyalty</span>
              <p className="text-gray-900 text-right">{user.brand_loyalty}</p>
            </div>
          </div>
        )}
      </Card>

      {/* Preferences Card */}
      {user.preferred_categories && user.preferred_categories.length > 0 && (
        <Card className="p-3 border border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-2 text-xs flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5" />
            Preferences
          </h3>
          <div className="flex flex-wrap gap-1.5">
            {user.preferred_categories.map((category, index) => (
              <span
                key={index}
                className="px-2 py-0.5 bg-orange-50 text-[#FF3621] text-xs rounded-full"
              >
                {category}
              </span>
            ))}
          </div>
        </Card>
      )}

      {/* Favorite Brands */}
      {user.favorite_brands && user.favorite_brands.length > 0 && (
        <Card className="p-3 border border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-2 text-xs">Favorite Brands</h3>
          <div className="flex flex-wrap gap-1.5">
            {user.favorite_brands.map((brand, index) => (
              <span
                key={index}
                className="px-2 py-0.5 bg-gray-100 text-gray-700 text-xs rounded-full"
              >
                {brand}
              </span>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

