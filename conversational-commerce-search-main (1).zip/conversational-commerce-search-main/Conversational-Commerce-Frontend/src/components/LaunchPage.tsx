import { Card } from './ui/card';
import { Button } from './ui/button';
import { Sparkles, MessageSquare, Brain, ShoppingBag, Loader2, Shield } from 'lucide-react';
import { ImageWithFallback } from './ImageWithFallback';
import { initializeAudio } from '../utils/soundEffects';

interface LaunchPageProps {
  onLogin: () => void;
  onAdminClick: () => void;
  isLoading?: boolean;
}

export function LaunchPage({ onLogin, onAdminClick, isLoading = false }: LaunchPageProps) {
  const handleLogin = () => {
    // Initialize audio context on user interaction (browser autoplay policy)
    initializeAudio();
    onLogin();
  };
  return (
    <div className="h-screen relative overflow-hidden flex flex-col">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1758686254082-0f91a27b3075?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlY29tbWVyY2UlMjBzaG9wcGluZyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYyMjI0ODEwfDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Modern ecommerce background"
          className="w-full h-full object-cover"
        />
        {/* Gradient Overlays - Increased text visibility (7% more opaque) for better readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/45 via-20% via-white/90 via-30% to-transparent to-60%"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-oat-light/45 via-20% via-oat-light/90 via-30% to-transparent to-60%"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col h-full">
        {/* Header - Databricks Style */}
        <header className="border-b border-gray-lines bg-[#EEEDE9] backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="flex justify-between items-center h-14">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-[#FF3621] rounded flex items-center justify-center">
                  <ShoppingBag className="w-4 h-4 text-white" />
                </div>
                <span className="text-lg font-medium text-navy-900">ConvoCommerce</span>
              </div>
              <div className="text-xs text-gray-navigation">AI-Powered Shopping Assistant</div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex items-center">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 w-full">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Left Column - Hero */}
              <div>
                {/* Badge - Databricks Style */}
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-orange-200/20 border border-[#FF5F46]/30 rounded-full mb-6">
                  <Sparkles className="w-3.5 h-3.5 text-[#FF3621]" />
                  <span className="text-xs font-medium text-[#FF3621]">Powered by Databricks AI</span>
                </div>

                {/* Main Headline - Databricks Typography */}
                <h1 className="text-5xl lg:text-6xl font-semibold text-navy-900 mb-5 tracking-tight leading-tight">
                  Conversational Commerce Search
                </h1>

                {/* Description - Databricks Style */}
                <p className="text-lg text-navy-600 mb-12 leading-relaxed">
                  Experience the future of online shopping with AI-powered conversations. Our intelligent assistant 
                  understands your needs and delivers personalized product recommendations in real-time.
                </p>

                {/* CTA Buttons - Databricks Style */}
                <div className="flex flex-col sm:flex-row gap-4 mb-4 justify-center">
                  <Button 
                    onClick={handleLogin}
                    disabled={isLoading}
                    size="lg" 
                    className="bg-[#FF3621] hover:bg-[#E62F1C] text-white px-10 py-7 h-auto shadow-lg hover:shadow-xl transition-all rounded-md font-medium min-w-[280px] w-full sm:w-auto"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Loading Your Profile...
                      </>
                    ) : (
                      <>
                        Start Shopping with AI
                        <MessageSquare className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    onClick={onAdminClick}
                    disabled={isLoading}
                    size="lg" 
                    className="bg-navy-800 hover:bg-navy-700 text-white px-10 py-7 h-auto shadow-lg hover:shadow-xl transition-all rounded-md font-medium min-w-[280px] w-full sm:w-auto"
                  >
                    <Shield className="w-5 h-5 mr-2" />
                    Admin Experience
                  </Button>
                </div>

                {/* Navy 800 Border Line */}
                <div className="border-t border-[#1B3139] mt-28 mb-0"></div>

                {/* Green Feature Dots */}
                <div className="flex flex-wrap gap-4 justify-center pt-4 pb-2">
                  <div className="flex items-center gap-2 text-sm text-navy-700">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="font-medium">Real-time Responses</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-navy-700">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="font-medium">Personalized</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-navy-700">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="font-medium">Natural Language</span>
                  </div>
                </div>
              </div>

              {/* Right Column - Placeholder */}
              <div></div>
            </div>
          </div>
        </main>

        {/* Static Box with Continuous Ticker Scroll - Full Width Edge to Edge */}
        <div className="w-full">
          <div className="w-full">
            <div className="bg-white/80 backdrop-blur-sm overflow-hidden shadow-sm">
              <div className="flex items-center h-[60px]">
                <div className="ticker-content flex items-center">
                  {/* Repeat content 4 times for seamless infinite scroll */}
                  {[1, 2, 3, 4].map((set) => (
                    <div key={set} className="flex items-center flex-shrink-0">
                      {/* Feature 1 */}
                      <div className="flex items-center gap-3 px-8">
                        <div className="w-10 h-10 bg-orange-50 rounded flex items-center justify-center flex-shrink-0">
                          <MessageSquare className="w-5 h-5 text-[#FF3621]" />
                        </div>
                        <div className="flex flex-col justify-center whitespace-nowrap">
                          <h3 className="text-sm font-semibold text-navy-900 leading-snug">Natural Language Search</h3>
                          <p className="text-xs text-navy-600 leading-snug">Search using everyday language</p>
                        </div>
                      </div>

                      {/* Separator */}
                      <div className="w-px h-8 bg-gray-200 mx-6"></div>

                      {/* Feature 2 */}
                      <div className="flex items-center gap-3 px-8">
                        <div className="w-10 h-10 bg-orange-50 rounded flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-5 h-5 text-[#FF3621]" />
                        </div>
                        <div className="flex flex-col justify-center whitespace-nowrap">
                          <h3 className="text-sm font-semibold text-navy-900 leading-snug">AI-Powered Recommendations</h3>
                          <p className="text-xs text-navy-600 leading-snug">Personalized suggestions that learn</p>
                        </div>
                      </div>

                      {/* Separator */}
                      <div className="w-px h-8 bg-gray-200 mx-6"></div>

                      {/* Feature 3 */}
                      <div className="flex items-center gap-3 px-8">
                        <div className="w-10 h-10 bg-orange-50 rounded flex items-center justify-center flex-shrink-0">
                          <Brain className="w-5 h-5 text-[#FF3621]" />
                        </div>
                        <div className="flex flex-col justify-center whitespace-nowrap">
                          <h3 className="text-sm font-semibold text-navy-900 leading-snug">Smart Context Memory</h3>
                          <p className="text-xs text-navy-600 leading-snug">Multi-turn conversations that remember</p>
                        </div>
                      </div>

                      {/* THICK DIVIDER - Start of Powered By Section - Reduced spacing */}
                      <div className="w-1 h-10 bg-[#FF3621] rounded-full mx-3"></div>

                      {/* Powered By Label */}
                      <div className="flex items-center gap-2 px-6">
                        <span className="text-xs text-gray-navigation uppercase tracking-wide font-medium whitespace-nowrap">Powered By</span>
                      </div>

                      {/* Separator */}
                      <div className="w-px h-8 bg-gray-200 mx-2"></div>

                      {/* Databricks */}
                      <div className="flex items-center gap-2 px-6">
                        <div className="w-8 h-8 bg-[#FF3621] rounded flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-[10px] font-bold">DB</span>
                        </div>
                        <span className="text-sm text-navy-800 font-medium whitespace-nowrap">Databricks</span>
                      </div>

                      {/* Separator */}
                      <div className="w-px h-8 bg-gray-200 mx-2"></div>

                      {/* Unity Catalog */}
                      <div className="flex items-center gap-2 px-6">
                        <div className="w-8 h-8 bg-navy-900 rounded flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-[10px] font-bold">UC</span>
                        </div>
                        <span className="text-sm text-navy-800 font-medium whitespace-nowrap">Unity Catalog</span>
                      </div>

                      {/* Separator */}
                      <div className="w-px h-8 bg-gray-200 mx-2"></div>

                      {/* Vector Search */}
                      <div className="flex items-center gap-2 px-6">
                        <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-[10px] font-bold">VS</span>
                        </div>
                        <span className="text-sm text-navy-800 font-medium whitespace-nowrap">Vector Search</span>
                      </div>

                      {/* Separator */}
                      <div className="w-px h-8 bg-gray-200 mx-2"></div>

                      {/* GTE-Large */}
                      <div className="flex items-center gap-2 px-6">
                        <div className="w-8 h-8 bg-maroon-600 rounded flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-[10px] font-bold">GT</span>
                        </div>
                        <span className="text-sm text-navy-800 font-medium whitespace-nowrap">GTE-Large</span>
                      </div>

                      {/* Separator */}
                      <div className="w-px h-8 bg-gray-200 mx-2"></div>

                      {/* Claude 3.7 */}
                      <div className="flex items-center gap-2 px-6">
                        <div className="w-8 h-8 bg-navy-700 rounded flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-[10px] font-bold">C3</span>
                        </div>
                        <span className="text-sm text-navy-800 font-medium whitespace-nowrap">Claude 3.7</span>
                      </div>

                      {/* THICK DIVIDER - End of Powered By Section */}
                      <div className="w-1 h-10 bg-[#FF3621] rounded-full mx-6"></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer - Databricks Style */}
        <footer className="bg-white/70 backdrop-blur-sm mt-0">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="flex justify-between items-center h-12 text-xs text-gray-navigation">
              <div>© 2025 ConvoCommerce. All rights reserved.</div>
              <div className="font-medium">Transforming shopping with AI</div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
