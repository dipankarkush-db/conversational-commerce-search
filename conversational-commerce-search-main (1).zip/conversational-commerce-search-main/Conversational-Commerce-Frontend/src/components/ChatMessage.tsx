import { useState } from 'react';
import { Card } from './ui/card';
import { 
  User, ShoppingBag, Star, ShoppingCart,
  // Product category icons
  Headphones, Laptop, Smartphone, Camera, Watch, Gamepad2, Tv,
  Book, BookOpen, GraduationCap, Baby,
  Dumbbell, Backpack, Heart, Trophy, Tent, Bike,
  Shirt, Glasses,
  Armchair, UtensilsCrossed, Home, Flower2, Wrench,
  Sparkles, Apple, Pill, Droplet, Car
} from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import { getExamplesForCategories } from '../constants/exampleQueries';

interface Product {
  product_id: string;
  name: string;
  category: string;
  subcategory: string;
  brand: string;
  price: number;
  description: string;
  avg_rating: number;
  features?: Record<string, any>;
  agent_summary?: string; // Agent's one-liner description from the response
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  products?: Product[];
  timestamp: Date;
  responseTime?: string;
}

interface ChatMessageProps {
  message: Message;
  userCustomerId?: string;
  userEmail?: string;
  userGender?: string;
  userName?: string;
  userPreferredCategories?: string[];
  onExampleClick?: (query: string) => void;
}

// Get icon component and gradient colors for product subcategories
// Get icon component for subcategory (same system as MiniCart)
const getSubcategoryIcon = (subcategory: string): any => {
  const iconMap: Record<string, any> = {
    'Headphones': Headphones, 'Laptop': Laptop, 'Tablet': Smartphone, 'Phone': Smartphone,
    'Camera': Camera, 'Smart Watch': Watch, 'Watch': Watch, 'Gaming': Gamepad2, 'TV': Tv,
    'Fiction': Book, 'Non-Fiction': BookOpen, 'Biography': BookOpen, 'Textbook': GraduationCap, 'Children': Baby,
    'Athletic Wear': Shirt, 'Outdoor Gear': Backpack, 'Fitness': Dumbbell, 'Sports Equipment': Trophy,
    'Camping': Tent, 'Cycling': Bike,
    'Outerwear': Shirt, 'Pants': Shirt, 'Shirts': Shirt, 'Jacket': Shirt, 'Coat': Shirt, 'Dress': Sparkles, 'Dresses': Sparkles,
    'Shoes': Shirt, 'Accessories': Glasses, 'Hat': Sparkles,
    'Furniture': Armchair, 'Kitchen': UtensilsCrossed, 'Decor': Home, 'Garden': Flower2, 'Tools': Wrench,
    'Toys': Sparkles, 'Food': Apple, 'Health': Heart, 'Beauty': Droplet, 'Automotive': Car,
  };
  
  for (const [key, Icon] of Object.entries(iconMap)) {
    if (subcategory.toLowerCase().includes(key.toLowerCase())) {
      return Icon;
    }
  }
  return ShoppingBag;
};

// Generate product image URL with enhanced keyword mapping for best results
const getProductImageUrl = (category: string, subcategory: string, productId: string): string => {
  // Enhanced image mapping for specific subcategories using reliable sources
  const subcategoryImages: Record<string, string> = {
    // Electronics - High quality tech images
    'Headphones': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
    'Laptops': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Laptop': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Smartphones': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Tablets': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Tablet': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Phone': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Camera': 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=400&fit=crop',
    'Smart Watches': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Smart Watch': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Watch': 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=400&h=400&fit=crop',
    'Gaming': 'https://images.unsplash.com/photo-1486401899868-0e435ed85128?w=400&h=400&fit=crop',
    'TV': 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=400&fit=crop',
    
    // Books - Relevant book imagery
    'Fiction': 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop',
    'Non-Fiction': 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=400&fit=crop',
    'Science': 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400&h=400&fit=crop',
    'History': 'https://images.unsplash.com/photo-1461360228754-6e81c478b882?w=400&h=400&fit=crop',
    'Biography': 'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=400&h=400&fit=crop',
    'Self-Help': 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&h=400&fit=crop',
    'Textbook': 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400&h=400&fit=crop',
    'Children': 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=400&fit=crop',
    
    // Sports & Outdoors - Distinct imagery for each subcategory
    // Fitness - Indoor gym/workout equipment
    'Fitness': 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=400&fit=crop', // Dumbbells and gym equipment
    // Outdoor Gear - Mountain/hiking gear
    'Outdoor Gear': 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=400&h=400&fit=crop', // Camping mountains
    // Hiking/Trail specific (must come before general "Outdoor Gear")
    'Hiking Boots': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Trail Shoes': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    'Hiking Shoes': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    'Hiking': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Trail': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    // Sports Equipment - Ball sports and equipment
    'Sports Equipment': 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=400&h=400&fit=crop', // Basketball close-up
    // Athletic Wear - Running/sports clothing
    'Athletic Wear': 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=400&fit=crop', // Athletic shoes/sportswear
    // Camping - Tents and camping scenes
    'Camping': 'https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?w=400&h=400&fit=crop', // Camping tent
    'Cycling': 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=400&h=400&fit=crop',
    
    // Clothing - Fashion photography
    'Outerwear': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Pants': 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400&h=400&fit=crop',
    'Shirts': 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=400&h=400&fit=crop',
    'Jacket': 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop',
    'Coat': 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400&h=400&fit=crop',
    'Dress': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Dresses': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Shoes': 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
    'Accessories': 'https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=400&h=400&fit=crop',
    'Hat': 'https://images.unsplash.com/photo-1521369909029-2afed882baee?w=400&h=400&fit=crop',
    
    // Home & Garden - Interior and lifestyle imagery
    'Furniture': 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&h=400&fit=crop',
    'Kitchen': 'https://images.unsplash.com/photo-1556911220-bff31c812dba?w=400&h=400&fit=crop',
    'Decor': 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=400&h=400&fit=crop',
    'Garden': 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400&h=400&fit=crop',
    'Tools': 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400&h=400&fit=crop',
    'Storage': 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop',
    'Organizer': 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop',
    'Organizers': 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop',
    
    // Other categories
    'Toys': 'https://images.unsplash.com/photo-1558060370-d644479cb6f7?w=400&h=400&fit=crop',
    'Food': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=400&fit=crop',
    'Health': 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400&h=400&fit=crop',
    'Beauty': 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop',
    'Automotive': 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=400&h=400&fit=crop',
  };
  
  // Try exact match first (case-sensitive for performance)
  if (subcategoryImages[subcategory]) {
    return subcategoryImages[subcategory];
  }
  
  // Try partial, case-insensitive match
  const subcategoryLower = subcategory.toLowerCase();
  for (const [key, imageUrl] of Object.entries(subcategoryImages)) {
    if (subcategoryLower.includes(key.toLowerCase()) || key.toLowerCase().includes(subcategoryLower)) {
      return imageUrl;
    }
  }
  
  // Category-based fallback for common categories
  const categoryLower = category.toLowerCase();
  if (categoryLower.includes('home') || categoryLower.includes('garden') || categoryLower.includes('furniture')) {
    return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop'; // Storage/furniture
  }
  if (categoryLower.includes('electronics') || categoryLower.includes('tech')) {
    return 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400&h=400&fit=crop'; // Tech/gadgets
  }
  if (categoryLower.includes('book')) {
    return 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop'; // Books
  }
  if (categoryLower.includes('clothing') || categoryLower.includes('fashion')) {
    return 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400&h=400&fit=crop'; // Fashion
  }
  if (categoryLower.includes('sports') || categoryLower.includes('outdoor')) {
    return 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400&h=400&fit=crop'; // Sports
  }
  
  // Final fallback - generic shopping
  return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop';
};

// Generate contextual follow-up suggestions based on message content
const getFollowUpSuggestions = (message: Message): string[] => {
  if (!message.products || message.products.length === 0) return [];
  
  const firstProduct = message.products[0];
  const category = firstProduct.category;
  const subcategory = firstProduct.subcategory;
  const avgPrice = message.products.reduce((sum, p) => sum + p.price, 0) / message.products.length;
  
  // Map categories to natural language terms
  const getCategoryTerm = (cat: string) => {
    const categoryMap: Record<string, string> = {
      'Electronics': 'electronics',
      'Books': 'books',
      'Clothing': 'clothing',
      'Home & Garden': 'home & garden items',
      'Sports & Outdoors': 'sports & outdoors gear'
    };
    return categoryMap[cat] || cat.toLowerCase();
  };
  
  const categoryTerm = getCategoryTerm(category);
  
  // Generate contextual suggestions based on what was shown
  const suggestions: string[] = [];
  
  // Price-based suggestions
  if (avgPrice > 100) {
    suggestions.push(`Show me similar ${subcategory} products under $${Math.round(avgPrice * 0.7)}`);
  } else {
    suggestions.push(`Show me premium ${subcategory} options`);
  }
  
  // Category-based suggestions
  if (category === 'Electronics') {
    suggestions.push(`Show me other ${subcategory} options`);
  } else if (category === 'Books') {
    suggestions.push(`Find other ${subcategory} books`);
  } else {
    suggestions.push(`Show me other ${categoryTerm}`);
  }
  
  // Brand-based suggestion with category-specific term
  if (firstProduct.brand) {
    suggestions.push(`Show me more ${categoryTerm} from ${firstProduct.brand}`);
  }
  
  return suggestions.slice(0, 3); // Return max 3 suggestions
};

export function ChatMessage({ message, userCustomerId, userEmail, userGender, userName, userPreferredCategories, onExampleClick }: ChatMessageProps) {
  const isUser = message.role === 'user';
  const { addItem } = useCart();
  const [expandedProducts, setExpandedProducts] = useState<Set<string>>(new Set());
  const followUpSuggestions = !isUser ? getFollowUpSuggestions(message) : [];
  const randomExamples = !isUser && (!message.products || message.products.length === 0) 
    ? getExamplesForCategories(userPreferredCategories, 3) 
    : [];

  const handleAddToCart = (product: Product) => {
    addItem({
      product_id: product.product_id,
      name: product.name,
      price: product.price,
      category: product.category,
      subcategory: product.subcategory,
      brand: product.brand,
      description: product.description,
    });
    toast.success(`Added ${product.name} to cart!`);
  };

  const toggleDescription = (productId: string) => {
    setExpandedProducts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(productId)) {
        newSet.delete(productId);
      } else {
        newSet.add(productId);
      }
      return newSet;
    });
  };

  const truncateDescription = (description: string, maxLength: number = 150) => {
    if (description.length <= maxLength) {
      return { text: description, isTruncated: false };
    }
    return { text: description.slice(0, maxLength), isTruncated: true };
  };

  // Parse grouped product categories from agent response
  const parseProductGroups = (content: string, products: Product[]) => {
    const groups: { category: string; products: Product[] }[] = [];
    
    // Debug: Show first 500 chars of content
    console.log('Content preview:', content.substring(0, 500));
    
    // Match category headers in the format: **Category - Subcategory:**
    // The colon is INSIDE the bold markers
    const categoryPattern = /(?:\n\n|\n)\*\*([^*\n]+?):\*\*/g;
    const categoryMatches = [...content.matchAll(categoryPattern)];
    
    console.log('parseProductGroups - found categories:', categoryMatches.length);
    console.log('parseProductGroups - total products:', products.length);
    
    if (categoryMatches.length > 0) {
      console.log('Matched categories:', categoryMatches.map(m => m[1]));
    }
    
    if (categoryMatches.length === 0) {
      // No categories found, return all products in one group
      console.log('parseProductGroups - no categories, returning all products in one group');
      return [{ category: '', products }];
    }
    
    // Extract product names from numbered list in each section
    const productsBySection: { category: string; productData: { name: string; summary: string }[] }[] = [];
    
    for (let i = 0; i < categoryMatches.length; i++) {
      const category = categoryMatches[i][1]; // Extract category name from **Category:**
      const categoryIndex = categoryMatches[i].index!;
      const nextCategoryIndex = i < categoryMatches.length - 1 ? categoryMatches[i + 1].index! : content.length;
      
      const sectionContent = content.substring(categoryIndex, nextCategoryIndex);
      
      // Extract products in the specified format:
      // "1. Product Name - $Price (rating) - Description"
      const productPattern = /\d+\.\s+(.+?)\s+-\s+\$[\d,]+\.?\d*\s+\([^)]+\)\s+-\s+([^\n]+)/gm;
      const productMatches = [...sectionContent.matchAll(productPattern)];
      
      const productData = productMatches.map(m => ({
        name: m[1].trim(),
        summary: m[2].trim()
      }));
      
      console.log(`Category "${category}": found ${productData.length} products`);
      productData.forEach(pd => {
        console.log(`  - ${pd.name}: ${pd.summary.substring(0, 50)}...`);
      });
      
      productsBySection.push({ category, productData });
    }
    
    // Match products to categories and add agent summaries
    for (const section of productsBySection) {
      const sectionProducts: Product[] = [];
      
      for (const productInfo of section.productData) {
        // Find matching product (fuzzy match - check if product name contains or is contained in the text)
        const matchedProduct = products.find(p => {
          const pName = p.name.toLowerCase();
          const searchName = productInfo.name.toLowerCase();
          return pName.includes(searchName) || searchName.includes(pName);
        });
        
        if (matchedProduct && !sectionProducts.find(p => p.product_id === matchedProduct.product_id)) {
          // Add agent_summary to the product
          const productWithSummary = {
            ...matchedProduct,
            agent_summary: productInfo.summary
          };
          console.log(`  Matched "${productInfo.name}" → "${matchedProduct.name}" with summary: ${productInfo.summary.substring(0, 50)}...`);
          sectionProducts.push(productWithSummary);
        } else if (!matchedProduct) {
          console.log(`  ❌ Could not match product: "${productInfo.name}"`);
        }
      }
      
      if (sectionProducts.length > 0) {
        console.log(`✅ Adding group "${section.category}" with ${sectionProducts.length} products`);
        groups.push({ category: section.category, products: sectionProducts });
      }
    }
    
    console.log(`parseProductGroups - final result: ${groups.length} groups`);
    groups.forEach((g, i) => {
      console.log(`  Group ${i}: "${g.category}" - ${g.products.length} products`);
    });
    
    // Add any unmatched products to the last group or create a new group
    const matchedIds = new Set(groups.flatMap(g => g.products.map(p => p.product_id)));
    const unmatchedProducts = products.filter(p => !matchedIds.has(p.product_id));
    
    if (unmatchedProducts.length > 0) {
      if (groups.length > 0) {
        groups[groups.length - 1].products.push(...unmatchedProducts);
      } else {
        groups.push({ category: '', products: unmatchedProducts });
      }
    }
    
    return groups;
  };

  // Split agent response into opening, product list, and closing sections
  const splitAgentResponse = (content: string, hasProducts: boolean) => {
    try {
      // If no products, return the full content as opening
      if (!hasProducts) {
        return { opening: content || '', closing: '' };
      }
      
      if (!content) {
        return { opening: '', closing: '' };
      }

      // Find the opening text (everything before the first category header)
      // Format: **Category - Subcategory:**
      const firstCategoryMatch = content.match(/\*\*[^*\n]+:\*\*/);
      
      if (firstCategoryMatch && firstCategoryMatch.index !== undefined) {
        const opening = content.substring(0, firstCategoryMatch.index).trim();
        
        // Find closing text (everything after "Would you like...")
        const closingMatch = content.match(/Would you like[^?]*\?/);
        const closing = closingMatch ? closingMatch[0].trim() : '';
        
        return { opening, closing };
      }
      
      // Fallback: show full content as opening
      return { opening: content, closing: '' };
    } catch (error) {
      console.error('Error in splitAgentResponse:', error);
      // Fallback: show full content
      return { opening: content || '', closing: '' };
    }
  };

  // Generate user avatar URL with initials style (same as UserProfilePanel)
  const getUserAvatarUrl = () => {
    // Use userName if available, otherwise fallback to email
    const name = userName || userEmail || 'User';
    
    // Use UI Avatars with Navy 800 background to match user message bubble
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=1B3139&color=fff&size=120&bold=true&font-size=0.4`;
  };

  return (
    <div 
      className={`flex gap-4 items-start ${isUser ? 'justify-end' : 'justify-start'}`}
      data-message-role={message.role}
    >
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-[#FF3621] flex items-center justify-center flex-shrink-0">
          <ShoppingBag className="w-5 h-5 text-white" />
        </div>
      )}
      
      <div className={`${isUser ? 'max-w-[85%]' : 'flex-1 max-w-[85%]'}`}>
        {isUser ? (
          <div className="bg-navy-800 text-white rounded-lg px-4 py-3">
            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {(() => {
              const hasProducts = message.products && message.products.length > 0;
              
              // Debug log
              if (!isUser && message.products) {
                console.log('ChatMessage products:', message.products.length, message.products);
              }
              
              // If no products, show message content AND follow-up examples
              if (!hasProducts) {
                return (
                  <>
                    <div className="bg-gradient-to-r from-[#FF3621] to-[#FF5F46] rounded-lg px-4 py-3">
                      <p className="text-sm text-white whitespace-pre-wrap">{message.content}</p>
                      {message.responseTime && (
                        <div className="mt-2 pt-2 border-t border-white/20">
                          <span className="text-xs text-white/80 flex items-center gap-1">
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Response time: {message.responseTime}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    {/* Show examples when there are no products */}
                    {onExampleClick && (
                      <div className="mt-4">
                        {/* Show 3 random examples */}
                        {randomExamples.length > 0 && (
                          <>
                            <p className="text-xs text-gray-500 mb-2 font-medium">Try these examples:</p>
                            <div className="flex flex-wrap gap-2 mb-3">
                              {randomExamples.map((example, index) => (
                                <button
                                  key={index}
                                  onClick={() => onExampleClick(typeof example === 'string' ? example : example.text)}
                                  className="px-3 py-1.5 text-xs bg-white border border-gray-200 rounded-full hover:border-[#FF3621] hover:bg-orange-200/20 text-gray-700 hover:text-[#FF3621] transition-all"
                                >
                                  <span className="mr-1">{typeof example === 'object' && example.emoji}</span>
                                  {typeof example === 'string' ? example : example.text}
                                </button>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </>
                );
              }
              
              // If there are products, parse and display them with structured layout
              let opening = '';
              let closing = '';
              let productGroups: Array<{ category: string | null; products: any[] }> = [];
              
              try {
                const splitResult = splitAgentResponse(message.content, hasProducts);
                opening = splitResult.opening;
                closing = splitResult.closing;
                productGroups = parseProductGroups(message.content, message.products!);
              } catch (error) {
                console.error('Error parsing product response:', error);
                // Fallback: show full message content if parsing fails
                opening = message.content;
                productGroups = [{ category: null, products: message.products || [] }];
              }
              
              return (
                <>
                  {/* Opening text */}
                  {opening && (
            <div className="bg-gradient-to-r from-[#FF3621] to-[#FF5F46] rounded-lg px-4 py-3">
                      <p className="text-sm text-white whitespace-pre-wrap">{opening}</p>
            </div>
                  )}
                  
                  {/* Product cards grouped by category */}
                  {hasProducts && productGroups.map((group, groupIndex) => (
                    <div key={`group-${groupIndex}`} className="space-y-3">
                      {/* Category header */}
                      {group.category && (
                        <div className="mt-6 mb-4">
                          <div className="flex items-center gap-3 bg-gradient-to-r from-orange-200/20 to-orange-200/20 border-l-4 border-[#FF3621] px-4 py-3 rounded-r-lg shadow-sm">
                            <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-r from-[#FF3621] to-[#FF5F46] rounded-lg flex items-center justify-center">
                              <ShoppingBag className="w-4 h-4 text-white" />
                            </div>
                            <h3 className="text-lg font-bold text-gray-900">
                              {group.category}
                            </h3>
                          </div>
                        </div>
                      )}
                      
                      {/* Products in this category */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                        {group.products.map((product, index) => {
                  const isExpanded = expandedProducts.has(product.product_id);
                  
                  // Debug logging
                  if (index === 0 && group.category) {
                    console.log(`🔍 Product ${product.name}:`, {
                      hasAgentSummary: !!product.agent_summary,
                      agentSummary: product.agent_summary,
                      descriptionPreview: product.description?.substring(0, 80) + '...'
                    });
                  }
                  
                  // Use agent's one-liner summary initially, then full description when expanded
                  const initialText = product.agent_summary || product.description;
                  const { text: truncatedText, isTruncated } = truncateDescription(initialText);
                  const displayDescription = isExpanded ? product.description : truncatedText;
                  
                  // Show "more" button if text is truncated OR if there's a longer full description
                  const hasMoreToShow = isTruncated || (product.agent_summary && product.description !== product.agent_summary);
                  
                  const Icon = getSubcategoryIcon(product.subcategory);
                  
                  return (
                  <Card 
                    key={`${message.id}-${product.product_id}`}
                    className="p-4 product-card border-gray-200 hover:border-[#FF3621] h-full flex flex-col animate-fadeInUp opacity-0 group transition-all hover:shadow-lg"
                    style={{
                      animationDelay: `${index * 150}ms`,
                      animationFillMode: 'forwards'
                    }}
                  >
                    <div className="flex gap-4 flex-1">
                        {/* Product Image with Badge */}
                        <div className="relative w-20 h-20 overflow-hidden rounded-xl flex-shrink-0 bg-gray-100">
                          <img 
                            src={getProductImageUrl(product.category, product.subcategory, product.product_id)}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            onError={(e) => {
                              // Fallback to icon if image fails to load
                              e.currentTarget.style.display = 'none';
                              const iconContainer = e.currentTarget.parentElement;
                              if (iconContainer) {
                                iconContainer.className = 'relative w-20 h-20 flex items-center justify-center bg-gray-100 rounded-xl flex-shrink-0';
                                const iconElement = document.createElement('div');
                                iconElement.innerHTML = `<svg class="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>`;
                                iconContainer.appendChild(iconElement);
                              }
                            }}
                          />
                          {/* Badge for top-rated products */}
                          {product.avg_rating >= 4.5 && (
                            <div className="absolute top-1 right-1 bg-gradient-to-r from-[#FF3621] to-[#FF5F46] text-white text-xs px-1.5 py-0.5 rounded-full font-semibold shadow-md">
                              ⭐
                            </div>
                          )}
                      </div>
                      
                      <div className="flex-1 min-w-0 flex flex-col">
                        <h4 className="font-semibold text-gray-900 mb-1 break-words group-hover:text-[#FF3621] transition-colors">
                          {product.name}
                        </h4>
                        <div className="flex items-center gap-2 mb-2 flex-shrink-0">
                          {/* Enhanced star rating display */}
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i}
                                className={`w-3.5 h-3.5 ${
                                  i < Math.floor(product.avg_rating)
                                    ? 'text-yellow-500 fill-yellow-500'
                                    : i < product.avg_rating
                                    ? 'text-yellow-500 fill-yellow-300'
                                    : 'text-gray-300 fill-gray-300'
                                }`}
                              />
                            ))}
                            <span className="text-sm text-gray-600 font-medium ml-0.5">{product.avg_rating}</span>
                          </div>
                          <span className="text-sm text-gray-400">•</span>
                          <span className="text-sm text-gray-600 truncate font-medium">{product.brand}</span>
                        </div>
                          <div className="text-sm text-gray-600 mb-3 flex-1">
                            <p className="whitespace-pre-wrap break-words">
                              {displayDescription}
                              {!isExpanded && hasMoreToShow && '...'}
                            </p>
                            {hasMoreToShow && (
                              <button
                                onClick={() => toggleDescription(product.product_id)}
                                className="text-[#FF3621] hover:text-[#E62F1C] font-medium mt-1 text-xs inline-flex items-center gap-1"
                              >
                                {isExpanded ? 'show less' : (
                                  <>
                                    more
                                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                    </svg>
                                  </>
                                )}
                              </button>
                            )}
                          </div>
                        <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100 gap-2">
                            <span className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FF3621] to-[#FF5F46]">
                            ${product.price.toFixed(2)}
                          </span>
                            <button 
                              onClick={() => handleAddToCart(product)}
                              className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white text-xs font-medium rounded-lg transition-all shadow-sm hover:shadow-md whitespace-nowrap flex-shrink-0"
                            >
                              <ShoppingCart className="w-3.5 h-3.5" />
                              <span>Add to Cart</span>
                          </button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                        })}
                      </div>
                    </div>
                  ))}
                    
                  {/* Closing text and response time */}
                  {(closing || message.responseTime) && (
                    <div className="bg-gradient-to-r from-[#FF3621] to-[#FF5F46] rounded-lg px-4 py-3">
                      {closing && (
                        <p className="text-sm text-white whitespace-pre-wrap">{closing}</p>
                      )}
                      {message.responseTime && (
                        <div className={closing ? "mt-2 pt-2 border-t border-white/20" : ""}>
                          <span className="text-xs text-white/80 flex items-center gap-1">
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Response time: {message.responseTime}
                            </span>
                      </div>
                    )}
                    </div>
                  )}
            
            {/* Contextual Follow-up Suggestions and Browse Examples (appears after assistant responses) */}
            {!isUser && onExampleClick && (
              <div className="mt-4">
                {/* Show follow-up suggestions only if there are products */}
                {followUpSuggestions.length > 0 && (
                  <>
                    <p className="text-xs text-gray-500 mb-2 font-medium">You might also like:</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {followUpSuggestions.map((suggestion, index) => (
                        <button
                          key={index}
                          onClick={() => onExampleClick(suggestion)}
                          className="px-3 py-1.5 text-xs bg-white border border-gray-200 rounded-full hover:border-[#FF3621] hover:bg-orange-200/20 text-gray-700 hover:text-[#FF3621] transition-all"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                
                {/* Show 3 random examples when there are no products */}
                {randomExamples.length > 0 && (
                  <>
                    <p className="text-xs text-gray-500 mb-2 font-medium">Try these examples:</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {randomExamples.map((example, index) => (
                        <button
                          key={index}
                          onClick={() => onExampleClick(typeof example === 'string' ? example : example.text)}
                          className="px-3 py-1.5 text-xs bg-white border border-gray-200 rounded-full hover:border-[#FF3621] hover:bg-orange-200/20 text-gray-700 hover:text-[#FF3621] transition-all"
                        >
                          <span className="mr-1">{typeof example === 'object' && example.emoji}</span>
                          {typeof example === 'string' ? example : example.text}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}
                </>
              );
            })()}
          </div>
        )}
      </div>

      {isUser && (
        <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 border-2 border-gray-200">
          <img 
            src={getUserAvatarUrl()} 
            alt="User"
            className="w-full h-full object-cover bg-gray-100"
            onError={(e) => {
              console.error('Failed to load avatar:', getUserAvatarUrl());
              e.currentTarget.style.display = 'none';
            }}
          />
        </div>
      )}
    </div>
  );
}

