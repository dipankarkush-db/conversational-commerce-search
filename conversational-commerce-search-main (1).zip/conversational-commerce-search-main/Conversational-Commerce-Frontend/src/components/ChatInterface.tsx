import { useState, useRef, useEffect } from 'react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Send, Sparkles } from 'lucide-react';
import { ChatMessage } from './ChatMessage';
import { LoadingExperience } from './LoadingExperience';
import { toast } from 'sonner';
import { sendChatMessage, getConfig, Message as ApiMessage, CustomerInteraction } from '../services/api';
import { getExamplesForCategories } from '../constants/exampleQueries';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  products?: Product[];
  timestamp: Date;
  responseTime?: string; // Response time in seconds (e.g., "2.34s")
}

interface Product {
  product_id: string;
  name: string;
  category: string;
  subcategory: string;
  brand: string;
  price: number;
  description: string;
  avg_rating: number;
  features?: Record<string, any>;
}

interface UserProfile {
  customer_id: string;
  name: string;
  email: string;
  gender?: string;
  persona: string;
  preferred_categories: string[];
  price_sensitivity: string;
  brand_loyalty: string;
  total_purchases: number;
  total_spent: number;
  avg_rating_given: number;
  favorite_brands: string[];
  recent_searches: string[];
  purchase_history: PurchaseItem[];
}

interface PurchaseItem {
  product_name: string;
  category: string;
  price: number;
  date: string;
  rating?: number;
}

interface ChatInterfaceProps {
  user: UserProfile;
  interactions: CustomerInteraction[];
  onLogout: () => void;
  onLoadingChange?: (isLoading: boolean) => void;
}

export function ChatInterface({ user, interactions, onLogout, onLoadingChange }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [maxTokens, setMaxTokens] = useState(800); // Default fallback
  const [exampleQueries, setExampleQueries] = useState<{ emoji: string; text: string }[]>([]);
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);
  const [hoveredTooltip, setHoveredTooltip] = useState<string | null>(null);
  const [pinnedTooltip, setPinnedTooltip] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  
  // Select 6 example queries based on user's preferred categories
  useEffect(() => {
    setExampleQueries(getExamplesForCategories(user.preferred_categories, 6));
  }, [user.email, user.preferred_categories]);

  // Notify parent when loading state changes
  useEffect(() => {
    if (onLoadingChange) {
      onLoadingChange(isLoading);
    }
  }, [isLoading, onLoadingChange]);

  // Listen for header search submissions
  useEffect(() => {
    const handleHeaderSearch = (e: CustomEvent) => {
      const searchQuery = e.detail;
      if (searchQuery && searchQuery.trim()) {
        // Directly send the message without setting input state
        sendMessage(searchQuery);
      }
    };

    window.addEventListener('headerSearch', handleHeaderSearch as EventListener);
    return () => {
      window.removeEventListener('headerSearch', handleHeaderSearch as EventListener);
    };
  }, []); // No dependencies needed since we're calling sendMessage directly
  
  // Helper function to send message directly
  const sendMessage = async (query: string) => {
    if (!query.trim() || isLoading) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: query,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    
    const startTime = performance.now();
    
    try {
      // Call FastAPI backend with correct format
      const apiMessages: ApiMessage[] = [...messages, userMessage].map(m => ({
        role: m.role,
        content: m.content
      }));

      const response = await sendChatMessage({
        customer_id: user.customer_id,
        customer_name: user.name,
        customer_email: user.email,
        messages: apiMessages,
        max_tokens: maxTokens
      });
      
      const endTime = performance.now();
      const responseTimeSeconds = ((endTime - startTime) / 1000).toFixed(2);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        products: response.products,
        timestamp: new Date(),
        responseTime: `${responseTimeSeconds}s`
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Failed to send message:', error);
      toast.error('Failed to get response. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch config on mount
  useEffect(() => {
    getConfig()
      .then(config => {
        if (config.max_tokens) {
          setMaxTokens(config.max_tokens);
        }
      })
      .catch(err => console.error('Failed to load config:', err));
  }, []);

  // Auto-scroll to top for new messages (descending order display)
  useEffect(() => {
    if (messages.length === 0) return;
    
    // Scroll to top to show the newest message (since we're displaying in reverse order)
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [messages]);

  // Focus input on mount
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // Update active tooltip based on hover or pinned state
  useEffect(() => {
    setActiveTooltip(pinnedTooltip || hoveredTooltip);
  }, [hoveredTooltip, pinnedTooltip]);

  // Click outside to close pinned tooltip
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (tooltipRef.current && !tooltipRef.current.contains(event.target as Node)) {
        setPinnedTooltip(null);
      }
    };

    if (pinnedTooltip) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }
  }, [pinnedTooltip]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Track response time
    const startTime = performance.now();

    try {
      // Call FastAPI backend
      const apiMessages: ApiMessage[] = [...messages, userMessage].map(m => ({
        role: m.role,
        content: m.content
      }));

      const response = await sendChatMessage({
        customer_id: user.customer_id,
        customer_name: user.name,
        customer_email: user.email,
        messages: apiMessages,
        max_tokens: maxTokens
      });

      // Calculate response time in seconds
      const endTime = performance.now();
      const responseTimeSeconds = ((endTime - startTime) / 1000).toFixed(2);

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        products: response.products,
        timestamp: new Date(),
        responseTime: `${responseTimeSeconds}s`
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('❌ Error sending message:', error);
      toast.error('Failed to get recommendations. Please check logs and try again.');
      // NO FALLBACK - force real API to work
    } finally {
      setIsLoading(false);
    }
  };

  const handleExampleClick = (query: string | { emoji: string; text: string }) => {
    // Extract text from query object if needed
    const queryText = typeof query === 'string' ? query : query.text;
    // Populate header search box with the example query (don't auto-submit)
    const event = new CustomEvent('populateHeaderSearch', { detail: queryText });
    window.dispatchEvent(event);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="w-full">
      {/* Main Chat Area - Full Width */}
      <div className="w-full">
        <Card className="h-[calc(100vh-10rem)] flex flex-col relative">
          {/* Chat Messages */}
          <ScrollArea className="flex-1 p-6" style={{ backgroundColor: 'rgb(234, 237, 237)' }}>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-start text-center px-6 py-6">
                {/* Large Icon - Databricks Style */}
                <div className="w-20 h-20 bg-[#FF3621] rounded-full flex items-center justify-center mb-5 shadow-lg">
                  <Sparkles className="w-10 h-10 text-white" />
                </div>
                
                {/* Heading - Databricks Style */}
                <h2 className="text-2xl font-semibold text-navy-900 mb-3">Start Your AI Shopping Journey</h2>
                
                {/* Description - Databricks Style */}
                <p className="text-base text-navy-700 mb-6 max-w-2xl leading-relaxed">
                  Ask me anything about products. I can help you find exactly what you're looking for using natural language.
                </p>
                
                {/* Quick Examples with Emojis - Databricks Style */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 w-full max-w-5xl mb-5">
                  {exampleQueries.map((query, index) => (
                    <button
                      key={index}
                      onClick={() => handleExampleClick(query)}
                      className="p-5 bg-white backdrop-blur-sm border border-gray-lines rounded-lg hover:border-[#FF3621] hover:shadow-lg transition-all text-center group min-h-[140px] flex flex-col items-center justify-center hover:bg-oat-light"
                    >
                      <div className="w-14 h-14 bg-orange-200/20 rounded flex items-center justify-center mb-3 group-hover:bg-orange-200/30 transition-colors">
                        <span className="text-3xl group-hover:scale-110 transition-transform">{query.emoji}</span>
                      </div>
                      <div className="text-sm text-navy-800 font-medium leading-snug">{query.text}</div>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div ref={scrollRef} />
                {/* Group messages into pairs and reverse the pairs, keeping question-answer order */}
                {(() => {
                  const messagePairs: Message[][] = [];
                  for (let i = 0; i < messages.length; i += 2) {
                    if (i + 1 < messages.length) {
                      // Push pair [userMessage, assistantMessage]
                      messagePairs.push([messages[i], messages[i + 1]]);
                    } else {
                      // Odd number of messages, push the last one alone
                      messagePairs.push([messages[i]]);
                    }
                  }
                  // Reverse pairs so newest pair is first, but keep question before answer
                  const reversedPairs = messagePairs.reverse().flat();
                  
                  return reversedPairs.map((message, index) => (
                    <div key={message.id}>
                      <ChatMessage 
                        message={message}
                        userCustomerId={user.customer_id}
                        userEmail={user.email}
                        userGender={user.gender}
                        userName={user.name}
                        userPreferredCategories={user.preferred_categories}
                        onExampleClick={handleExampleClick}
                      />
                      {/* Show loading indicator after the first message (newest user question) */}
                      {index === 0 && isLoading && message.role === 'user' && (
                        <div className="mt-4">
                          <LoadingExperience mode="chat" />
                        </div>
                      )}
                    </div>
                  ));
                })()}
              </div>
            )}
          </ScrollArea>

          {/* Footer - Databricks Style */}
          <div className="border-t border-gray-lines py-1 px-3 bg-oat-light text-center">
            <p className="text-xs text-gray-navigation">
              Powered by Databricks AI • Unity Catalog • Claude 3.7 Sonnet
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
