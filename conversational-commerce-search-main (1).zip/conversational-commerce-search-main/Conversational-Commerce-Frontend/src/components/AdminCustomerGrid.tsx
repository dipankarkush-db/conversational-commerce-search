import { useState, useEffect } from 'react';
import { AdminCustomerCard } from './AdminCustomerCard';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { CustomerInfo, getAdminCustomers } from '../services/api';
import { Users, ArrowLeft, Loader2 } from 'lucide-react';

interface AdminCustomerGridProps {
  onSelectCustomer: (customer: CustomerInfo) => void;
  onBack: () => void;
}

export function AdminCustomerGrid({ onSelectCustomer, onBack }: AdminCustomerGridProps) {
  const [customers, setCustomers] = useState<CustomerInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    setIsLoading(true);
    setError('');
    
    try {
      const data = await getAdminCustomers();
      setCustomers(data);
    } catch (err) {
      console.error('Failed to fetch admin customers:', err);
      setError('Failed to load customers. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Group customers by persona
  const groupedCustomers = customers.reduce((acc, customer) => {
    const persona = customer.persona || 'Unknown';
    if (!acc[persona]) {
      acc[persona] = [];
    }
    acc[persona].push(customer);
    return acc;
  }, {} as Record<string, CustomerInfo[]>);

  // Sort personas alphabetically, but put "Mixed" at the end
  const personas = Object.keys(groupedCustomers).sort((a, b) => {
    if (a === 'Mixed') return 1;
    if (b === 'Mixed') return -1;
    return a.localeCompare(b);
  });

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <Button
                onClick={onBack}
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-[#FF3621] to-[#FF5F46] rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-gray-900">Admin Dashboard</h1>
                  <p className="text-xs text-gray-500">Customer Management</p>
                </div>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              {customers.length} Customers
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
        {/* Loading State */}
        {isLoading && (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-12 h-12 text-[#FF3621] animate-spin mb-4" />
            <p className="text-gray-600">Loading customers...</p>
          </div>
        )}

        {/* Error State */}
        {error && !isLoading && (
          <div className="bg-orange-200/20 border border-orange-200 rounded-lg p-6 text-center">
            <p className="text-[#FF3621] mb-4">{error}</p>
            <Button onClick={fetchCustomers} variant="outline">
              Retry
            </Button>
          </div>
        )}

        {/* Customer Grid - Tabbed by Persona */}
        {!isLoading && !error && personas.length > 0 && (
          <Tabs defaultValue={personas[0]} className="w-full">
            <TabsList className="w-full justify-start bg-white border border-gray-200 p-1 rounded-lg mb-6 flex-wrap h-auto gap-2">
              {personas.map((persona) => (
                <TabsTrigger
                  key={persona}
                  value={persona}
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white data-[state=active]:shadow-md px-6 py-2.5 rounded-md transition-all font-medium text-gray-700 hover:bg-gray-50"
                >
                  {persona}
                  <span className="ml-2 px-2 py-0.5 rounded-full text-xs bg-white/20 data-[state=active]:bg-white/30">
                    {groupedCustomers[persona].length}
                  </span>
                </TabsTrigger>
              ))}
            </TabsList>

            {personas.map((persona) => (
              <TabsContent key={persona} value={persona} className="mt-0">
                <div className="mb-4">
                  <p className="text-sm text-gray-500">
                    {groupedCustomers[persona].length} customer{groupedCustomers[persona].length !== 1 ? 's' : ''} in {persona}
                  </p>
                </div>

                {/* Customer Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {groupedCustomers[persona].map((customer) => (
                    <AdminCustomerCard
                      key={customer.customer_id}
                      customer={customer}
                      onSelectCustomer={onSelectCustomer}
                    />
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}

        {/* Empty State */}
        {!isLoading && !error && customers.length === 0 && (
          <div className="text-center py-20">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600 text-lg mb-2">No customers found</p>
            <p className="text-gray-500 text-sm">Please check your database connection.</p>
          </div>
        )}
      </main>
    </div>
  );
}

