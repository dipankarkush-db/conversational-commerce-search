import { X, Package, Calendar, DollarSign } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';

interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

interface Order {
  orderId: string;
  timestamp: Date;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
}

interface OrdersPanelProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
}

export function OrdersPanel({ isOpen, onClose, orders }: OrdersPanelProps) {
  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Slide-out Panel */}
      <div className="fixed top-0 right-0 h-full w-full sm:w-[500px] bg-white shadow-2xl z-50 transform transition-transform">
        <div className="h-full flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Package className="w-6 h-6 text-green-600" />
                My Orders
              </h2>
              <p className="text-sm text-gray-600 mt-1">Orders: {orders.length}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Orders List */}
          <ScrollArea className="flex-1 p-6">
            {orders.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <Package className="w-16 h-16 text-gray-300 mb-4" />
                <p className="text-gray-500 text-lg">No orders yet</p>
                <p className="text-gray-400 text-sm mt-2">
                  Your order history will appear here
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order) => (
                  <Card key={order.orderId} className="p-4 border-2 border-gray-200">
                    {/* Order Header */}
                    <div className="flex items-start justify-between mb-3 pb-3 border-b">
                      <div>
                        <p className="text-sm font-semibold text-gray-900">
                          Order #{order.orderId}
                        </p>
                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(order.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded">
                        ✓ Placed
                      </span>
                    </div>

                    {/* Order Items */}
                    <div className="space-y-2 mb-3">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-sm">
                          <span className="text-gray-700">
                            {item.quantity}x {item.name}
                          </span>
                          <span className="text-gray-900 font-medium">
                            ${(item.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Order Total */}
                    <div className="pt-3 border-t space-y-1">
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>Subtotal:</span>
                        <span>${order.subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>Tax (6.5%):</span>
                        <span>${order.tax.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-lg font-bold text-gray-900 pt-2">
                        <span className="flex items-center gap-1">
                          <DollarSign className="w-5 h-5" />
                          Total:
                        </span>
                        <span className="text-green-600">${order.total.toFixed(2)}</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Footer */}
          <div className="p-6 border-t bg-gray-50">
            <div className="text-center text-sm text-gray-600 mb-4">
              <p>📧 Confirmation emails sent to your email</p>
              <p className="text-xs text-gray-500 mt-1">All orders are securely stored in the database</p>
            </div>
            <Button
              onClick={onClose}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white"
            >
              Close
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}

