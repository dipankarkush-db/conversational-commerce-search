import { useCart } from '../contexts/CartContext';
import {
  Headphones, Laptop, Smartphone, Camera, Watch, Gamepad2, Tv,
  Book, BookOpen, GraduationCap, Baby,
  Dumbbell, Backpack, Heart, Trophy, Tent, Bike,
  Shirt, Glasses,
  Armchair, UtensilsCrossed, Home, Flower2, Wrench,
  Sparkles, Apple, Pill, Droplet, Car, ShoppingBag, X
} from 'lucide-react';

interface MiniCartProps {
  isVisible: boolean;
  onViewCart: () => void;
  onClose?: () => void;
}

// Get icon component for subcategory (same system as ChatMessage) - used as fallback
const getSubcategoryIcon = (subcategory: string): any => {
  const iconMap: Record<string, any> = {
    'Headphones': Headphones, 'Laptop': Laptop, 'Tablet': Smartphone, 'Phone': Smartphone,
    'Camera': Camera, 'Smart Watch': Watch, 'Watch': Watch, 'Gaming': Gamepad2, 'TV': Tv,
    'Fiction': Book, 'Non-Fiction': BookOpen, 'Biography': BookOpen, 'Textbook': GraduationCap, 'Children': Baby,
    'Athletic Wear': Shirt, 'Outdoor Gear': Backpack, 'Fitness': Dumbbell, 'Sports Equipment': Trophy,
    'Camping': Tent, 'Cycling': Bike,
    'Outerwear': Shirt, 'Pants': Shirt, 'Shirts': Shirt, 'Jacket': Shirt, 'Coat': Shirt, 'Dress': Sparkles, 'Dresses': Sparkles,
    'Shoes': Shirt, 'Accessories': Glasses, 'Hat': Sparkles,
    'Furniture': Armchair, 'Kitchen': UtensilsCrossed, 'Decor': Home, 'Garden': Flower2, 'Tools': Wrench,
    'Toys': Sparkles, 'Food': Apple, 'Health': Heart, 'Beauty': Droplet, 'Automotive': Car,
  };
  
  for (const [key, Icon] of Object.entries(iconMap)) {
    if (subcategory.toLowerCase().includes(key.toLowerCase())) {
      return Icon;
    }
  }
  return ShoppingBag;
};

// Generate product image URL with enhanced keyword mapping for best results
const getProductImageUrl = (category: string, subcategory: string, productId: string): string => {
  // Enhanced image mapping for specific subcategories using reliable sources
  const subcategoryImages: Record<string, string> = {
    // Electronics - High quality tech images
    'Headphones': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
    'Laptops': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Laptop': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=400&fit=crop',
    'Smartphones': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Tablets': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Tablet': 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop',
    'Phone': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop',
    'Camera': 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=400&fit=crop',
    'Smart Watches': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Smart Watch': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
    'Watch': 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=400&h=400&fit=crop',
    'Gaming': 'https://images.unsplash.com/photo-1486401899868-0e435ed85128?w=400&h=400&fit=crop',
    'TV': 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=400&fit=crop',
    
    // Books - Relevant book imagery
    'Fiction': 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop',
    'Non-Fiction': 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=400&fit=crop',
    'Science': 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400&h=400&fit=crop',
    'History': 'https://images.unsplash.com/photo-1461360228754-6e81c478b882?w=400&h=400&fit=crop',
    'Biography': 'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=400&h=400&fit=crop',
    'Self-Help': 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&h=400&fit=crop',
    'Textbook': 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400&h=400&fit=crop',
    'Children': 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=400&fit=crop',
    
    // Sports & Outdoors - Distinct imagery for each subcategory
    // Fitness - Indoor gym/workout equipment
    'Fitness': 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=400&fit=crop', // Dumbbells and gym equipment
    // Outdoor Gear - Mountain/hiking gear
    'Outdoor Gear': 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=400&h=400&fit=crop', // Camping mountains
    // Hiking/Trail specific (must come before general "Outdoor Gear")
    'Hiking Boots': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Trail Shoes': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    'Hiking Shoes': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    'Hiking': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Trail': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    // Sports Equipment - Ball sports and equipment
    'Sports Equipment': 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=400&h=400&fit=crop', // Basketball close-up
    // Athletic Wear - Running/sports clothing
    'Athletic Wear': 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=400&fit=crop', // Athletic shoes/sportswear
    // Camping - Tents and camping scenes
    'Camping': 'https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?w=400&h=400&fit=crop', // Camping tent
    'Cycling': 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=400&h=400&fit=crop',
    
    // Clothing - Fashion photography
    'Outerwear': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    'Pants': 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400&h=400&fit=crop',
    'Shirts': 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=400&h=400&fit=crop',
    'Jacket': 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop',
    'Coat': 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400&h=400&fit=crop',
    'Dress': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Dresses': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
    'Shoes': 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
    'Accessories': 'https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=400&h=400&fit=crop',
    'Hat': 'https://images.unsplash.com/photo-1521369909029-2afed882baee?w=400&h=400&fit=crop',
    
    // Home & Garden - Interior and lifestyle imagery
    'Furniture': 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&h=400&fit=crop',
    'Kitchen': 'https://images.unsplash.com/photo-1556911220-bff31c812dba?w=400&h=400&fit=crop',
    'Decor': 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=400&h=400&fit=crop',
    'Garden': 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400&h=400&fit=crop',
    'Tools': 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400&h=400&fit=crop',
    
    // Other categories
    'Toys': 'https://images.unsplash.com/photo-1558060370-d644479cb6f7?w=400&h=400&fit=crop',
    'Food': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=400&fit=crop',
    'Health': 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400&h=400&fit=crop',
    'Beauty': 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop',
    'Automotive': 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=400&h=400&fit=crop',
  };
  
  // Try exact match first
  if (subcategoryImages[subcategory]) {
    return subcategoryImages[subcategory];
  }
  
  // Try partial match
  const subcategoryLower = subcategory.toLowerCase();
  for (const [key, imageUrl] of Object.entries(subcategoryImages)) {
    if (subcategoryLower.includes(key.toLowerCase()) || key.toLowerCase().includes(subcategoryLower)) {
      return imageUrl;
    }
  }
  
  // Category-based fallback
  const categoryLower = category.toLowerCase();
  if (categoryLower.includes('home') || categoryLower.includes('garden') || categoryLower.includes('furniture')) {
    return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('electronics') || categoryLower.includes('tech')) {
    return 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('book')) {
    return 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('clothing') || categoryLower.includes('fashion')) {
    return 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400&h=400&fit=crop';
  }
  if (categoryLower.includes('sports') || categoryLower.includes('outdoor')) {
    return 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400&h=400&fit=crop';
  }
  
  // Final fallback
  return 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop';
};

export function MiniCart({ isVisible, onViewCart, onClose }: MiniCartProps) {
  const { items, itemCount, subtotal, tax, totalPrice } = useCart();

  // Show when there are items in cart
  if (!isVisible || itemCount === 0) return null;

  return (
    <div className="absolute top-full right-0 pt-2 w-80 z-50">
      <div className="bg-white rounded-lg shadow-xl border border-gray-200">
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-gray-900">🛒 Your Cart ({itemCount})</h3>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Close mini cart"
            >
              <X className="w-4 h-4 text-gray-600" />
            </button>
          )}
        </div>
        
        {/* Cart Items */}
        <div className="space-y-1.5 mb-3">
          {items.slice(0, 3).map((item) => {
            const Icon = getSubcategoryIcon(item.subcategory || '');
            return (
            <div key={item.product_id} className="flex items-center gap-2.5 py-1.5 border-b border-gray-100 last:border-0">
              <div className="w-12 h-12 overflow-hidden rounded flex-shrink-0 bg-gray-100">
                <img 
                  src={getProductImageUrl(item.category, item.subcategory || '', item.product_id)}
                  alt={item.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback to icon if image fails to load
                    e.currentTarget.style.display = 'none';
                    const iconContainer = e.currentTarget.parentElement;
                    if (iconContainer) {
                      iconContainer.className = 'w-12 h-12 flex items-center justify-center bg-gray-100 rounded flex-shrink-0';
                      const iconElement = document.createElement('div');
                      iconElement.innerHTML = `<svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>`;
                      iconContainer.appendChild(iconElement);
                    }
                  }}
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate leading-tight">
                  {item.name}
                </p>
                <p className="text-xs text-gray-500 mt-0.5">
                  {item.quantity} × ${item.price.toFixed(2)}
                </p>
              </div>
              <p className="text-sm font-semibold text-[#FF3621]">
                ${(item.quantity * item.price).toFixed(2)}
              </p>
            </div>
          );
          })}
          
          {items.length > 3 && (
            <p className="text-xs text-gray-500 text-center py-0.5">
              +{items.length - 3} more item{items.length - 3 === 1 ? '' : 's'}
            </p>
          )}
        </div>

        {/* Price Breakdown */}
        <div className="bg-gray-50 p-2 rounded-lg border border-gray-200 space-y-1 mb-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Subtotal:</span>
            <span className="text-gray-900">${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Tax (6.5%):</span>
            <span className="text-gray-900">${tax.toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between pt-1 border-t border-gray-200">
            <span className="font-semibold text-gray-900">Total:</span>
            <span className="text-lg font-bold text-[#FF3621]">
              ${totalPrice.toFixed(2)}
            </span>
          </div>
        </div>

        {/* View Cart Button */}
        <button
          onClick={onViewCart}
          className="w-full bg-gradient-to-r from-[#FF3621] to-[#FF5F46] hover:from-[#F32415] hover:to-[#FF3621] text-white py-2 px-4 rounded-lg text-sm font-medium transition-all"
        >
          View Cart →
        </button>
      </div>
      </div>
    </div>
  );
}

