// Example queries organized by category with emojis
export const EXAMPLE_QUERIES_BY_CATEGORY: Record<string, { emoji: string; text: string }[]> = {
  "🎯 Intent Based Search": [
    { emoji: '🎧', text: "I work in a really loud place and need to take a lot of meetings. Looking for some high end headphones that can work well in this situation." },
    { emoji: '🏠', text: "I am moving to a new apartment and need to buy all the necessary items for my new apartment. I do not want them to be too expensive but durable. What do you suggest?" },
    { emoji: '⛺', text: "I am going for a camping trip where it's going to rain. I want to be prepared. I would also like to bring some books for leisure reading and plan to do lots of hiking and other activities. Each item should not be more than 500 $." },
    { emoji: '🎒', text: "My daughter is starting college next month and I need to get her essential items like a laptop, backpack, and some books. Looking for reliable products under $1000 total. Any recommendations?" },
    { emoji: '🎒', text: "Back to school season! I need a good quality backpack for my teenager, headphones for online classes, and maybe a tablet for studying. Budget is around $600." },
    { emoji: '🏕️', text: "Planning a camping trip for my family of 4 this weekend. Need a good quality tent, sleeping bags, and outdoor gear. Budget-friendly options preferred, under $400 per item." },
    { emoji: '🏕️', text: "Going camping in the mountains for 3 days. I need durable outdoor gear, hiking equipment, and comfortable athletic wear for trails. Quality is important but nothing over $500 each." },
    { emoji: '🎮', text: "My son is turning 16 and wants to start gaming seriously. I need to get him a gaming laptop, quality headphones, and maybe a smartwatch to track his activities. Budget around $2500 total." },
    { emoji: '👔', text: "I just got my first corporate job and need to build a professional wardrobe. Looking for shirts, pants, dresses, and some quality outerwear. Want to look polished but stay under $1200." },
    { emoji: '💼', text: "Setting up a home office for remote work. Need comfortable furniture, good storage solutions, and some nice decor to make it feel professional. Budget is around $1500." },
    { emoji: '💪', text: "New Year resolution to get fit! Need fitness equipment for home workouts, quality athletic wear, and maybe some outdoor gear for running. Looking to spend around $600." },
    { emoji: '📖', text: "Planning a cozy weekend reading retreat at home. Need some great fiction and non-fiction books, comfortable furniture, and maybe some nice decor. Budget around $500." },
  ],
  "Books": [
    { emoji: '📚', text: "Find me fiction books under $45" },
    { emoji: '📚', text: "Show me non-fiction books about history under $35" },
    { emoji: '📚', text: "Best science books for beginners under $75" },
    { emoji: '📚', text: "Recommend bestselling fiction from Random House under $30" },
    { emoji: '📚', text: "What are good biography books under $40?" },
  ],
  "Electronics": [
    { emoji: '🎧', text: "Wireless headphones under $350" },
    { emoji: '💻', text: "I need a laptop for students under $800" },
    { emoji: '📱', text: "Phones with good cameras under $500" },
    { emoji: '🎧', text: "Best noise-canceling headphones under $650" },
    { emoji: '📱', text: "I need a tablet for reading and browsing under $400" },
  ],
  "Sports & Outdoors": [
    { emoji: '🏕️', text: "Show me camping gear under $100" },
    { emoji: '💪', text: "Find me fitness equipment for home workouts under $250" },
    { emoji: '🥾', text: "What are good hiking boots for trails under $150?" },
    { emoji: '🧘', text: "I need gym equipment under $75" },
    { emoji: '🎒', text: "Show me outdoor gear for hiking under $200" },
    { emoji: '🏀', text: "Find me sports equipment for basketball under $100" },
    { emoji: '👟', text: "Show me Nike athletic wear for running under $120" },
    { emoji: '⛺', text: "I need camping tents for 4 people under $300" },
  ],
  "Clothing": [
    { emoji: '👗', text: "Find me dresses for a fancy dinner under $1000" },
    { emoji: '👕', text: "Show me casual shirts under $50" },
    { emoji: '👜', text: "Trendy accessories under $100" },
    { emoji: '👔', text: "Find me formal wear for business meetings under $300" },
    { emoji: '👖', text: "Show me comfortable jeans under $80" },
  ],
  "Home & Garden": [
    { emoji: '🍳', text: "I need kitchen appliances under $2000" },
    { emoji: '🛏️', text: "Furniture for a small apartment under $600" },
    { emoji: '🖼️', text: "Find me home decor items under $150" },
    { emoji: '📦', text: "What are good storage solutions for closets under $1200?" },
    { emoji: '🌻', text: "I need gardening tools for beginners under $80" },
    { emoji: '🛏️', text: "Show me bedroom furniture sets under $1500" },
  ],
};

// Flatten all queries into a single array for backwards compatibility
export const ALL_EXAMPLE_QUERIES = Object.values(EXAMPLE_QUERIES_BY_CATEGORY).flat();

// Helper function to randomly select N items from an array
export const getRandomItems = <T,>(arr: T[], count: number): T[] => {
  const shuffled = [...arr].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
};

/**
 * Get example queries based on customer's preferred categories
 * @param preferredCategories - Array of category names from customer profile
 * @param count - Number of examples to return
 * @returns Array of example queries matching the customer's preferences
 */
export const getExamplesForCategories = (
  preferredCategories: string[] | undefined,
  count: number = 6
): { emoji: string; text: string }[] => {
  // If no preferences, return random from all categories
  if (!preferredCategories || preferredCategories.length === 0) {
    return getRandomItems(ALL_EXAMPLE_QUERIES, count);
  }

  // Collect queries from matching categories
  const matchingQueries: { emoji: string; text: string }[] = [];
  
  preferredCategories.forEach(category => {
    const queries = EXAMPLE_QUERIES_BY_CATEGORY[category];
    if (queries) {
      matchingQueries.push(...queries);
    }
  });

  // If we found matching queries, use them; otherwise fall back to all
  if (matchingQueries.length > 0) {
    return getRandomItems(matchingQueries, count);
  }
  
  return getRandomItems(ALL_EXAMPLE_QUERIES, count);
};

