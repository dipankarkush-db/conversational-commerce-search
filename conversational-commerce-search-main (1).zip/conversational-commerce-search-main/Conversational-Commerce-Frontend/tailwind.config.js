/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'system-ui', '-apple-system', 'sans-serif'],
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)'
      },
      colors: {
        // Databricks Primary Colors (Official Lava 600)
        lava: {
          600: '#FF3621', // Primary Lava 600 - rgb(255,54,33)
          500: '#FF5F46', // Secondary Lava 500
        },
        navy: {
          900: '#0B2026', // Primary Navy
          800: '#1B3139',
          700: '#1B3C48',
          600: '#274B5A',
          500: '#37596A',
          400: '#5F7B88',
          300: '#8A9FA7',
          200: '#B5C5CB',
        },
        // Databricks Secondary Colors
        maroon: {
          600: '#981024',
        },
        yellow: {
          600: '#FFA800',
        },
        green: {
          600: '#00A972',
        },
        blue: {
          600: '#227284',
        },
        // Neutral Colors
        oat: {
          light: '#F9F7F4',
          medium: '#EEEDEB',
        },
        gray: {
          navigation: '#464D63',
          text: '#000D19',
          lines: '#E2E7EA',
        },
        // Extended palette for richer UI
        orange: {
          900: '#F32415',
          700: '#FD3716',
          500: '#FF5E48',
          400: '#FF7168',
          300: '#FFA396',
          200: '#FFBAB2',
        },
      }
    }
  },
  plugins: [require("tailwindcss-animate")],
}

