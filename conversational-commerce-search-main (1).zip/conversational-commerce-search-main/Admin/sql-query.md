# write a sql query using the following concept where I want 5 random customer from each persona.

    SELECT 
        customer_id,
        name as customer_name,
        email as customer_email,
        age as customer_age,
        gender as customer_gender,
        location as customer_location,
        persona,
        preferred_categories,
        total_orders,
        total_spent
    FROM retail_consumer_goods.conversational_commerce_search.customers
    ORDER BY RAND()  -- Random ordering
    LIMIT 1;  -- Return only one random customer


    personas = {
        'Tech Enthusiast': {
            'preferred_categories': ['Electronics'],
            'price_sensitivity': 'low',
            'brand_loyalty': 'high',
            'preferred_brands': ['Apple', 'Samsung', 'Sony']
        },
        'Fashion Forward': {
            'preferred_categories': ['Clothing'],
            'price_sensitivity': 'medium',
            'brand_loyalty': 'medium',
            'preferred_brands': ['Zara', 'H&M', 'Nike']
        },
        'Home Decorator': {
            'preferred_categories': ['Home & Garden'],
            'price_sensitivity': 'high',
            'brand_loyalty': 'low',
            'preferred_brands': ['IKEA', 'Target']
        },
        'Book Lover': {
            'preferred_categories': ['Books'],
            'price_sensitivity': 'high',
            'brand_loyalty': 'low',
            'preferred_brands': ['Penguin', 'Random House']
        },
        'Fitness Enthusiast': {
            'preferred_categories': ['Sports & Outdoors'],
            'price_sensitivity': 'medium',
            'brand_loyalty': 'high',
            'preferred_brands': ['Nike', 'Adidas', 'Under Armour']
        },
        'Bargain Hunter': {
            'preferred_categories': ['Electronics', 'Clothing', 'Home & Garden'],
            'price_sensitivity': 'very_high',
            'brand_loyalty': 'very_low',
            'preferred_brands': []
        }
    }