-- Query to get 6 random customers from each persona
-- Personas: Tech Enthusiast, Fashion Forward, Home Decorator, Book Lover, Fitness Enthusiast, Bargain Hunter

SELECT 
    customer_id,
    customer_name,
    customer_email,
    customer_age,
    customer_gender,
    customer_location,
    persona,
    preferred_categories,
    total_orders,
    total_spent
FROM (
    SELECT 
        customer_id,
        name as customer_name,
        email as customer_email,
        age as customer_age,
        gender as customer_gender,
        location as customer_location,
        persona,
        preferred_categories,
        total_orders,
        total_spent,
        ROW_NUMBER() OVER (PARTITION BY persona ORDER BY RAND()) as row_num
    FROM retail_consumer_goods.conversational_commerce_search.customers
) ranked
WHERE row_num <= 6
ORDER BY persona, row_num;

