# I need to build an admin version of this app

## It should be integrated with the exiting functionality

## No functionality of the existing app should be changed for the random customer experience

## In the Launch page Add a new button - "Admin experience" on the right side of "Start Shopping with AI" at exactly same level and same look and feel

### The button should be exactly same with the current desing of the other buttons including color

### Lets add a authentication page for admin experience. Use password "Admin"

### Clicking this button ("Admin experience") should open a new spearate page which will then show 36 different customers (6 from each persona). There are total 6 persona defined in agent/01_data_generation.ipynb/ Total 42 customers. The query to fetch these 42 customers is available in get_random_customers_by_persona.sql file.

### If there is not enough customer (not 6 in count) for a persona then do not worry about it. Show whatever is available

### Use this query to get 42 customers during runtime when the user clicks "Admin experience".

### These 42 customers need to be shown in this new page as customer card. 

### Each Customer card should show the following -
    #### customer_name,
    #### customer_email,
    #### persona,
    #### preferred_categories,
    #### total_orders,
    #### total_spent

### Each customer card should be clickable

### Once the admin clicks the customer name it should open the current chat interface page of the app for that customer. This point forward the experience is the same.

### Admin should be able to go back to the customer grid after selecting a customer and reviewing the chat interface for the customer.

### Admin auth should be required every time the user switches to admin experience (no session persistence).

### The admin should not have the ability to order but they can add to the cart and remove items from the cart.



I have now added 4 more tables - @generate_customer_profile_data.sql retail_consumer_goods.conversational_commerce_search.customer_browsing_events
retail_consumer_goods.conversational_commerce_search.customer_external_signals
retail_consumer_goods.conversational_commerce_search.customer_basket_intelligence
retail_consumer_goods.conversational_commerce_search.customer_browsing_events

I need to incorporate these information in the admin experience. So, when a customer for a persona is fetched in admin page it shows all of these details. See atatched image. Can you create a separate page for the same? Add a link in the customer postcard (as shown in the atatched picture) lower bottom called more and when clicked then show these details for the customer in a modal window.