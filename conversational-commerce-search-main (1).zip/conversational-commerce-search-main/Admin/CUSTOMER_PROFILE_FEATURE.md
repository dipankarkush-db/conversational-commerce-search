# Customer Profile Details Feature

## Overview
This feature adds detailed customer profile intelligence to the admin experience, showing:
- **Recent Shopping History** - Product interactions (purchases, cart adds, views)
- **Recent .com Browsing History** - Website/app browsing sessions with device, channel, and search queries
- **External Intelligence** - Social media signals from TikTok, Instagram, YouTube, Pinterest, Reddit
- **Basket Intelligence** - Frequently bought together products with affinity scores

## Implementation

### Backend Changes
**File:** `fastapi-backend/main.py`

Added new API endpoint:
```python
@app.get("/api/admin/customer-profile/{customer_id}")
async def get_customer_profile_details(customer_id: str)
```

This endpoint queries 4 new tables created by `generate_customer_profile_data.sql`:
1. `customer_profile_summary` - Aggregated customer profile
2. `customer_browsing_events` - Web/mobile browsing sessions
3. `customer_external_signals` - Social media engagement signals
4. `customer_basket_intelligence` - Co-purchase patterns
5. `interactions` - Recent shopping history (existing table)

### Frontend Changes

#### 1. New Modal Component
**File:** `Conversational-Commerce-Frontend/src/components/AdminCustomerProfileModal.tsx`

- Full-screen modal with detailed customer profile sections
- Color-coded badges for different data types
- Responsive layout with scrollable content
- Time-ago formatting for timestamps
- Engagement score visualization

#### 2. Updated Customer Card
**File:** `Conversational-Commerce-Frontend/src/components/AdminCustomerCard.tsx`

- Added "More Details" button at the bottom of each customer card
- Button triggers modal with detailed profile
- Prevents card selection when clicking "More Details"

## Data Tables Used

### 1. `customer_browsing_events`
Tracks customer browsing behavior across web and mobile:
- Session IDs, timestamps
- Channel (mobile_app/website)
- Page types (product_detail, search_results, category, home)
- Device type (iOS, Android, Desktop, Tablet)
- Search queries and focus topics
- Dwell time and scroll depth

### 2. `customer_external_signals`
Social media engagement signals:
- Platform (TikTok, Instagram, YouTube, Pinterest, Reddit)
- Signal type (trend_follow, content_engagement, influencer_like, wishlist_save)
- Content topics
- Engagement scores
- Source URLs

### 3. `customer_basket_intelligence`
Co-purchase patterns:
- Anchor product (what they bought)
- Associated product (what they bought together)
- Pair count (how many times)
- Affinity share (percentage)

### 4. `customer_profile_summary`
Unified view combining all signals with:
- Last purchase details
- Last browsing activity
- Last external signal
- Top cross-sell products

## Usage

### Admin Experience Flow:
1. Admin logs in and sees customer grid (6 per persona)
2. Click customer card → Opens chat interface (existing behavior)
3. Click "More Details" button → Opens detailed profile modal (NEW)

### Modal Sections:
- **Recent Shopping History** - Shows last 5 interactions with products
- **Recent .com Browsing History** - Last 5 browsing sessions
- **External Intelligence** - Last 5 social media signals
- **Basket Intelligence** - Top 5 product pairs frequently bought together

## Performance
- Backend queries 4 tables in parallel
- Returns top 5 records from each for fast loading
- Modal only loads data when opened (lazy loading)
- All data cached on first load

## UI/UX Features
- **Color-coded badges** for different channels/platforms
- **Time-ago formatting** (e.g., "2h ago", "5d ago")
- **Engagement scores** as percentages
- **Click-through links** to social media sources
- **Responsive design** works on all screen sizes
- **Smooth animations** for modal open/close

## Testing
To test the feature:
1. Build frontend: `cd Conversational-Commerce-Frontend && npm run build`
2. Start backend: `cd fastapi-backend && uvicorn main:app --reload`
3. Navigate to admin view
4. Click "More Details" on any customer card
5. Verify all 4 sections display data correctly

## Future Enhancements
- Add filters to browse historical data (e.g., last 30 days)
- Export customer profile as PDF
- Compare customer profiles side-by-side
- Real-time updates when new data arrives
- Integration with recommendation engine to show "why" certain products were recommended

